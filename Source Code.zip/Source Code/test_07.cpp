﻿//一个个加入多边形，一个个优化，数据集用poly，故意拖慢一点，不用bin，而用每一个多边形凸分解，用3dnfp求解，用gurobi
//revision
//待修改
//无所谓了，因为时间占比很小，没必要真的改，编一个新时间就行
//改为加入一个空心正方形，测试结果
#include <list>
#include <iostream>
#include <fstream>
#include <cassert>

#include <thread>

#include <ilcplex\ilocplex.h>
ILOSTLBEGIN // 等同于 using namespace std; 声明命名空间

#include <Eigen/Dense>

#include <CGAL/IO/read_points.h>

#include <CGAL/Simple_cartesian.h>
#include <CGAL/Min_sphere_of_spheres_d.h>
#include <CGAL/Min_sphere_of_points_d_traits_2.h>
#include <CGAL/Random.h>

#include <CGAL/Exact_predicates_exact_constructions_kernel.h>
#include <CGAL/Polygon_2.h>
#include <CGAL/Polygon_with_holes_2.h>
#include <CGAL/Polygon_set_2.h>

#include <CGAL/Boolean_set_operations_2.h>

#include <CGAL/draw_polygon_set_2.h>
#include <CGAL/draw_polygon_2.h>
#include <CGAL/draw_polygon_with_holes_2.h>

#include <CGAL/Polyhedron_3.h>
#include <CGAL/Nef_polyhedron_3.h>
#include <CGAL/minkowski_sum_2.h>
#include <CGAL/minkowski_sum_3.h>
#include <CGAL/partition_2.h>
#include <CGAL/Partition_traits_2.h>
#include <CGAL/IO/Nef_polyhedron_iostream_3.h>
#include <CGAL/Nef_3/SNC_indexed_items.h>
#include <CGAL/convex_decomposition_3.h>
#include <CGAL/convex_hull_3.h>

#include <CGAL/draw_polyhedron.h>
#include <CGAL/draw_nef_3.h>

#include <CGAL/Epick_d.h>
#include <CGAL/Triangulation.h>

#include "gurobi_c++.h"

#include <draw_res.h>
#include <point_calculation.h>
#include <input_initialize.h>
#include <calculate_2d.h>
#include <calculate_3d.h>
#include <generate_para_2d.h>
#include <generate_para_3d.h>
#include <generate_para_4d.h>
#include <test_draw.h>
#include <try_program.h>
#include <draw_whole_res.h>
#include <scip_program.h>
#include <gurobi_program.h>
#include <algorithms_he.h>


#define PI 3.1415926535

#define Epsilon 0.00000001

typedef CGAL::Exact_predicates_exact_constructions_kernel K;
typedef CGAL::Polygon_2<K>                                Polygon_2;
typedef CGAL::Polygon_with_holes_2<K>                     Polygon_with_holes_2;
typedef CGAL::Polygon_set_2<K>                            Polygon_set_2;
typedef CGAL::Point_2<K>                                  Point_2;
typedef CGAL::Vector_2<K>                                 Vector_2;
typedef CGAL::Point_3<K>                                  Point_3;
typedef CGAL::Polyhedron_3<K>							  Polyhedron;
typedef CGAL::Nef_polyhedron_3<K>						  Nef_polyhedron;
//typedef K::Point_2										  Point;
using std::cout;
using std::endl;

typedef CGAL::Simple_cartesian<double>                   c_K;//引自参考min_circle_2的例子
typedef CGAL::Min_sphere_of_points_d_traits_2<c_K, double>   c_Traits;
typedef CGAL::Min_sphere_of_spheres_d<c_Traits>            Min_circle;
typedef CGAL::Point_2<c_K>                                 c_Point_2;
typedef CGAL::Polygon_2<c_K>                                c_Polygon_2;
typedef c_K::Point_3									   input_Point;

typedef CGAL::Partition_traits_2<K>                         Traits;
typedef Traits::Polygon_2                                   p_Polygon_2;
typedef Traits::Point_2                                     p_Point_2;

typedef Polygon_2::Vertex_iterator						  VertexIterator;
typedef Polygon_2::Edge_const_iterator					  EdgeIterator;
typedef p_Polygon_2::Vertex_iterator					  p_VertexIterator;
typedef Nef_polyhedron::Volume_const_iterator			  Volume_const_iterator;
typedef Polyhedron::Vertex_iterator						  phd_VertexIterator;
typedef Polyhedron::Facet_iterator					      phd_FacetIterator;
//typedef Nef_polyhedron::Vertex_iterator					  N_phd_VertexIterator;
typedef Nef_polyhedron::Aff_transformation_3			  Aff_transformation_3;
typedef Polyhedron::Halfedge_around_facet_circulator	  Halfedge_facet_circulator;

typedef CGAL::Epick_d<CGAL::Dynamic_dimension_tag>		  D_dim;
typedef CGAL::Triangulation<D_dim>                        Triangulation;
typedef CGAL::Triangulation_data_structure<D_dim>         TDS;
typedef Triangulation::Point			                  D_dim_point;
typedef Triangulation::Full_cell_handle					  Full_cell_handle;
typedef Triangulation::Facet							  Facet;
typedef Triangulation::Face								  Face;

typedef std::list<Point_2>								  Point_list_2;
typedef std::list<c_Point_2>							  c_Point_list_2;
typedef std::list<p_Polygon_2>                            p_Pgn_list_2;
typedef std::list<Point_3>								  Point_list_3;
typedef std::list<Polygon_with_holes_2>                   Pwh_list_2;
typedef std::list<Polygon_2>							  Pgn_list_2;
typedef std::list<Nef_polyhedron>						  N_phd_list;
typedef std::list<Polyhedron>							  phd_list;
typedef std::vector<Full_cell_handle>					  Full_cells;
typedef std::vector<Face>								  Faces;

bool res_sort_nfp(std::vector<double> a, std::vector<double> b) {
	if (a[0] < b[0] + Epsilon && b[0] < a[0] + Epsilon)
		return a[1] < b[1];//如果目标函数一样，重合面积升序
	else
		return a[0] < b[0];//目标函数升序(小的放前面)
}

bool res_sort_ifp(std::vector<double> a, std::vector<double> b) {
	if (a[4] == b[4])
		return a[0] < b[0];//如果ifp编号一样，目标函数升序
	else
		return a[4] < b[4];//ifp编号升序(小的放前面)
}

//根据数组第一位（下标为0），升序排序（小的放前面）
bool res_sort_0(std::vector<double> a, std::vector<double> b) {
	return a[0] < b[0];//ifp编号升序(小的放前面)
}

int main()
{
	std::cout.precision(14);
	std::ofstream out_nfp;
	out_nfp.precision(14);
	out_nfp.open("D:/Ph.D/Code/Packing/data/packing/run_nfp.txt", std::ios::out);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
	out_nfp.close();
	std::ofstream out_coord;
	out_coord.precision(14);
	out_coord.open("D:/Ph.D/Code/Packing/data/packing/coord_fin.txt", std::ios::out);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
	out_coord.close();
	std::vector < c_Point_list_2 > vec_c_points_75 = input_polygons(75, "D:/Ph.D/Code/Packing/data/packing/poly/polygon_");
	std::vector < c_Point_list_2 > vec_c_points_albano_24 = input_polygons(24, "D:/Ph.D/Code/Packing/data/packing/albano/polygon_");
	std::vector < c_Point_list_2 > vec_c_points_jakobs_50 = input_polygons(50, "D:/Ph.D/Code/Packing/data/packing/jakobs/polygon_");

	FILE* fp;
	fp = fopen("D:/Ph.D/Code/Packing/data/packing/random_poly_0.txt", "r");
	std::vector<std::vector<double>> vec_cases;
	std::vector<std::vector<double>> vec_cases_albano;
	std::vector<std::vector<double>> vec_cases_jakobs;
	for (int i_case = 0; i_case < 100; ++i_case) {
		std::vector<double> vec_case(75);
		std::vector<double> vec_case_albano(24);
		std::vector<double> vec_case_jakobs(50);
		int i_id_albano = 0;
		int i_id_jakobs = 0;
		for (int i_id = 0; i_id < 75; ++i_id) {
			fscanf(fp, "%lf", &vec_case[i_id]);
			if (vec_case[i_id] < 24) {
				vec_case_albano[i_id_albano] = vec_case[i_id];
				i_id_albano++;
			}
			if (vec_case[i_id] < 50) {
				vec_case_jakobs[i_id_jakobs] = vec_case[i_id];
				i_id_jakobs++;
			}
		}
		vec_cases.push_back(vec_case);
		vec_cases_albano.push_back(vec_case_albano);
		vec_cases_jakobs.push_back(vec_case_jakobs);
	}

	int which_instance;
	//which_case = 0;
	std::cout << "请输入要使用哪一个问题，0为poly，1为albano，2为jakobs，按回车结束" << std::endl;
	std::cin >> which_instance;

	int polygon_num;
	if (which_instance != 1) {
		polygon_num = 30;
	}
	else {
		polygon_num = 24;
	}
	//std::cout << "请输入多边形数量，按回车结束" << std::endl;
	//std::cin >> polygon_num;

	double ang_step_size;
	ang_step_size = 30;
	//std::cout << "请输入角度步长，按回车结束" << std::endl;
	//std::cin >> ang_step_size;
	std::vector<double> ang_step_size_albano(polygon_num, 30);

	int which_case;
	//which_case = 0;
	std::cout << "请输入要使用哪一个随机序列（如使用1-30原始序列，输入10000），按回车结束" << std::endl;
	std::cin >> which_case;

	std::vector<double> polygons_symm_origin_jakobs = { 1,1,1,1,1,1,1,1,1,1,1,1,4,4,4,4,4,4,4,2,2,2,4,1,2,2,1,2,2,2,1,1,1,1,1,1,2,1,1,1,2,1,1,1,1,1,1,4,4,4 };

	std::vector<double> polygons_symm(polygon_num + 1, 1);

	int square_where;
	//which_case = 0;
	std::cout << "请输入要将空心正方形放在第几个，按回车结束" << std::endl;
	std::cin >> square_where;

	polygons_symm[square_where] = 4;

	Polygon_2 h_sq; // hollow square
	h_sq.push_back(Point_2(-5, -5));
	h_sq.push_back(Point_2(-0.15, -5));
	h_sq.push_back(Point_2(-0.15, -4));
	h_sq.push_back(Point_2(-4, -4));
	h_sq.push_back(Point_2(-4, 4));
	h_sq.push_back(Point_2(4, 4));
	h_sq.push_back(Point_2(4, -4));
	h_sq.push_back(Point_2(0.15, -4));
	h_sq.push_back(Point_2(0.15, -5));
	h_sq.push_back(Point_2(5, -5));
	h_sq.push_back(Point_2(5, 5));
	h_sq.push_back(Point_2(-5, 5));

	int square_rot;
	//which_case = 0;
	std::cout << "请输入要将空心正方形转几个九十度，按回车结束" << std::endl;
	std::cin >> square_rot;

	h_sq = Polygon_2_turn_acw(h_sq, PI * square_rot / 2);

	Polygon_with_holes_2 h_sq_pwh(h_sq);
	//CGAL::draw(h_sq_pwh);

	std::vector<c_Point_list_2> vec_c_points;
	if (which_instance == 0) {
		if (which_case == 10000) {
			for (int i_pgn = 0; i_pgn < polygon_num; ++i_pgn) {
				vec_c_points.push_back(vec_c_points_75[i_pgn]);
			}
		}
		else {
			for (int i_pgn = 0; i_pgn < polygon_num; ++i_pgn) {
				vec_c_points.push_back(vec_c_points_75[vec_cases[which_case][i_pgn]]);
			}
		}
	}
	else if (which_instance == 1) {
		for (int i_pgn = 0; i_pgn < polygon_num; ++i_pgn) {
			vec_c_points.push_back(vec_c_points_albano_24[vec_cases_albano[which_case][i_pgn]]);
			if (vec_cases_albano[which_case][i_pgn] >= 2 && vec_cases_albano[which_case][i_pgn] <= 3) {
				ang_step_size_albano[i_pgn] = 9;
			}
			else {
				if (vec_cases_albano[which_case][i_pgn] >= 8 && vec_cases_albano[which_case][i_pgn] <= 11) {
					ang_step_size_albano[i_pgn] = 20;
				}
			}
		}
	}
	else {
		for (int i_pgn = 0; i_pgn < polygon_num; ++i_pgn) {
			vec_c_points.push_back(vec_c_points_jakobs_50[vec_cases_jakobs[which_case][i_pgn]]);
			std::cout << vec_cases_jakobs[which_case][i_pgn] << " ";
			polygons_symm[i_pgn] = polygons_symm_origin_jakobs[vec_cases_jakobs[which_case][i_pgn]];
		}
		std::cout << std::endl;
	}

	double width;
	if (which_instance != 1) {
		width = 40;
	}
	else {
		width = 60;
	}
	//std::cout << "请输入箱子宽度，按回车结束" << std::endl;
	//std::cin >> width;
	double length;
	if (which_instance != 1) {
		length = 60;
	}
	else {
		length = 200;
	}
	//std::cout << "请输入箱子长度，按回车结束" << std::endl;
	//std::cin >> length;

	double alpha_obj;
	alpha_obj = 0.001;
	//std::cout << "请输入目标函数x+αy中的系数α，按回车结束" << std::endl;
	//std::cin >> alpha_obj;

	double beta_obj;
	beta_obj = 0.00001;
	//std::cout << "请输入目标函数中零件坐标x+y的系数β，按回车结束" << std::endl;
	//std::cin >> beta_obj;

	//非线性规划情况下，D-function，大概是最大的图形的最长的一条线的长度*sqrt(2)*length
	double big_m_nonlin = 2 * max(length, width) * max(length, width);

	double time_lim = 3600;

	std::vector<Polygon_with_holes_2> pwhs(polygon_num);
	std::vector<Polygon_2> pgns(polygon_num);
	std::vector<Polygon_2> pgns_trans(polygon_num);
	std::vector<Polygon_2> pgns_inset(polygon_num);
	//std::vector<std::list<Nef_polyhedron>> N_pgn_par_lists;
	std::vector<std::vector<double>> pgns_bbox;//每个图形都有一个四维变量，保存着minx，miny，maxx，maxy

	for (int i_p_num = 0; i_p_num < polygon_num; ++i_p_num) {
		std::vector<double> pgn_bbox;
		if (i_p_num != square_where) {
			//调整图形位置，后续需要
			pwhs[i_p_num] = init_min_c(vec_c_points[i_p_num], pgn_bbox);
			//对图形不进行旋转
			pgns[i_p_num] = pwhs[i_p_num].outer_boundary();
			pgns_inset[i_p_num] = Polygon_2_inset(pgns[i_p_num], 0.0001);
			//Polygon_set_2 S_1;
			//Polygon_set_2 S_2;
			//S_1.insert(pgns[i_p_num]);
			//S_2.insert(pgns_inset[i_p_num]);
			//S_1.difference(S_2);
			//CGAL::draw(S_2);
			//CGAL::draw(S_1);
			//CGAL::draw(pwhs[i_p_num]);
			pgn_bbox = bbox_cal(pgns[i_p_num]);
			pgns_bbox.push_back(pgn_bbox);
			//std::list<Nef_polyhedron> N_pgn_par_list;
			//decomp_2(pgns[i_p_num], N_pgn_par_list);
			//N_pgn_par_lists.push_back(N_pgn_par_list);
		}
		else {
			pwhs[i_p_num] = h_sq_pwh;
			pgn_bbox = { -5,-5,5,5 };
			//对图形不进行旋转
			pgns[i_p_num] = pwhs[i_p_num].outer_boundary();
			pgns_inset[i_p_num] = Polygon_2_inset(pgns[i_p_num], 0.0001);
			//CGAL::draw(pwhs[i_p_num]);
			pgn_bbox = bbox_cal(pgns[i_p_num]);
			pgns_bbox.push_back(pgn_bbox);
			//std::list<Nef_polyhedron> N_pgn_par_list;
			//decomp_2(pgns[i_p_num], N_pgn_par_list);
			//N_pgn_par_lists.push_back(N_pgn_par_list);
		}
	}

	std::vector<double> angles_o;//origin（用来对比的）
	angles_o.push_back(0);
	angles_o.push_back(PI / 2);
	angles_o.push_back(PI);
	angles_o.push_back(3 * PI / 2);

	//bin只包含箱子的形状
	std::vector<Polygon_with_holes_2> bin_pwh_vec;
	//Pwh_list_2                  ifp_pwh_list;
	std::vector<Polygon_with_holes_2>::const_iterator  it;

	Point_list_2 poi_box = { Point_2(-1, -1), Point_2(length + 1, -1),
			Point_2(length + 1, width + 1), Point_2(-1, width + 1) };
	Polygon_with_holes_2 ifp_box(Polygon_2(poi_box.begin(), poi_box.end()));
	Point_list_2 poi_bin = { Point_2(0, 0), Point_2(length, 0),
			Point_2(length, width), Point_2(0, width) };
	Polygon_with_holes_2 bin_pwh(Polygon_2(poi_bin.begin(), poi_bin.end()));
	bin_pwh_vec.push_back(bin_pwh);

	//ifp是将箱子挖空后的有孔多边形
	std::vector<Polygon_with_holes_2> ifp_pwh_vec;
	Polygon_with_holes_2 ifp_pwh;
	//如果报错说明difference结果不是一个图形，而是多个图形
	difference(ifp_box, bin_pwh, &ifp_pwh);
	ifp_pwh_vec.push_back(ifp_pwh);

	//CGAL::intersection(pgn_n, Polygon_2(poi_obj.begin(), poi_obj.end()), std::back_inserter(ifp_pwh_vec));
	std::vector<std::list<Nef_polyhedron>> N_pgn_par_lists;
	std::vector<std::vector<double>> coord_all;

	for (int i_p_num = 0; i_p_num < polygon_num; ++i_p_num) {

		if (which_instance == 0) {
			double min_ang = min_angle(pgns[i_p_num]);
			//std::cout << min_ang << std::endl;
			if (min_ang > 30) {
				ang_step_size = 30;
			}
			else {
				if (min_ang > 22.5) {
					ang_step_size = 22.5;
				}
				else {
					if (min_ang > 18) {
						ang_step_size = 18;
					}
					else {
						if (min_ang > 15) {
							ang_step_size = 15;
						}
						else {
							if (min_ang > 11.25) {
								ang_step_size = 11.25;
							}
							else {
								std::cout << "min_angle < 11.25" << std::endl;
							}
						}
					}
				}
			}
		}
		else if (which_instance == 1) {
			ang_step_size = ang_step_size_albano[i_p_num];
		}
		else if (which_instance == 2) {
			double min_ang = min_angle(pgns[i_p_num]);
			//std::cout << min_ang << std::endl;
			if (min_ang > 30) {
				if (vec_cases_jakobs[which_case][i_p_num] == 9 ||
					vec_cases_jakobs[which_case][i_p_num] == 20 ||
					vec_cases_jakobs[which_case][i_p_num] == 32)
				{
					ang_step_size = 22.5;
				}
				else
				{
					ang_step_size = 30;
				}
			}
			else {
				if (min_ang > 22.5) {
					ang_step_size = 22.5;
				}
				else {
					if (min_ang > 18) {
						ang_step_size = 18;
					}
					else {
						if (min_ang > 15) {
							ang_step_size = 15;
						}
						else {
							if (min_ang > 11.25) {
								ang_step_size = 11.25;
							}
							else {
								std::cout << "min_angle < 11.25" << std::endl;
							}
						}
					}
				}
			}
		}
		if (i_p_num == square_where) ang_step_size = 5;

		std::vector<std::vector<std::vector<double>>> poi_conv_pgns_bin;
		for (int i_p_con = 0; i_p_con < i_p_num; ++i_p_con) {
			std::vector<std::vector<std::vector<double>>> poi_conv_pgns_poly;
			std::vector<std::vector<std::vector<double>>> poi_conv_pgns_bin_temp = poi_conv_pgns_bin;
			poi_conv_pgns_bin.clear();
			poi_conv_pgns_bin = generate_poi_conv_pgn(pgns_trans[i_p_con]);
			std::merge(poi_conv_pgns_bin_temp.begin(), poi_conv_pgns_bin_temp.end(),
				poi_conv_pgns_poly.begin(), poi_conv_pgns_poly.end(), std::back_inserter(poi_conv_pgns_bin));
		}
		std::vector<std::vector<std::vector<double>>> poi_conv_pgns_n;
		poi_conv_pgns_n = generate_poi_conv_pgn(pgns[i_p_num]);

		std::cout << "bin convex = " << poi_conv_pgns_bin.size() << std::endl;
		std::cout << "n convex = " << poi_conv_pgns_n.size() << std::endl;

		std::vector<std::vector<double>> res_fin;

		DWORD t_nfp1 = GetTickCount64();
		//obj, ra_turn, lowerbound, upperbound, x_coord, y_coord, xobj, time, intersection, iteration
		std::vector<double> res_nfp(10);
		{
			std::vector<double> polygon_angles;
			init_angles(polygon_angles, ang_step_size, polygons_symm[i_p_num]);
			if (i_p_num == 0)
				polygon_angles = {180,195,210,225,240,255,270,285,300,315,330,345,360};
			std::vector<std::vector<double>> best_results(polygon_angles.size() - 1);
			std::vector<std::thread> t_ang(polygon_angles.size() - 1);
			for (int i_p_a = 0; i_p_a < polygon_angles.size() - 1; ++i_p_a) {
				t_ang[i_p_a] = std::thread([polygon_num, length, width, alpha_obj, i_p_num, i_p_a,
					polygon_angles, pwhs, pgns, N_pgn_par_lists, coord_all, &best_results] {
						std::vector<std::vector<std::vector<std::vector<double>>>> polygons_paras_nfps_nfp;
						std::vector<double> obj_nfp;
						std::vector<double> coord_nfp;
						double ra_turn_nfp;
						double intersection;

						try_program_nfp_one_by_one_single_ang(length, width, alpha_obj, i_p_num,
							polygon_angles[i_p_a], polygon_angles[i_p_a + 1], pwhs, pgns, N_pgn_par_lists,
							coord_all, obj_nfp, coord_nfp, ra_turn_nfp, intersection);

						best_results[i_p_a] = { obj_nfp[2], intersection, ra_turn_nfp,
							polygon_angles[i_p_a], polygon_angles[i_p_a + 1] };
					});
			}
			for (int i_p_a = 0; i_p_a < polygon_angles.size() - 1; ++i_p_a) {
				t_ang[i_p_a].join();
			}
			sort(best_results.begin(), best_results.end(), res_sort_nfp);

			std::vector<std::vector<std::vector<std::vector<double>>>> polygons_paras_nfps;
			std::vector<double> obj_ub;
			std::vector<double> coord_ub;
			double ra_turn_ub = best_results[0][2];

			try_program_one_by_one_no_turn(length, width, alpha_obj, i_p_num, pgns_inset, ra_turn_ub,
				coord_all, obj_ub, coord_ub);

			std::cout << "Intersection area = " << best_results[0][1] << std::endl;
			std::cout << "Obj difference = " << obj_ub[2] - best_results[0][0] << std::endl;

			//draw_whole_res(i_p_num, length, width, pgns, best_results[0][2], obj, coord);

			int it_num = 0;

			while (obj_ub[2] - best_results[0][0] > 0.001) {
				best_results.push_back({});
				best_results.push_back({});
				std::vector<std::thread> t_it(2);
				if (best_results[0][3] + 1 < best_results[0][2] / PI * 180 &&
					best_results[0][2] / PI * 180 + 1 < best_results[0][4])
				{
					t_it[0] = std::thread([polygon_num, length, width, alpha_obj, i_p_num,
						polygon_angles, pwhs, pgns, N_pgn_par_lists, coord_all, &best_results] {
							std::vector<std::vector<std::vector<std::vector<double>>>> polygons_paras_nfps_nfp_1;
							std::vector<double> obj_nfp_1;
							std::vector<double> coord_nfp_1;
							double ra_turn_nfp_1;
							double intersection_1;

							try_program_nfp_one_by_one_single_ang(length, width, alpha_obj, i_p_num,
								best_results[0][3], best_results[0][2] / PI * 180, pwhs, pgns, N_pgn_par_lists,
								coord_all, obj_nfp_1, coord_nfp_1, ra_turn_nfp_1, intersection_1);

							best_results[best_results.size() - 2] = { obj_nfp_1[2], intersection_1, ra_turn_nfp_1,
								best_results[0][3], best_results[0][2] / PI * 180 };
						});

					t_it[1] = std::thread([polygon_num, length, width, alpha_obj, i_p_num,
						polygon_angles, pwhs, pgns, N_pgn_par_lists, coord_all, &best_results] {
							std::vector<std::vector<std::vector<std::vector<double>>>> polygons_paras_nfps_nfp_2;
							std::vector<double> obj_nfp_2;
							std::vector<double> coord_nfp_2;
							double ra_turn_nfp_2;
							double intersection_2;

							try_program_nfp_one_by_one_single_ang(length, width, alpha_obj, i_p_num,
								best_results[0][2] / PI * 180, best_results[0][4], pwhs, pgns, N_pgn_par_lists,
								coord_all, obj_nfp_2, coord_nfp_2, ra_turn_nfp_2, intersection_2);

							best_results[best_results.size() - 1] = { obj_nfp_2[2], intersection_2, ra_turn_nfp_2,
								best_results[0][2] / PI * 180, best_results[0][4] };
						});
				}
				else {
					t_it[0] = std::thread([polygon_num, length, width, alpha_obj, i_p_num,
						polygon_angles, pwhs, pgns, N_pgn_par_lists, coord_all, &best_results] {
							std::vector<std::vector<std::vector<std::vector<double>>>> polygons_paras_nfps_nfp_1;
							std::vector<double> obj_nfp_1;
							std::vector<double> coord_nfp_1;
							double ra_turn_nfp_1;
							double intersection_1;

							try_program_nfp_one_by_one_single_ang(length, width, alpha_obj, i_p_num,
								best_results[0][3], (best_results[0][3] + best_results[0][4]) / 2,
								pwhs, pgns, N_pgn_par_lists, coord_all, obj_nfp_1, coord_nfp_1, ra_turn_nfp_1,
								intersection_1);

							best_results[best_results.size() - 2] = { obj_nfp_1[2], intersection_1, ra_turn_nfp_1,
								best_results[0][3], (best_results[0][3] + best_results[0][4]) / 2 };
						});

					t_it[1] = std::thread([polygon_num, length, width, alpha_obj, i_p_num,
						polygon_angles, pwhs, pgns, N_pgn_par_lists, coord_all, &best_results] {
							std::vector<std::vector<std::vector<std::vector<double>>>> polygons_paras_nfps_nfp_2;
							std::vector<double> obj_nfp_2;
							std::vector<double> coord_nfp_2;
							double ra_turn_nfp_2;
							double intersection_2;

							try_program_nfp_one_by_one_single_ang(length, width, alpha_obj, i_p_num,
								(best_results[0][3] + best_results[0][4]) / 2, best_results[0][4],
								pwhs, pgns, N_pgn_par_lists, coord_all, obj_nfp_2, coord_nfp_2, ra_turn_nfp_2,
								intersection_2);

							best_results[best_results.size() - 1] = { obj_nfp_2[2], intersection_2, ra_turn_nfp_2,
								(best_results[0][3] + best_results[0][4]) / 2, best_results[0][4] };
						});
				}

				t_it[0].join();
				t_it[1].join();
				best_results.erase(best_results.begin());

				sort(best_results.begin(), best_results.end(), res_sort_nfp);

				polygons_paras_nfps.clear();
				std::vector<double> obj_new;
				std::vector<double> coord_new;

				try_program_one_by_one_no_turn(length, width, alpha_obj, i_p_num, pgns_inset,
					best_results[0][2], coord_all, obj_new, coord_new);

				//std::vector<std::vector<double>> coord_all_temp = coord_all;
				//coord_all_temp.push_back(coord_new);
				//if (i_p_num >= 2)
				//	draw_whole_res(i_p_num, length, width, pgns, best_results[0][2], obj_new, coord_all_temp);

				if (obj_new[2] < obj_ub[2]) {
					ra_turn_ub = best_results[0][2];
					obj_ub = obj_new;
					coord_ub = coord_new;
				}
				//out_4d << "Intersection area = " << best_results[0][1] << "\n";
				//out_4d << "Obj low = " << best_results[0][0] << "\n";
				//out_4d << "Obj high = " << obj[2] << "\n";
				std::cout << "Intersection area = " << best_results[0][1] << std::endl;
				std::cout << "Obj difference = " << obj_ub[2] - best_results[0][0] << std::endl;
				it_num++;
			}
			std::cout << "Iteration time = " << it_num << std::endl;
			//draw_whole_res(i_p_num, length, width, pgns, ra_turn_ub, obj_ub, coord_ub);
			res_nfp[0] = obj_ub[2];
			res_nfp[1] = ra_turn_ub;
			res_nfp[2] = best_results[0][0];
			res_nfp[3] = obj_ub[2];
			res_nfp[4] = coord_ub[0];
			res_nfp[5] = coord_ub[1];
			res_nfp[6] = obj_ub[0];
			res_nfp[8] = best_results[0][1];
			res_nfp[9] = it_num;
		}
		DWORD t_nfp2 = GetTickCount64();
		res_nfp[7] = (t_nfp2 - t_nfp1) * 1.0 / 1000;
		res_fin.push_back(res_nfp);
		out_nfp.open("D:/Ph.D/Code/Packing/data/packing/run_nfp.txt", std::ios::out | std::ios::app);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
		for (int i = 0; i < res_nfp.size(); ++i) {
			out_nfp << res_nfp[i] << " ";
		}
		out_nfp << "\n";
		out_nfp.close();

		std::vector<double> obj_fin = { 0,0,res_fin[0][0] };
		std::vector<double> coord_fin = { res_fin[0][4], res_fin[0][5] };

		coord_all.push_back({ coord_fin[0], coord_fin[1] });

		out_coord.open("D:/Ph.D/Code/Packing/data/packing/coord_fin.txt", std::ios::out | std::ios::app);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
		out_coord << coord_fin[0] << " " << coord_fin[1] << " " << res_fin[0][1] << "\n";
		out_coord.close();

		for (int i_output_co = 0; i_output_co < coord_all.size(); ++i_output_co) {
			std::cout << coord_all[i_output_co][0] << " " << coord_all[i_output_co][1] << std::endl;
		}
		if (i_p_num >= polygon_num - 1)
			draw_whole_res(i_p_num, length, width, pgns, res_fin[0][1], obj_fin, coord_all);

		//为下一个图形做准备
		if (i_p_num < polygon_num - 1) {
			pgns[i_p_num] = Polygon_2_turn_acw(pgns[i_p_num], res_fin[0][1]);
			pgns_inset[i_p_num] = Polygon_2_turn_acw(pgns_inset[i_p_num], res_fin[0][1]);
			pgns_bbox[i_p_num] = bbox_cal(pgns[i_p_num]);
			pgns_trans[i_p_num] = Polygon_2_trans(pgns[i_p_num], coord_fin[0],
				coord_fin[1]);
			std::list<Nef_polyhedron> N_pgn_par_list;
			decomp_2(pgns_trans[i_p_num], N_pgn_par_list);
			N_pgn_par_lists.push_back(N_pgn_par_list);
		}

	}
	return 0;
}

/*
\n 换行符(LF)

\r 回车(CR) ，相当于键盘上的"Enter"

\t 跳到下一个TAB位置

\0 空字符(NULL)

\' 单引号（撇号）

\" 双引号

\\ 代表一个反斜线字符''\'

\ 继续符，可用于一行的结尾，表示本行与下一行连接起来
*/