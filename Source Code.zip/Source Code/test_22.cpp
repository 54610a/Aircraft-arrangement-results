﻿// 上汽项目程序
// 为了便于输出，必须更改输出目录
// 用于debug，目录固定
#include <list>
#include <iostream>
#include <fstream>
#include <cassert>
#include <algorithm>

#include <thread>

#include <Eigen/Dense>

#include <CGAL/IO/read_points.h>

#include <CGAL/Simple_cartesian.h>
#include <CGAL/Min_sphere_of_spheres_d.h>
#include <CGAL/Min_sphere_of_points_d_traits_2.h>
#include <CGAL/Random.h>

#include <CGAL/Exact_predicates_exact_constructions_kernel.h>
#include <CGAL/Polygon_2.h>
#include <CGAL/Polygon_with_holes_2.h>
#include <CGAL/Polygon_set_2.h>

#include <CGAL/Boolean_set_operations_2.h>

#include <CGAL/draw_polygon_set_2.h>
#include <CGAL/draw_polygon_2.h>
#include <CGAL/draw_polygon_with_holes_2.h>

#include <CGAL/Polyhedron_3.h>
#include <CGAL/Nef_polyhedron_3.h>
#include <CGAL/minkowski_sum_2.h>
#include <CGAL/minkowski_sum_3.h>
#include <CGAL/partition_2.h>
#include <CGAL/Partition_traits_2.h>
#include <CGAL/IO/Nef_polyhedron_iostream_3.h>
#include <CGAL/Nef_3/SNC_indexed_items.h>
#include <CGAL/convex_decomposition_3.h>
#include <CGAL/convex_hull_3.h>
#include <CGAL/approximated_offset_2.h>
#include <CGAL/Gps_circle_segment_traits_2.h>

#include <CGAL/draw_polyhedron.h>
#include <CGAL/draw_nef_3.h>

#include <CGAL/Epick_d.h>
#include <CGAL/Triangulation.h>

#include <draw_res.h>
#include <point_calculation.h>
#include <input_initialize.h>
#include <calculate_2d.h>
#include <calculate_3d.h>
#include <generate_para_2d.h>
#include <generate_para_3d.h>
#include <generate_para_4d.h>
#include <test_draw.h>
#include <draw_whole_res.h>
#include <simple_cal.h>


#define PI 3.1415926535

#define Epsilon 0.00000001

typedef CGAL::Exact_predicates_exact_constructions_kernel K;
typedef CGAL::Polygon_2<K>                                Polygon_2;
typedef CGAL::Polygon_with_holes_2<K>                     Polygon_with_holes_2;
typedef CGAL::Polygon_set_2<K>                            Polygon_set_2;
typedef CGAL::Point_2<K>                                  Point_2;
typedef CGAL::Vector_2<K>                                 Vector_2;
typedef CGAL::Point_3<K>                                  Point_3;
typedef CGAL::Polyhedron_3<K>							  Polyhedron;
typedef CGAL::Nef_polyhedron_3<K>						  Nef_polyhedron;
//typedef K::Point_2										  Point;
using std::cout;
using std::endl;

typedef CGAL::Simple_cartesian<double>                   c_K;//引自参考min_circle_2的例子
typedef CGAL::Min_sphere_of_points_d_traits_2<c_K, double>   c_Traits;
typedef CGAL::Min_sphere_of_spheres_d<c_Traits>            Min_circle;
typedef CGAL::Point_2<c_K>                                 c_Point_2;
typedef CGAL::Polygon_2<c_K>                                c_Polygon_2;
typedef c_K::Point_3									   input_Point;

typedef CGAL::Partition_traits_2<K>                         Traits;
typedef Traits::Polygon_2                                   p_Polygon_2;
typedef Traits::Point_2                                     p_Point_2;

typedef Polygon_2::Vertex_iterator						  VertexIterator;
typedef Polygon_2::Edge_const_iterator					  EdgeIterator;
typedef p_Polygon_2::Vertex_iterator					  p_VertexIterator;
typedef Nef_polyhedron::Volume_const_iterator			  Volume_const_iterator;
typedef Polyhedron::Vertex_iterator						  phd_VertexIterator;
typedef Polyhedron::Facet_iterator					      phd_FacetIterator;
//typedef Nef_polyhedron::Vertex_iterator					  N_phd_VertexIterator;
typedef Nef_polyhedron::Aff_transformation_3			  Aff_transformation_3;
typedef Polyhedron::Halfedge_around_facet_circulator	  Halfedge_facet_circulator;

typedef CGAL::Epick_d<CGAL::Dynamic_dimension_tag>		  D_dim;
typedef CGAL::Triangulation<D_dim>                        Triangulation;
typedef CGAL::Triangulation_data_structure<D_dim>         TDS;
typedef Triangulation::Point			                  D_dim_point;
typedef Triangulation::Full_cell_handle					  Full_cell_handle;
typedef Triangulation::Facet							  Facet;
typedef Triangulation::Face								  Face;

typedef std::list<Point_2>								  Point_list_2;
typedef std::list<c_Point_2>							  c_Point_list_2;
typedef std::list<p_Polygon_2>                            p_Pgn_list_2;
typedef std::list<Point_3>								  Point_list_3;
typedef std::list<Polygon_with_holes_2>                   Pwh_list_2;
typedef std::list<Polygon_2>							  Pgn_list_2;
typedef std::list<Nef_polyhedron>						  N_phd_list;
typedef std::list<Polyhedron>							  phd_list;
typedef std::vector<Full_cell_handle>					  Full_cells;
typedef std::vector<Face>								  Faces;

typedef CGAL::Gps_circle_segment_traits_2<K>			Traits_gps;
typedef Traits_gps::Polygon_2							Polygon_2_gps;
typedef Traits_gps::Polygon_with_holes_2                Polygon_with_holes_2_gps;

bool res_sort_nfp(std::vector<double> a, std::vector<double> b) {
	if (a[0] < b[0] + Epsilon && b[0] < a[0] + Epsilon)
		return a[1] < b[1];//如果目标函数一样，重合面积升序
	else
		return a[0] < b[0];//目标函数升序(小的放前面)
}

bool res_sort_ifp(std::vector<double> a, std::vector<double> b) {
	if (a[4] == b[4])
		return a[0] < b[0];//如果ifp编号一样，目标函数升序
	else
		return a[4] < b[4];//ifp编号升序(小的放前面)
}

//根据数组第一位（下标为0），升序排序（小的放前面）
bool res_sort_0(std::vector<double> a, std::vector<double> b) {
	return a[0] < b[0];//ifp编号升序(小的放前面)
}

int main()
{
	std::ofstream out_poi;
	out_poi.precision(50);

	int n_piece;
	n_piece = 0;
	std::cout << "请输入共有多少个小零件，按回车结束" << std::endl;
	std::cin >> n_piece;

	int n_sheet;
	n_sheet = 0;
	std::cout << "请输入共有多少块边角料，按回车结束" << std::endl;
	std::cin >> n_sheet;

	int eve_n;
	eve_n = 2;
	std::cout << "请输入选择几个均分角度进行比较，按回车结束" << std::endl;
	std::cin >> eve_n;

	int whe_allow_flip;
	whe_allow_flip = 0;
	std::cout << "请输入是否允许镜像（1为允许，0为不允许），按回车结束" << std::endl;
	std::cin >> whe_allow_flip;

	int offset_amount;
	offset_amount = 0;
	std::cout << "请输入需要留的间隙大小，按回车结束" << std::endl;
	std::cin >> offset_amount;

	for (int i_sheet = 1; i_sheet <= n_sheet; ++i_sheet) {
		double s_id, s_n_holes;
		Polygon_2 sheet = input_pgn_from_txt_shangqi("D:/Ph.D/Code/Packing/data/packing/shang qi test/Sheets/sheet " + std::to_string(i_sheet) + ".txt", s_id, s_n_holes);
		//Polygon_2 sheet = input_pgn_from_txt_shangqi("../Data/Sheets/sheet " + std::to_string(i_sheet) + ".txt", s_id, s_n_holes);
		double x_s_min = 1000000, x_s_max = -1000000, y_s_min = 1000000, y_s_max = -1000000;
		for (VertexIterator vi = sheet.vertices_begin(); vi != sheet.vertices_end(); ++vi) {
			double vi_x = to_double(vi->x().approx());
			double vi_y = to_double(vi->y().approx());
			if (vi_x < x_s_min) x_s_min = vi_x;
			if (vi_x > x_s_max) x_s_max = vi_x;
			if (vi_y < y_s_min) y_s_min = vi_y;
			if (vi_y > y_s_max) y_s_max = vi_y;
		}
		double xmid = 0.5 * x_s_max + 0.5 * x_s_min;
		double ymid = 0.4 * y_s_max + 0.6 * y_s_min;
		Polygon_2 sheet_change;
		sheet_change.push_back(Point_2(x_s_min-1, ymid-1));
		sheet_change.push_back(Point_2(x_s_min-1, y_s_max+1));
		sheet_change.push_back(Point_2(x_s_max+1, y_s_max+1));
		sheet_change.push_back(Point_2(x_s_max+1, ymid-1));

		Polygon_set_2 sheet_change_set;
		sheet_change_set.insert(sheet_change);
		sheet_change_set.join(sheet);

		std::list<Polygon_with_holes_2> res;
		sheet_change_set.polygons_with_holes(std::back_inserter(res));
		//sheet = res.begin()->outer_boundary();
		//CGAL::draw(sheet);

		std::vector<Polygon_2> s_holes;
		for (int i_p_num = 0; i_p_num < s_n_holes; ++i_p_num) {
			s_holes.push_back(input_hole_from_txt_shangqi("D:/Ph.D/Code/Packing/data/packing/shang qi test/Sheets/sheet " + std::to_string(i_sheet) + " hole " + std::to_string(i_p_num + 1) + ".txt"));
			//s_holes.push_back(input_hole_from_txt_shangqi("../Data/Sheets/sheet " + std::to_string(i_sheet) + " hole " + std::to_string(i_p_num + 1) + ".txt"));
		}

		for (int i_piece = 1; i_piece <= n_piece; ++i_piece) {
			std::vector<double> res_data;
			double p_id, p_n_holes;
			Polygon_2 piece = input_pgn_from_txt_shangqi("D:/Ph.D/Code/Packing/data/packing/shang qi test/Pieces/piece " + std::to_string(i_piece) + ".txt", p_id, p_n_holes);
			//Polygon_2 piece = input_pgn_from_txt_shangqi("../Data/Pieces/piece " + std::to_string(i_piece) + ".txt", p_id, p_n_holes);
			double x_p_min = 1000000, x_p_max = -1000000, y_p_min = 1000000, y_p_max = -1000000;
			for (VertexIterator vi = piece.vertices_begin(); vi != piece.vertices_end(); ++vi) {
				double vi_x = to_double(vi->x().approx());
				double vi_y = to_double(vi->y().approx());
				if (vi_x < x_p_min) x_p_min = vi_x;
				if (vi_x > x_p_max) x_p_max = vi_x;
				if (vi_y < y_p_min) y_p_min = vi_y;
				if (vi_y > y_p_max) y_p_max = vi_y;
			}
			double bbox_max = std::max({x_p_max, -x_p_min, y_p_max, -y_p_min});

			Polygon_2 piece_offset = Polygon_2_offset(piece, offset_amount);
			//CGAL::draw(piece_offset);

			std::vector<Polygon_2> p_holes;
			for (int i_p_num = 0; i_p_num < p_n_holes; ++i_p_num) {
				p_holes.push_back(input_hole_from_txt_shangqi("D:/Ph.D/Code/Packing/data/packing/shang qi test/Pieces/piece " + std::to_string(i_piece) + " hole " + std::to_string(i_p_num + 1) + ".txt"));
				//p_holes.push_back(input_hole_from_txt_shangqi("../Data/Pieces/piece " + std::to_string(i_piece) + " hole " + std::to_string(i_p_num + 1) + ".txt"));
			}

			std::cout << i_sheet << " " << s_id << " " << i_piece << " " << p_id << std::endl;

			if (piece_offset.area() >= sheet.area()) {
				res_data = { double(i_sheet), s_id, double(i_piece), p_id, double(eve_n), 0, 0, 0, 0, 0 };
				std::string ad_str = "D:/Ph.D/Code/Packing/data/packing/shang qi test/result.txt";
				//std::string ad_str = "../Data/result.txt";
				out_poi.open(ad_str.c_str(), std::ios::out | std::ios::app);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
				for (int i = 0; i < res_data.size(); ++i)
					out_poi << res_data[i] << " ";
				out_poi << "\n";
				out_poi.close();
				std::cout << "零件面积大于边角料，无法放置" << std::endl;
				continue;
			}

			double big_M = 2 * std::max({ abs(x_s_max), abs(y_s_max), abs(-x_s_min), abs(-y_s_min) }) + 2 * bbox_max;
			Polygon_2 sheet_frame;
			sheet_frame.push_back(Point_2(-big_M, -big_M));
			sheet_frame.push_back(Point_2(-big_M, big_M));
			sheet_frame.push_back(Point_2(big_M, big_M));
			sheet_frame.push_back(Point_2(big_M, -big_M));

			//std::cout << sheet_frame << std::endl;
			//std::cout << sheet << std::endl;
			//CGAL::draw(sheet);
			Polygon_set_2 sheet_ring_set;
			sheet_ring_set.insert(sheet_frame);
			//CGAL::draw(sheet_ring_set);
			sheet_ring_set.difference(sheet);
			//CGAL::draw(sheet_ring_set);

			std::list<Polygon_with_holes_2> res;
			sheet_ring_set.polygons_with_holes(std::back_inserter(res));
			Polygon_with_holes_2 sheet_ring = *res.begin();
			//std::cout << sheet_ring << std::endl;
			//CGAL::draw(sheet_ring);

			double best_ang = 0, best_xmax = big_M, best_ymax = big_M,
				best_x_co = 0, best_y_co = 0;
			int whe_fit = 0, best_whe_flip = 0;

			for (int i_eve = 0; i_eve < eve_n; ++i_eve) {
				double ang_r = 2.0 * PI / eve_n * i_eve;
				piece_whe_fit_sheet(piece_offset, ang_r, p_holes, p_n_holes, s_holes, s_n_holes, sheet_ring,
					x_s_min, x_s_max, y_s_min, y_s_max, big_M, 0, whe_fit, best_whe_flip,
					best_xmax, best_ymax, best_ang, best_x_co, best_y_co);

				if (whe_allow_flip == 1) {
					piece_whe_fit_sheet(piece_offset, ang_r, p_holes, p_n_holes, s_holes, s_n_holes, sheet_ring,
						x_s_min, x_s_max, y_s_min, y_s_max, big_M, 1, whe_fit, best_whe_flip,
						best_xmax, best_ymax, best_ang, best_x_co, best_y_co);
				}

				/*
				Polygon_2 piece_r = Polygon_2_turn_acw(piece, PI + ang_r);
				std::vector<Polygon_2> p_holes_r;
				for (int i_p_num = 0; i_p_num < p_n_holes; ++i_p_num) {
					p_holes_r.push_back(Polygon_2_turn_acw(p_holes[i_p_num], PI + ang_r));
				}

				Polygon_set_2 piece_draw;
				piece_draw.insert(piece_r);
				for (int i_p_num = 0; i_p_num < p_n_holes; ++i_p_num) {
					piece_draw.difference(p_holes_r[i_p_num]);
				}
				//CGAL::draw(piece_draw);

				std::list<Polygon_with_holes_2> res_p;
				piece_draw.polygons_with_holes(std::back_inserter(res_p));
				Polygon_with_holes_2 piece_pwh = *res_p.begin();
				//std::cout << piece_pwh << std::endl;
				//CGAL::draw(piece_pwh);

				Polygon_with_holes_2 mink_res_sp = CGAL::minkowski_sum_2(sheet_ring, piece_pwh);
				//std::cout << mink_res_sp << std::endl;
				//CGAL::draw(mink_res_sp);

				std::vector<Polygon_with_holes_2> hole_nfps;
				for (int i_p_num = 0; i_p_num < s_n_holes; ++i_p_num) {
					Polygon_with_holes_2 mink_res_hp = CGAL::minkowski_sum_2(s_holes[i_p_num], piece_pwh);
					hole_nfps.push_back(mink_res_hp);
				}

				Polygon_2 sheet_diff;
				sheet_diff.push_back(Point_2(x_s_min, y_s_min));
				sheet_diff.push_back(Point_2(x_s_min, y_s_max));
				sheet_diff.push_back(Point_2(x_s_max, y_s_max));
				sheet_diff.push_back(Point_2(x_s_max, y_s_min));

				Polygon_set_2 mink_res_diff;
				mink_res_diff.insert(sheet_diff);
				mink_res_diff.difference(mink_res_sp);
				for (int i_p_num = 0; i_p_num < s_n_holes; ++i_p_num) {
					mink_res_diff.difference(hole_nfps[i_p_num]);
				}
				//CGAL::draw(mink_res_diff);

				if (!mink_res_diff.is_empty()) {
					whe_fit = 1;
					std::list<Polygon_with_holes_2> mink_set_res;
					mink_res_diff.polygons_with_holes(std::back_inserter(mink_set_res));
					double x_res = x_s_max, y_res = y_s_max;
					for (auto it = mink_set_res.begin(); it != mink_set_res.end(); ++it) {
						Polygon_2 ob = it->outer_boundary();
						for (VertexIterator vi = ob.vertices_begin(); vi != ob.vertices_end(); ++vi) {
							double vi_x = to_double(vi->x().approx());
							double vi_y = to_double(vi->y().approx());
							if (vi_x < x_res) {
								x_res = vi_x;
								y_res = vi_y;
							}
							else if (vi_x == x_res && vi_y < y_res) {
								x_res = vi_x;
								y_res = vi_y;
							}
						}
					}

					double piece_xmax = x_s_min, piece_ymax = y_s_min;
					Polygon_2 pgn_res = Polygon_2_trans(Polygon_2_turn_acw(piece, ang_r), x_res, y_res);
					for (VertexIterator vi = pgn_res.vertices_begin(); vi != pgn_res.vertices_end(); ++vi) {
						double vi_x = to_double(vi->x().approx());
						double vi_y = to_double(vi->y().approx());
						if (vi_x > piece_xmax) {
							piece_xmax = vi_x;
						}
						if (vi_y > piece_ymax) {
							piece_ymax = vi_y;
						}
					}

					if (piece_xmax < best_xmax) {
						best_ang = ang_r;
						best_xmax = piece_xmax;
						best_ymax = piece_ymax;
						best_x_co = x_res;
						best_y_co = y_res;
					}
					else if (piece_xmax == best_xmax && piece_ymax < best_ymax) {
						best_ang = ang_r;
						best_xmax = piece_xmax;
						best_ymax = piece_ymax;
						best_x_co = x_res;
						best_y_co = y_res;
					}
				}
				*/
			}
			if (whe_fit == 1) {
				double best_ang_d = best_ang / (2.0 * PI) * 360;

				//i_sheet, s_id, i_piece, p_id, eve_n, whe_fit, best_ang_d, best_x_co, best_y_co
				res_data = { double(i_sheet), s_id, double(i_piece), p_id, double(eve_n), double(whe_fit), double(best_whe_flip), best_ang_d, best_x_co, best_y_co };

				//*
				Polygon_set_2 fin_res;
				fin_res.insert(sheet);
				for (int i_p_num = 0; i_p_num < s_n_holes; ++i_p_num) {
					fin_res.difference(s_holes[i_p_num]);
				}
				if (best_whe_flip == 0) {
					fin_res.difference(Polygon_2_trans(Polygon_2_turn_acw(piece, best_ang), best_x_co, best_y_co));
					for (int i_p_num = 0; i_p_num < p_n_holes; ++i_p_num) {
						fin_res.join(Polygon_2_trans(Polygon_2_turn_acw(p_holes[i_p_num], best_ang), best_x_co, best_y_co));
					}
				}
				else {
					fin_res.difference(Polygon_2_trans(Polygon_2_turn_acw(Polygon_2_flip(piece), best_ang), best_x_co, best_y_co));
					for (int i_p_num = 0; i_p_num < p_n_holes; ++i_p_num) {
						fin_res.join(Polygon_2_trans(Polygon_2_turn_acw(Polygon_2_flip(p_holes[i_p_num]), best_ang), best_x_co, best_y_co));
					}
				}
				//*/

				//CGAL::draw(fin_res);

				std::vector<Polygon_2> sheet_v_draw;
				sheet_v_draw.push_back(sheet);
				for (int i_p_num = 0; i_p_num < s_n_holes; ++i_p_num)
					sheet_v_draw.push_back(s_holes[i_p_num]);
				std::vector<Polygon_2> piece_v_draw;
				if (best_whe_flip == 0) {
					piece_v_draw.push_back(Polygon_2_trans(Polygon_2_turn_acw(piece, best_ang), best_x_co, best_y_co));
					for (int i_p_num = 0; i_p_num < p_n_holes; ++i_p_num)
						piece_v_draw.push_back(Polygon_2_trans(Polygon_2_turn_acw(p_holes[i_p_num], best_ang), best_x_co, best_y_co));
				}
				else {
					piece_v_draw.push_back(Polygon_2_trans(Polygon_2_turn_acw(Polygon_2_flip(piece), best_ang), best_x_co, best_y_co));
					for (int i_p_num = 0; i_p_num < p_n_holes; ++i_p_num)
						piece_v_draw.push_back(Polygon_2_trans(Polygon_2_turn_acw(Polygon_2_flip(p_holes[i_p_num]), best_ang), best_x_co, best_y_co));
				}

				std::vector<Polygon_2> Ps1 = sheet_v_draw;
				std::vector<Polygon_2> Ps2 = piece_v_draw;
				std::string filename = "D:/Ph.D/Code/Packing/data/packing/shang qi test/Results/result sheet " + std::to_string(i_sheet) + " piece " + std::to_string(i_piece) + ".svg";
				//std::string filename = "../Data/Results/result sheet " + std::to_string(i_sheet) + " piece " + std::to_string(i_piece) + ".svg";
				std::cout << "可以放置" << std::endl;
				save_polygon_as_svg(Ps1, Ps2, x_s_max, x_s_min, y_s_max, y_s_min, filename);
			}
			else {
				std::cout << "无法放置" << std::endl;
				res_data = { double(i_sheet), s_id, double(i_piece), p_id, double(eve_n), 0, 0, 0, 0, 0 };
			}
			std::string ad_str = "D:/Ph.D/Code/Packing/data/packing/shang qi test/result.txt";
			//std::string ad_str = "../Data/result.txt";
			out_poi.open(ad_str.c_str(), std::ios::out | std::ios::app);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
			for (int i = 0; i < res_data.size(); ++i)
				out_poi << res_data[i] << " ";
			out_poi << "\n";
			out_poi.close();
		}
	}
	std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
	std::cout << "程序已执行完毕，按回车键关闭窗口" << std::endl;
	std::cin.get();
	return 0;
}

/*
\n 换行符(LF)

\r 回车(CR) ，相当于键盘上的"Enter"

\t 跳到下一个TAB位置

\0 空字符(NULL)

\' 单引号（撇号）

\" 双引号

\\ 代表一个反斜线字符''\'

\ 继续符，可用于一行的结尾，表示本行与下一行连接起来
*/