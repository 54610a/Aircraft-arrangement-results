﻿//尝试plane with key points数据集，只用2D NFP，使用已计算好的nfp，用nfp area选择最优位置和旋转角度
#include <list>
#include <iostream>
#include <fstream>
#include <cassert>

#include <thread>

#include <ilcplex\ilocplex.h>
ILOSTLBEGIN // 等同于 using namespace std; 声明命名空间

#include <Eigen/Dense>

#include <CGAL/IO/read_points.h>

#include <CGAL/Simple_cartesian.h>
#include <CGAL/Min_sphere_of_spheres_d.h>
#include <CGAL/Min_sphere_of_points_d_traits_2.h>
#include <CGAL/Random.h>

#include <CGAL/Exact_predicates_exact_constructions_kernel.h>
#include <CGAL/Polygon_2.h>
#include <CGAL/Polygon_with_holes_2.h>
#include <CGAL/Polygon_set_2.h>

#include <CGAL/Boolean_set_operations_2.h>

#include <CGAL/draw_polygon_set_2.h>
#include <CGAL/draw_polygon_2.h>
#include <CGAL/draw_polygon_with_holes_2.h>

#include <CGAL/Polyhedron_3.h>
#include <CGAL/Nef_polyhedron_3.h>
#include <CGAL/minkowski_sum_2.h>
#include <CGAL/minkowski_sum_3.h>
#include <CGAL/partition_2.h>
#include <CGAL/Partition_traits_2.h>
#include <CGAL/IO/Nef_polyhedron_iostream_3.h>
#include <CGAL/Nef_3/SNC_indexed_items.h>
#include <CGAL/convex_decomposition_3.h>
#include <CGAL/convex_hull_3.h>

#include <CGAL/draw_polyhedron.h>
#include <CGAL/draw_nef_3.h>

#include <CGAL/Epick_d.h>
#include <CGAL/Triangulation.h>

#include "gurobi_c++.h"

#include <draw_res.h>
#include <point_calculation.h>
#include <input_initialize.h>
#include <calculate_2d.h>
#include <calculate_3d.h>
#include <generate_para_2d.h>
#include <generate_para_3d.h>
#include <generate_para_4d.h>
#include <test_draw.h>
#include <try_program.h>
#include <draw_whole_res.h>
#include <scip_program.h>
#include <gurobi_program.h>
#include <simple_cal.h>


#define PI 3.1415926535

#define Epsilon 0.00000001

typedef CGAL::Exact_predicates_exact_constructions_kernel K;
typedef CGAL::Polygon_2<K>                                Polygon_2;
typedef CGAL::Polygon_with_holes_2<K>                     Polygon_with_holes_2;
typedef CGAL::Polygon_set_2<K>                            Polygon_set_2;
typedef CGAL::Point_2<K>                                  Point_2;
typedef CGAL::Vector_2<K>                                 Vector_2;
typedef CGAL::Point_3<K>                                  Point_3;
typedef CGAL::Polyhedron_3<K>							  Polyhedron;
typedef CGAL::Nef_polyhedron_3<K>						  Nef_polyhedron;
//typedef K::Point_2										  Point;
using std::cout;
using std::endl;

typedef CGAL::Simple_cartesian<double>                   c_K;//引自参考min_circle_2的例子
typedef CGAL::Min_sphere_of_points_d_traits_2<c_K, double>   c_Traits;
typedef CGAL::Min_sphere_of_spheres_d<c_Traits>            Min_circle;
typedef CGAL::Point_2<c_K>                                 c_Point_2;
typedef CGAL::Polygon_2<c_K>                                c_Polygon_2;
typedef c_K::Point_3									   input_Point;

typedef CGAL::Partition_traits_2<K>                         Traits;
typedef Traits::Polygon_2                                   p_Polygon_2;
typedef Traits::Point_2                                     p_Point_2;

typedef Polygon_2::Vertex_iterator						  VertexIterator;
typedef Polygon_2::Edge_const_iterator					  EdgeIterator;
typedef p_Polygon_2::Vertex_iterator					  p_VertexIterator;
typedef Nef_polyhedron::Volume_const_iterator			  Volume_const_iterator;
typedef Polyhedron::Vertex_iterator						  phd_VertexIterator;
typedef Polyhedron::Facet_iterator					      phd_FacetIterator;
//typedef Nef_polyhedron::Vertex_iterator					  N_phd_VertexIterator;
typedef Nef_polyhedron::Aff_transformation_3			  Aff_transformation_3;
typedef Polyhedron::Halfedge_around_facet_circulator	  Halfedge_facet_circulator;

typedef CGAL::Epick_d<CGAL::Dynamic_dimension_tag>		  D_dim;
typedef CGAL::Triangulation<D_dim>                        Triangulation;
typedef CGAL::Triangulation_data_structure<D_dim>         TDS;
typedef Triangulation::Point			                  D_dim_point;
typedef Triangulation::Full_cell_handle					  Full_cell_handle;
typedef Triangulation::Facet							  Facet;
typedef Triangulation::Face								  Face;

typedef std::list<Point_2>								  Point_list_2;
typedef std::list<c_Point_2>							  c_Point_list_2;
typedef std::list<p_Polygon_2>                            p_Pgn_list_2;
typedef std::list<Point_3>								  Point_list_3;
typedef std::list<Polygon_with_holes_2>                   Pwh_list_2;
typedef std::list<Polygon_2>							  Pgn_list_2;
typedef std::list<Nef_polyhedron>						  N_phd_list;
typedef std::list<Polyhedron>							  phd_list;
typedef std::vector<Full_cell_handle>					  Full_cells;
typedef std::vector<Face>								  Faces;

bool res_sort_nfp(std::vector<double> a, std::vector<double> b) {
	if (a[0] < b[0] + Epsilon && b[0] < a[0] + Epsilon)
		return a[1] < b[1];//如果目标函数一样，重合面积升序
	else
		return a[0] < b[0];//目标函数升序(小的放前面)
}

bool res_sort_ifp(std::vector<double> a, std::vector<double> b) {
	if (a[4] == b[4])
		return a[0] < b[0];//如果ifp编号一样，目标函数升序
	else
		return a[4] < b[4];//ifp编号升序(小的放前面)
}

//根据数组第一位（下标为0），升序排序（小的放前面）
bool res_sort_0(std::vector<double> a, std::vector<double> b) {
	return a[0] < b[0];//ifp编号升序(小的放前面)
}

int main()
{
	std::ofstream out_num;
	out_num.precision(14);

	double obj_ang;
	obj_ang = 0;
	//std::cout << "请输入目标函数角度（弧度制），按回车结束" << std::endl;
	//std::cin >> obj_ang;
	double x_para = cos(obj_ang);
	double y_para = sin(obj_ang);
	//std::cout << sin(PI/2) << std::endl;

	std::vector<int> sheet_holes = { 3,2,3,3,6 };

	int eve_n;
	//eve_n = 8;
	//std::cout << "请输入选择几个均分角度进行比较，按回车结束" << std::endl;
	//std::cin >> eve_n;

	int id_piece;
	//id_piece = 0;
	//std::cout << "请输入要使用哪一个零件（编号1-9），按回车结束" << std::endl;
	//std::cin >> id_piece;

	int id_sheet;
	//id_sheet = 0;
	//std::cout << "请输入要使用哪一块板材（编号1-5），按回车结束" << std::endl;
	//std::cin >> id_sheet;

	int i_draw;
	std::cout << "请输入是否只需要绘图（0为计算求解，1为读取结果绘图），按回车结束" << std::endl;
	std::cin >> i_draw;

	int i_obj;
	//i_obj = 0;
	std::cout << "请输入使用什么目标函数筛选位置（0为靠固定方向启发式；1为随机方向启发式；2为遍历顶点计算feasible面积；\
		3为使用圆周方向筛选顶点后计算feasible面积，以最大nfp面积最大为目标函数；4为使用圆周方向筛选顶点后计算feasible面积，以最小降低nfp面积最小为目标函数；\
		5为使用圆周方向筛选顶点后计算feasible面积，以最小降低nfp面积比例最小为目标函数；6为使用圆周方向筛选顶点后计算feasible面积，以最小nfp面积最大为目标函数；\
		7为使用圆周方向筛选顶点后计算feasible面积，以最大降低nfp面积最小为目标函数；8为使用圆周方向筛选顶点后计算feasible面积，以最大降低nfp面积比例最小为目标函数）；\
		9为使用圆周方向筛选顶点后计算feasible面积，以平均nfp面积最大为目标函数；10为使用圆周方向筛选顶点后计算feasible面积，以平均降低nfp面积最小为目标函数；\
		11为使用圆周方向筛选顶点后计算feasible面积，以平均降低nfp面积比例最小为目标函数；12为LLM1；13为LLM2；14为LLM3；15为LLM4；16为LLM5；\
		17为LLM6；18为LLM7；19为LLM8；20为LLM9；21为LLM10；22为LLM11；23为LLM15；24为LLM16；25为LLM17；26为LLM18；27为LLM19；28为LLM20；\
		1001为0-1，1011为1-1等等；按回车结束" << std::endl;
	std::cin >> i_obj;

	int i_obj_start;
	std::cout << "请输入目标函数起点，按回车结束" << std::endl;
	std::cin >> i_obj_start;

	int i_obj_end;
	std::cout << "请输入目标函数终点，按回车结束" << std::endl;
	std::cin >> i_obj_end;

	if (i_draw == 0) {
		int i_all;
		//i_all = 0;
		std::cout << "请输入是否搜索到超过当前最优就停止（0为全部搜索，1为搜索到超过当前最优就停止），按回车结束" << std::endl;
		std::cin >> i_all;

		int id_piece_start = 1;
		//i_all = 0;

		int id_piece_end = 5;
		//i_all = 0;

		int id_sheet_start = 1;
		//i_all = 0;

		int id_sheet_end = 4;
		//i_all = 0;

		int id_p_s_set;
		std::cout << "请输入搜索的零件板材组合（0为自定义；1为零件1-5，板材1-4；2为零件6-9，板材5），按回车结束" << std::endl;
		std::cin >> id_p_s_set;

		if (id_p_s_set == 0) {
			std::cout << "请输入搜索的零件范围起点（编号1-9），按回车结束" << std::endl;
			std::cin >> id_piece_start;
			std::cout << "请输入搜索的零件范围终点（编号1-9），按回车结束" << std::endl;
			std::cin >> id_piece_end;
			std::cout << "请输入搜索的板材范围起点（编号1-5），按回车结束" << std::endl;
			std::cin >> id_sheet_start;
			std::cout << "请输入搜索的板材范围终点（编号1-5），按回车结束" << std::endl;
			std::cin >> id_sheet_end;
		}
		if (id_p_s_set == 1) {
			id_piece_start = 1;
			id_piece_end = 5;
			id_sheet_start = 1;
			id_sheet_end = 4;
		}
		if (id_p_s_set == 2) {
			id_piece_start = 6;
			id_piece_end = 9;
			id_sheet_start = 5;
			id_sheet_end = 5;
		}

		int id_eve_set;
		std::cout << "请输入搜索的角度区间组合（0为自定义；1为{8,12,18,36,72}；2为{90,120,180}；3为两者合并；4为{1,2,3,4,5,6,8,9,10,12,15,18}；5为{1,2,3,4,5,6,8,9,10,12,15,18,20,24,30,36,40,45,60,72,90,120,180}），按回车结束" << std::endl;
		std::cin >> id_eve_set;

		std::vector<int> eve_n_vec;

		if (id_eve_set == 0) {
			int eve_vec_len;
			std::cout << "请输入角度区间等级个数，按回车结束" << std::endl;
			std::cin >> eve_vec_len;
			std::cout << "请输入角度区间等级，按回车结束" << std::endl;
			for (int i_vec_len = 0; i_vec_len < eve_vec_len; ++i_vec_len) {
				int eve_temp;
				std::cin >> eve_temp;
				eve_n_vec.push_back(eve_temp);
			}
		}
		if (id_eve_set == 1) {
			eve_n_vec = { 8,12,18,36,72 };
		}
		if (id_eve_set == 2) {
			eve_n_vec = { 90,120,180 };
		}
		if (id_eve_set == 3) {
			eve_n_vec = { 8,12,18,36,72,90,120,180 };
		}
		if (id_eve_set == 4) {
			eve_n_vec = { 1,2,3,4,5,6,8,9,10,12,15,18 };
		}
		if (id_eve_set == 5) {
			eve_n_vec = { 1,2,3,4,5,6,8,9,10,12,15,18,20,24,30,36,40,45,60,72,90,120,180 };
		}

		int whe_mid, id_piece_mid = 0, id_sheet_mid = 0, id_eve_mid = 0;
		std::cout << "请输入是否要从中途某个组合开始（0为否；1为是），按回车结束" << std::endl;
		std::cin >> whe_mid;
		if (whe_mid == 1) {
			std::cout << "请输入要从中途哪个零件开始（包含），按回车结束" << std::endl;
			std::cin >> id_piece_mid;
			std::cout << "请输入要从中途哪个板材开始（包含），按回车结束" << std::endl;
			std::cin >> id_sheet_mid;
			std::cout << "请输入要从中途哪个角度区间（编号从0开始）开始（包含），按回车结束" << std::endl;
			std::cin >> id_eve_mid;
		}

		std::vector<std::vector<std::vector<int>>> whe_cal;
		int whe_dec_cal;
		std::cout << "请输入是否要只选择其中的某一些情况进行计算（1为是，0为全部计算），按回车结束" << std::endl;
		std::cin >> whe_dec_cal;
		if (whe_dec_cal == 1) {
			for (int i_p = 0; i_p <= id_piece_end - id_piece_start; ++i_p) {
				std::cout << "piece " << id_piece_start + i_p << std::endl;
				std::vector<std::vector<int>> whe_cal_p;
				for (int i_s = 0; i_s <= id_sheet_end - id_sheet_start; ++i_s) {
					std::cout << "sheet " << id_sheet_start + i_s << std::endl;
					std::vector<int> whe_cal_ps;
					for (int i_e = 0; i_e < eve_n_vec.size(); ++i_e) {
						std::cout << "eve " << eve_n_vec[i_e] << "，0为跳过，1为计算" << std::endl;
						int whe_cal_pse;
						std::cin >> whe_cal_pse;
						whe_cal_ps.push_back(whe_cal_pse);
					}
					whe_cal_p.push_back(whe_cal_ps);
				}
				whe_cal.push_back(whe_cal_p);
			}
		}
		else {
			for (int i_p = 0; i_p <= id_piece_end - id_piece_start; ++i_p) {
				std::vector<std::vector<int>> whe_cal_p;
				for (int i_s = 0; i_s <= id_sheet_end - id_sheet_start; ++i_s) {
					std::vector<int> whe_cal_ps;
					for (int i_e = 0; i_e < eve_n_vec.size(); ++i_e) {
						whe_cal_ps.push_back(1);
					}
					whe_cal_p.push_back(whe_cal_ps);
				}
				whe_cal.push_back(whe_cal_p);
			}
		}

		for (i_obj = i_obj_start; i_obj <= i_obj_end; ++i_obj) {
			std::vector<std::vector<int>> targ_num = { {130,119,138,132,0},{117,107,126,120,0},{93,84,98,94,0},{54,49,58,57,0},{102,89,107,102,0},{0,0,0,0,76},{0,0,0,0,96},{0,0,0,0,82},{0,0,0,0,70} };
			std::vector<std::vector<int>> whe_targ = { {0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0} };
			std::vector<std::vector<int>> best_num = { {0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0} };

			for (id_piece = id_piece_start; id_piece <= id_piece_end; ++id_piece) {
				if (whe_mid == 1 && id_piece != id_piece_mid) {
					continue;
				}
				c_Point_list_2 c_points_piece = input_polygon("D:/Ph.D/Code/Packing/data/packing/Plane with key points/Pieces/piece " + std::to_string(id_piece) + ".xyz");

				FILE* fp;
				std::string kp_str = "D:/Ph.D/Code/Packing/data/packing/Plane with key points/Pieces/key points " + std::to_string(id_piece) + ".txt";
				fp = fopen(kp_str.c_str(), "r");
				std::vector<std::vector<double>> key_points;
				for (int i_case = 0; i_case < 3; ++i_case) {
					std::vector<double> key_point(2);
					for (int i_id = 0; i_id < 2; ++i_id) {
						fscanf(fp, "%lf", &key_point[i_id]);
					}
					key_points.push_back(key_point);
				}
				fclose(fp);

				std::vector<double> cc_piece(2);
				Polygon_2 piece;
				// for (c_Point_list_2::const_iterator it = c_points_piece.begin(); it != c_points_piece.end(); ++it)
				//	piece.push_back(Point_2(it->x(), it->y()));
				// CGAL::draw(piece);
				piece = init_min_c_c(c_points_piece, cc_piece).outer_boundary();
				Polygon_2 key_point_hole;
				for (int i_poi = 0; i_poi < 3; ++i_poi)
					key_point_hole.push_back(Point_2(key_points[i_poi][0] - cc_piece[0], key_points[i_poi][1]
						- cc_piece[1]));

				std::vector<double> bbox = bbox_cal(piece);
				double bbox_area = (bbox[2] - bbox[0]) * (bbox[3] - bbox[1]);

				std::vector<std::vector<double>> best_res_output(5);
				for (int i_eve_n = 0; i_eve_n < eve_n_vec.size(); ++i_eve_n) {
					if (whe_mid == 1 && i_eve_n != id_eve_mid) {
						continue;
					}
					eve_n = eve_n_vec[i_eve_n];
					std::vector<std::vector<Polygon_2>> nfp_vv;

					for (int i_eve_1 = 0; i_eve_1 < eve_n; ++i_eve_1) {
						int ang_1 = 360.0 / eve_n * i_eve_1;
						//std::cout << "reading: ang_1: " << ang_1 << std::endl;

						std::vector<Polygon_2> nfp_v;
						for (int i_eve_2 = 0; i_eve_2 < eve_n; ++i_eve_2) {
							int ang_2 = 360.0 / eve_n * i_eve_2;
							std::vector<double> f_poi({ 0,0 });
							Polygon_2 piece_nfp;
							f_poi = { 0,0 };
							kp_str = "D:/Ph.D/Code/Packing/data/packing/nfp record/p"
								+ std::to_string(id_piece) + "_" + std::to_string(ang_1) + "_"
								+ std::to_string(ang_2) + "piece_nfp.txt";
							fp = fopen(kp_str.c_str(), "r");
							while (fscanf(fp, "%lf", &f_poi[0]) == 1) {
								fscanf(fp, "%lf", &f_poi[1]);
								piece_nfp.push_back(Point_2(f_poi[0], f_poi[1]));
							}
							fclose(fp);
							nfp_v.push_back(piece_nfp);
							//std::cout << ang_2 << std::endl;
						}
						nfp_vv.push_back(nfp_v);
					}

					for (id_sheet = id_sheet_start; id_sheet <= id_sheet_end; ++id_sheet) {
						if (whe_mid == 1 && id_sheet != id_sheet_mid) {
							continue;
						}
						if (whe_cal[id_piece - id_piece_start][id_sheet - id_sheet_start][i_eve_n] != 1) {
							continue;
						}
						whe_mid = 0;
						if (whe_targ[id_piece - 1][id_sheet - 1] == 0 || i_all == 0) {
							std::cout << "id_piece: " << id_piece << ", eve_n: " << eve_n << ", id_sheet: " << id_sheet << std::endl;
							c_Point_list_2 c_points_sheet = input_polygon("D:/Ph.D/Code/Packing/data/packing/Plane with key points/Sheets/sheet " + std::to_string(id_sheet) + ".xyz");

							std::vector < c_Point_list_2 > vec_c_points_holes;
							for (int i_p_num = 0; i_p_num < sheet_holes[id_sheet - 1]; ++i_p_num) {
								c_Point_list_2 vec_c_points_hole = input_polygon("D:/Ph.D/Code/Packing/data/packing/Plane with key points/Sheets/sheet " + std::to_string(id_sheet) + "h" + std::to_string(i_p_num + 1) + ".xyz");
								vec_c_points_holes.push_back(vec_c_points_hole);
							}

							Polygon_2 sheet;
							for (c_Point_list_2::const_iterator it = c_points_sheet.begin(); it != c_points_sheet.end(); ++it)
								sheet.push_back(Point_2(it->x(), it->y()));

							std::vector<Polygon_2> holes(sheet_holes[id_sheet - 1]);
							for (int i_p_num = 0; i_p_num < sheet_holes[id_sheet - 1]; ++i_p_num) {
								for (c_Point_list_2::const_iterator it = vec_c_points_holes[i_p_num].begin(); it
									!= vec_c_points_holes[i_p_num].end(); ++it)
									holes[i_p_num].push_back(Point_2(it->x(), it->y()));
							}

							std::vector<Polygon_set_2> feasible_vec;
							std::vector<double> pre_area_nfps;
							for (int i_eve_1 = 0; i_eve_1 < eve_n; ++i_eve_1) {
								int ang_1 = 360.0 / eve_n * i_eve_1;
								Polygon_set_2 feasible_single;

								Polygon_2 feasible_sheet;
								std::vector<double> f_poi({ 0,0 });
								kp_str = "D:/Ph.D/Code/Packing/data/packing/nfp record/p"
									+ std::to_string(id_piece) + "s" + std::to_string(id_sheet) + "_"
									+ std::to_string(ang_1) + "feasible_sheet.txt";
								fp = fopen(kp_str.c_str(), "r");
								while (fscanf(fp, "%lf", &f_poi[0]) == 1) {
									fscanf(fp, "%lf", &f_poi[1]);
									feasible_sheet.push_back(Point_2(f_poi[0], f_poi[1]));
								}
								fclose(fp);

								feasible_single.insert(feasible_sheet);

								for (int i_hole = 0; i_hole < sheet_holes[id_sheet - 1]; ++i_hole) {
									Polygon_2 hole_nfp;
									f_poi = { 0,0 };
									kp_str = "D:/Ph.D/Code/Packing/data/packing/nfp record/p"
										+ std::to_string(id_piece) + "s" + std::to_string(id_sheet) + "h"
										+ std::to_string(i_hole) + "_" + std::to_string(ang_1) + "hole_nfp.txt";
									fp = fopen(kp_str.c_str(), "r");
									while (fscanf(fp, "%lf", &f_poi[0]) == 1) {
										fscanf(fp, "%lf", &f_poi[1]);
										hole_nfp.push_back(Point_2(f_poi[0], f_poi[1]));
									}
									fclose(fp);
									feasible_single.difference(hole_nfp);
								}

								double area_nfp_first = 0;
								std::list<Polygon_with_holes_2> res_first;
								std::list<Polygon_with_holes_2>::const_iterator it_first;
								feasible_single.polygons_with_holes(std::back_inserter(res_first));
								for (it_first = res_first.begin(); it_first != res_first.end(); ++it_first) {
									area_nfp_first += to_double(it_first->outer_boundary().area().approx());
									for (auto it_hole_first = it_first->holes_begin(); it_hole_first != it_first->holes_end(); ++it_hole_first) {
										area_nfp_first -= to_double(it_hole_first->area().approx());
									}
								}
								pre_area_nfps.push_back(area_nfp_first);
								feasible_vec.push_back(feasible_single);
							}

							/*
				std::vector<Polygon_2> pgns_to_draw;
				for (int i_p_num = 0; i_p_num < sheet_holes[id_sheet - 1]; ++i_p_num)
					pgns_to_draw.push_back(holes[i_p_num]);
				*/
							int num_packed = 0;
							std::vector<std::vector<double>> res_coords;
							std::vector<double> i_eves;
							double fin_nfp_perc = 0;

							DWORD t_heu1 = GetTickCount64();

							// 靠固定方向启发式
							if (i_obj == 0) {
								for (;;) {
									double best_obj = 100000;
									int best_i_eve;
									std::vector<double> best_coord;
									for (int i_eve = 0; i_eve < eve_n; ++i_eve) {
										if (feasible_vec[i_eve].number_of_polygons_with_holes() == 0) {
											continue;
										}
										std::list<Polygon_with_holes_2> res;
										std::list<Polygon_with_holes_2>::const_iterator it;

										double best_obj_local = 100000;
										std::vector<double> best_coord_local;
										feasible_vec[i_eve].polygons_with_holes(std::back_inserter(res));
										for (it = res.begin(); it != res.end(); ++it) {
											Polygon_2 ob = it->outer_boundary();
											for (VertexIterator vi = ob.vertices_begin(); vi != ob.vertices_end(); ++vi) {
												double vi_x = to_double(vi->x().approx());
												double vi_y = to_double(vi->y().approx());
												double obj = vi_x * x_para + vi_y * y_para;
												if (obj < best_obj_local) {
													best_obj_local = obj;
													best_coord_local = { vi_x, vi_y };
												}
											}
										}
										if (best_obj_local < best_obj) {
											best_obj = best_obj_local;
											best_coord = best_coord_local;
											best_i_eve = i_eve;
										}
									}

									if (best_obj == 100000)
										break;

									//pgns_to_draw.push_back(Polygon_2_trans(Polygon_2_turn_acw(piece, 2.0 * PI / eve_n * best_i_eve),
									//	best_coord[0], best_coord[1]));
									res_coords.push_back({ best_coord[0], best_coord[1] });
									i_eves.push_back(best_i_eve);
									std::cout << "best_i_eve: " << best_i_eve << std::endl;

									/*
									if (feasible.number_of_polygons_with_holes() == 0) {
										break;
									}
									std::list<Polygon_with_holes_2> res;
									std::list<Polygon_with_holes_2>::const_iterator it;

									double best_obj = 100000;
									std::vector<double> best_coord(2);
									feasible.polygons_with_holes(std::back_inserter(res));
									for (it = res.begin(); it != res.end(); ++it) {
										Polygon_2 ob = it->outer_boundary();
										for (VertexIterator vi = ob.vertices_begin(); vi != ob.vertices_end(); ++vi) {
											double vi_x = to_double(vi->x().approx());
											double vi_y = to_double(vi->y().approx());
											double obj = vi_x * x_para + vi_y * y_para;
											if (obj < best_obj) {
												best_obj = obj;
												best_coord = {vi_x, vi_y};
											}
										}
									}
									res_coords.push_back(best_coord);
									Polygon_with_holes_2 mink_res_2d = CGAL::minkowski_sum_2(Polygon_2_trans(piece,
										best_coord[0], best_coord[1]), Polygon_2_turn_acw(piece, PI));
									feasible.difference(mink_res_2d);
									num_packed++;
									std::cout << num_packed << std::endl;
									*/

									for (int i_eve = 0; i_eve < eve_n; ++i_eve) {
										//std::cout << "updating: i_eve: " << i_eve << std::endl;
										/*
										if (i_eve == 2) {
											Polygon_set_2 pgn_set_temp = feasible_vec[i_eve];
											CGAL::draw(pgn_set_temp);
											Polygon_2 nfp_trans = Polygon_2_trans(nfp_vv[i_eve][best_i_eve], best_coord[0],
												best_coord[1]);
											nfp_trans = nfp_vv[i_eve][best_i_eve];
											std::cout << nfp_trans << std::endl;
											CGAL::draw(nfp_trans);
											Polygon_set_2 test;
											test.insert(nfp_trans);
											CGAL::draw(test);
											test.difference(pgn_set_temp);
											CGAL::draw(test);
											test.difference(nfp_trans);
											CGAL::draw(test);
											pgn_set_temp.difference(test);
											CGAL::draw(pgn_set_temp);
										}
										*/
										feasible_vec[i_eve].difference(Polygon_2_trans(nfp_vv[i_eve][best_i_eve], best_coord[0],
											best_coord[1]));
									}

									num_packed++;
									std::cout << "num_packed: " << num_packed << std::endl;
								}
							}
							// 随机方向启发式
							if (i_obj == 1) {
								srand(time(NULL));
								for (;;) {
									int rand_num = rand();
									x_para = cos(2 * PI / RAND_MAX * rand_num);
									y_para = sin(2 * PI / RAND_MAX * rand_num);
									double best_obj = 100000;
									int best_i_eve;
									std::vector<double> best_coord;
									for (int i_eve = 0; i_eve < eve_n; ++i_eve) {
										if (feasible_vec[i_eve].number_of_polygons_with_holes() == 0) {
											continue;
										}
										std::list<Polygon_with_holes_2> res;
										std::list<Polygon_with_holes_2>::const_iterator it;

										double best_obj_local = 100000;
										std::vector<double> best_coord_local;
										feasible_vec[i_eve].polygons_with_holes(std::back_inserter(res));
										for (it = res.begin(); it != res.end(); ++it) {
											Polygon_2 ob = it->outer_boundary();
											for (VertexIterator vi = ob.vertices_begin(); vi != ob.vertices_end(); ++vi) {
												double vi_x = to_double(vi->x().approx());
												double vi_y = to_double(vi->y().approx());
												double obj = vi_x * x_para + vi_y * y_para;
												if (obj < best_obj_local) {
													best_obj_local = obj;
													best_coord_local = { vi_x, vi_y };
												}
											}
										}
										if (best_obj_local < best_obj) {
											best_obj = best_obj_local;
											best_coord = best_coord_local;
											best_i_eve = i_eve;
										}
									}

									if (best_obj == 100000)
										break;

									//pgns_to_draw.push_back(Polygon_2_trans(Polygon_2_turn_acw(piece, 2.0 * PI / eve_n * best_i_eve),
									//	best_coord[0], best_coord[1]));
									res_coords.push_back({ best_coord[0], best_coord[1] });
									i_eves.push_back(best_i_eve);
									std::cout << "best_i_eve: " << best_i_eve << std::endl;

									/*
									if (feasible.number_of_polygons_with_holes() == 0) {
										break;
									}
									std::list<Polygon_with_holes_2> res;
									std::list<Polygon_with_holes_2>::const_iterator it;

									double best_obj = 100000;
									std::vector<double> best_coord(2);
									feasible.polygons_with_holes(std::back_inserter(res));
									for (it = res.begin(); it != res.end(); ++it) {
										Polygon_2 ob = it->outer_boundary();
										for (VertexIterator vi = ob.vertices_begin(); vi != ob.vertices_end(); ++vi) {
											double vi_x = to_double(vi->x().approx());
											double vi_y = to_double(vi->y().approx());
											double obj = vi_x * x_para + vi_y * y_para;
											if (obj < best_obj) {
												best_obj = obj;
												best_coord = {vi_x, vi_y};
											}
										}
									}
									res_coords.push_back(best_coord);
									Polygon_with_holes_2 mink_res_2d = CGAL::minkowski_sum_2(Polygon_2_trans(piece,
										best_coord[0], best_coord[1]), Polygon_2_turn_acw(piece, PI));
									feasible.difference(mink_res_2d);
									num_packed++;
									std::cout << num_packed << std::endl;
									*/

									for (int i_eve = 0; i_eve < eve_n; ++i_eve) {
										//std::cout << "updating: i_eve: " << i_eve << std::endl;
										/*
										if (i_eve == 2) {
											Polygon_set_2 pgn_set_temp = feasible_vec[i_eve];
											CGAL::draw(pgn_set_temp);
											Polygon_2 nfp_trans = Polygon_2_trans(nfp_vv[i_eve][best_i_eve], best_coord[0],
												best_coord[1]);
											nfp_trans = nfp_vv[i_eve][best_i_eve];
											std::cout << nfp_trans << std::endl;
											CGAL::draw(nfp_trans);
											Polygon_set_2 test;
											test.insert(nfp_trans);
											CGAL::draw(test);
											test.difference(pgn_set_temp);
											CGAL::draw(test);
											test.difference(nfp_trans);
											CGAL::draw(test);
											pgn_set_temp.difference(test);
											CGAL::draw(pgn_set_temp);
										}
										*/
										feasible_vec[i_eve].difference(Polygon_2_trans(nfp_vv[i_eve][best_i_eve], best_coord[0],
											best_coord[1]));
									}

									num_packed++;
									std::cout << "num_packed: " << num_packed << std::endl;
								}
							}
							// 遍历顶点计算feasible面积
							if (i_obj == 2) {
								for (;;) {
									double best_obj = -10;
									int best_i_eve;
									std::vector<Polygon_set_2> best_feasible_vec;
									std::vector<double> best_coord;
									for (int i_eve = 0; i_eve < eve_n; ++i_eve) {
										if (feasible_vec[i_eve].number_of_polygons_with_holes() == 0) {
											continue;
										}
										std::list<Polygon_with_holes_2> res;
										std::list<Polygon_with_holes_2>::const_iterator it;

										double best_obj_local = -10;
										std::vector<double> best_coord_local;
										std::vector<Polygon_set_2> best_feasible_vec_local;
										feasible_vec[i_eve].polygons_with_holes(std::back_inserter(res));
										for (it = res.begin(); it != res.end(); ++it) {
											Polygon_2 ob = it->outer_boundary();
											for (VertexIterator vi = ob.vertices_begin(); vi != ob.vertices_end(); ++vi) {
												double vi_x = to_double(vi->x().approx());
												double vi_y = to_double(vi->y().approx());
												double nfp_max = 0, nfp_min = 100000000, nfp_sum = 0;
												std::vector<Polygon_set_2> feasible_vec_local;
												for (int i_eve_2 = 0; i_eve_2 < eve_n; ++i_eve_2) {
													Polygon_set_2 feasible_temp = feasible_vec[i_eve_2];
													feasible_temp.difference(Polygon_2_trans(nfp_vv[i_eve_2][i_eve], vi_x, vi_y));
													feasible_vec_local.push_back(feasible_temp);
													std::list<Polygon_with_holes_2> res_temp;
													std::list<Polygon_with_holes_2>::const_iterator it_temp;

													double area_nfp = 0;
													feasible_temp.polygons_with_holes(std::back_inserter(res_temp));
													for (it_temp = res_temp.begin(); it_temp != res_temp.end(); ++it_temp) {
														area_nfp += to_double(it_temp->outer_boundary().area().approx());
														for (auto it_hole_temp = it_temp->holes_begin(); it_hole_temp != it_temp->holes_end(); ++it_hole_temp) {
															area_nfp -= to_double(it_hole_temp->area().approx());
														}
													}
													if (area_nfp < nfp_min) {
														nfp_min = area_nfp;
													}
													if (area_nfp > nfp_max) {
														nfp_max = area_nfp;
													}
													nfp_sum += area_nfp;
												}

												double obj = nfp_max;
												if (obj > best_obj_local) {
													best_obj_local = obj;
													best_coord_local = { vi_x, vi_y };
													best_feasible_vec_local = feasible_vec_local;
												}
											}
										}
										if (best_obj_local > best_obj) {
											best_obj = best_obj_local;
											best_coord = best_coord_local;
											best_i_eve = i_eve;
											best_feasible_vec = best_feasible_vec_local;
										}
									}

									if (best_obj == -10)
										break;

									//pgns_to_draw.push_back(Polygon_2_trans(Polygon_2_turn_acw(piece, 2.0 * PI / eve_n * best_i_eve),
									//	best_coord[0], best_coord[1]));
									res_coords.push_back({ best_coord[0], best_coord[1] });
									i_eves.push_back(best_i_eve);
									std::cout << "best_i_eve: " << best_i_eve << std::endl;

									/*
									if (feasible.number_of_polygons_with_holes() == 0) {
										break;
									}
									std::list<Polygon_with_holes_2> res;
									std::list<Polygon_with_holes_2>::const_iterator it;

									double best_obj = 100000;
									std::vector<double> best_coord(2);
									feasible.polygons_with_holes(std::back_inserter(res));
									for (it = res.begin(); it != res.end(); ++it) {
										Polygon_2 ob = it->outer_boundary();
										for (VertexIterator vi = ob.vertices_begin(); vi != ob.vertices_end(); ++vi) {
											double vi_x = to_double(vi->x().approx());
											double vi_y = to_double(vi->y().approx());
											double obj = vi_x * x_para + vi_y * y_para;
											if (obj < best_obj) {
												best_obj = obj;
												best_coord = {vi_x, vi_y};
											}
										}
									}
									res_coords.push_back(best_coord);
									Polygon_with_holes_2 mink_res_2d = CGAL::minkowski_sum_2(Polygon_2_trans(piece,
										best_coord[0], best_coord[1]), Polygon_2_turn_acw(piece, PI));
									feasible.difference(mink_res_2d);
									num_packed++;
									std::cout << num_packed << std::endl;
									*/

									feasible_vec = best_feasible_vec;
									/*
									for (int i_eve = 0; i_eve < eve_n; ++i_eve) {
										//std::cout << "updating: i_eve: " << i_eve << std::endl;
										/*
										if (i_eve == 2) {
											Polygon_set_2 pgn_set_temp = feasible_vec[i_eve];
											CGAL::draw(pgn_set_temp);
											Polygon_2 nfp_trans = Polygon_2_trans(nfp_vv[i_eve][best_i_eve], best_coord[0],
												best_coord[1]);
											nfp_trans = nfp_vv[i_eve][best_i_eve];
											std::cout << nfp_trans << std::endl;
											CGAL::draw(nfp_trans);
											Polygon_set_2 test;
											test.insert(nfp_trans);
											CGAL::draw(test);
											test.difference(pgn_set_temp);
											CGAL::draw(test);
											test.difference(nfp_trans);
											CGAL::draw(test);
											pgn_set_temp.difference(test);
											CGAL::draw(pgn_set_temp);
										}
										/
										feasible_vec[i_eve].difference(Polygon_2_trans(nfp_vv[i_eve][best_i_eve], best_coord[0],
											best_coord[1]));
									}
									*/
									num_packed++;
									std::cout << "num_packed: " << num_packed << std::endl;
								}
							}
							// 使用圆周方向筛选顶点后计算feasible面积
							if (i_obj >= 3) {
								for (;;) {
									double best_obj = -100000000;
									int best_i_eve;
									std::vector<Polygon_set_2> best_feasible_vec;
									std::vector<double> best_coord;
									std::vector<double> best_area_nfps;
									for (int i_eve = 0; i_eve < eve_n; ++i_eve) {
										if (feasible_vec[i_eve].number_of_polygons_with_holes() == 0) {
											continue;
										}

										std::list<Polygon_with_holes_2> res;
										std::list<Polygon_with_holes_2>::const_iterator it;

										std::vector<std::vector<double>> coord_ll_to_compare;
										std::vector<double> best_coord_ll_pre;
										for (int temp_obj_ang = 0; temp_obj_ang < 36; ++temp_obj_ang) {
											double x_para = cos(2 * PI / 36 * temp_obj_ang);
											double y_para = sin(2 * PI / 36 * temp_obj_ang);
											double best_obj_ll = 100000;
											std::vector<double> best_coord_ll;
											feasible_vec[i_eve].polygons_with_holes(std::back_inserter(res));
											for (it = res.begin(); it != res.end(); ++it) {
												Polygon_2 ob = it->outer_boundary();
												for (VertexIterator vi = ob.vertices_begin(); vi != ob.vertices_end(); ++vi) {
													double vi_x = to_double(vi->x().approx());
													double vi_y = to_double(vi->y().approx());
													double obj = vi_x * x_para + vi_y * y_para;
													if (obj < best_obj_ll) {
														best_obj_ll = obj;
														best_coord_ll = { vi_x, vi_y };
													}
												}
											}
											if (temp_obj_ang == 0) {
												best_coord_ll_pre = best_coord_ll;
											}
											else {
												if (!equal_double(best_coord_ll_pre[0], best_coord_ll[0], 0.001) ||
													!equal_double(best_coord_ll_pre[1], best_coord_ll[1], 0.001)) {
													coord_ll_to_compare.push_back(best_coord_ll_pre);
													best_coord_ll_pre = best_coord_ll;
												}
											}
										}
										if (!equal_double(best_coord_ll_pre[0], coord_ll_to_compare[0][0], 0.001) ||
											!equal_double(best_coord_ll_pre[1], coord_ll_to_compare[0][1], 0.001)) {
											coord_ll_to_compare.push_back(best_coord_ll_pre);
										}
										//std::cout << "coord_ll_to_compare.size() = " << coord_ll_to_compare.size() << std::endl;

										std::vector<std::vector<double>> best_coords_local(coord_ll_to_compare.size());
										std::vector<std::vector<double>> area_nfps_vec(coord_ll_to_compare.size());
										std::vector<std::vector<Polygon_set_2>> best_feasibles_vec_local(coord_ll_to_compare.size());
										std::vector<std::thread> t_poi(coord_ll_to_compare.size());
										for (int i_poi = 0; i_poi < coord_ll_to_compare.size(); ++i_poi) {
											t_poi[i_poi] = std::thread([i_poi, coord_ll_to_compare, eve_n, i_eve, nfp_vv, pre_area_nfps,
												feasible_vec, i_obj, &best_coords_local, &best_feasibles_vec_local, &area_nfps_vec] {
													double vi_x = coord_ll_to_compare[i_poi][0];
													double vi_y = coord_ll_to_compare[i_poi][1];
													double nfp_max = 0, nfp_min = 100000000, nfp_sum = 0;
													double diff_nfp_max = 0, diff_nfp_min = 100000000, diff_nfp_sum = 0;
													double perc_nfp_max = 0, perc_nfp_min = 100000000, perc_nfp_sum = 0;
													std::vector<Polygon_set_2> feasible_vec_local;
													std::vector<double> area_nfps;
													for (int i_eve_2 = 0; i_eve_2 < eve_n; ++i_eve_2) {
														Polygon_set_2 feasible_temp = feasible_vec[i_eve_2];
														feasible_temp.difference(Polygon_2_trans(nfp_vv[i_eve_2][i_eve], vi_x, vi_y));
														feasible_vec_local.push_back(feasible_temp);
														std::list<Polygon_with_holes_2> res_temp;
														std::list<Polygon_with_holes_2>::const_iterator it_temp;

														double area_nfp = 0;
														double diff_area_nfp, perc_area_nfp;
														feasible_temp.polygons_with_holes(std::back_inserter(res_temp));
														for (it_temp = res_temp.begin(); it_temp != res_temp.end(); ++it_temp) {
															area_nfp += to_double(it_temp->outer_boundary().area().approx());
															for (auto it_hole_temp = it_temp->holes_begin(); it_hole_temp != it_temp->holes_end(); ++it_hole_temp) {
																area_nfp -= to_double(it_hole_temp->area().approx());
															}
														}
														diff_area_nfp = pre_area_nfps[i_eve_2] - area_nfp;
														perc_area_nfp = diff_area_nfp / pre_area_nfps[i_eve_2];//倒数意味着原先这么大的nfp估计能这样放进多少个零件
														if (area_nfp < nfp_min) {
															nfp_min = area_nfp;
														}
														if (area_nfp > nfp_max) {
															nfp_max = area_nfp;
														}
														nfp_sum += area_nfp;
														if (diff_area_nfp < diff_nfp_min) {
															diff_nfp_min = diff_area_nfp;
														}
														if (diff_area_nfp > diff_nfp_max) {
															diff_nfp_max = diff_area_nfp;
														}
														diff_nfp_sum += diff_area_nfp;
														if (perc_area_nfp < perc_nfp_min) {
															perc_nfp_min = perc_area_nfp;
														}
														if (perc_area_nfp > perc_nfp_max) {
															perc_nfp_max = perc_area_nfp;
														}
														perc_nfp_sum += perc_area_nfp;
														area_nfps.push_back(area_nfp);
													}

													double diff_nfp_avg = diff_nfp_sum / eve_n;
													double nfp_avg = nfp_sum / eve_n;
													double obj = nfp_max;
													if (i_obj == 4) {
														obj = -diff_nfp_min;
													}
													if (i_obj == 5) {
														obj = -perc_nfp_min;
													}
													if (i_obj == 6) {
														obj = nfp_min;
													}
													if (i_obj == 7) {
														obj = -diff_nfp_max;
													}
													if (i_obj == 8) {
														obj = -perc_nfp_max;
													}
													if (i_obj == 9) {
														obj = nfp_sum / eve_n;
													}
													if (i_obj == 10) {
														obj = -diff_nfp_sum / eve_n;
													}
													if (i_obj == 11) {
														obj = -perc_nfp_sum / eve_n;
													}
													if (i_obj == 12) {
														obj = (nfp_sum - diff_nfp_sum) / eve_n;
													}
													if (i_obj == 13) {
														obj = 0.5 * (nfp_sum - diff_nfp_sum) / eve_n + 0.5 * (nfp_min - diff_nfp_max);
													}
													if (i_obj == 14) {
														obj = 0.5 * (nfp_sum / eve_n) / (1.0 + diff_nfp_sum / eve_n) +
															0.5 * nfp_min / (1.0 + diff_nfp_max);
													}
													if (i_obj == 15) {
														obj = (nfp_max + nfp_min + nfp_sum / eve_n) / (1.0 + diff_nfp_max + diff_nfp_min + diff_nfp_sum / eve_n);
													}
													if (i_obj == 16) {
														obj = cbrt(nfp_max * nfp_min * nfp_sum / eve_n) / (1.0 + cbrt(diff_nfp_max * diff_nfp_min * diff_nfp_sum / eve_n));
													}
													if (i_obj == 17) {
														obj = sqrt((nfp_sum - diff_nfp_sum) / eve_n * (nfp_min - diff_nfp_max));
													}
													if (i_obj == 18) {
														obj = (0.2 * nfp_max + 0.3 * nfp_min + 0.5 * nfp_sum / eve_n) / (1.0 + 0.2 * diff_nfp_max + 0.3 * diff_nfp_min + 0.5 * diff_nfp_sum / eve_n);
													}
													if (i_obj == 19) {
														obj = ((nfp_sum / eve_n - diff_nfp_sum / eve_n) / (1.0 + nfp_sum / eve_n)
															+ (nfp_min - diff_nfp_max) / (1.0 + nfp_min) + (nfp_max - diff_nfp_min) / (1.0 + nfp_max)) / 3;
													}
													if (i_obj == 20) {
														obj = std::pow((1.0 + nfp_sum / eve_n) / (1.0 + diff_nfp_sum / eve_n) * (1.0 + nfp_min) / (1.0 + diff_nfp_max) * (1.0 + nfp_max) / (1.0 + diff_nfp_min), 1.0 / 3.0);
													}
													if (i_obj == 21) {
														double ratio_avg = (nfp_sum / eve_n) / (1.0 + diff_nfp_sum / eve_n);
														double ratio_worst = (nfp_min) / (1.0 + diff_nfp_max);
														obj = 2.0 * ratio_avg * ratio_worst / (ratio_avg + ratio_worst);
													}
													if (i_obj == 22) {
														obj = 0.4 * (nfp_sum / eve_n) / (1.0 + diff_nfp_sum / eve_n) +
															0.3 * nfp_min / (1.0 + diff_nfp_max) + 0.3 * nfp_max / (1.0 + diff_nfp_min);
													}
													if (i_obj == 23) {
														obj = cbrt((nfp_sum - diff_nfp_sum) / eve_n * (nfp_min - diff_nfp_max) * (nfp_max - diff_nfp_min));
													}
													if (i_obj == 24) {
														obj = 3.0 / (1.0 / ((nfp_sum / eve_n) / (1.0 + diff_nfp_sum / eve_n)) +
															1.0 / (nfp_min / (1.0 + diff_nfp_max)) + 1.0 / (nfp_max / (1.0 + diff_nfp_min)));
													}
													if (i_obj == 25) {
														obj = ((nfp_sum / eve_n) / (1.0 + diff_nfp_sum / eve_n) +
															nfp_min / (1.0 + diff_nfp_max) + nfp_max / (1.0 + diff_nfp_min)) / 3.0;
													}
													if (i_obj == 26) {
														double net_avg = (nfp_sum - diff_nfp_sum) / eve_n;
														double net_min = nfp_min - diff_nfp_max;
														double net_max = nfp_max - diff_nfp_min;
														double disparity = net_max - net_min;
														obj = net_avg - 0.5 * disparity;
													}
													if (i_obj == 27) {
														double ratio_avg = (nfp_sum / eve_n) / (1.0 + diff_nfp_sum / eve_n);
														double ratio_min = nfp_min / (1.0 + diff_nfp_max);
														double ratio_max = nfp_max / (1.0 + diff_nfp_min);
														double geo_mean = std::sqrt(ratio_avg * ratio_min);
														obj = geo_mean + 0.2 * ratio_max;
													}
													if (i_obj == 28) {
														double ratio_avg = (nfp_sum / eve_n) / (1.0 + diff_nfp_sum / eve_n);
														double ratio_min = nfp_min / (1.0 + diff_nfp_max);
														double ratio_max = nfp_max / (1.0 + diff_nfp_min);
														double harmonic_mean = 2.0 * ratio_avg * ratio_min / (ratio_avg + ratio_min);
														obj = harmonic_mean + 0.1 * ratio_max;
													}
													if (i_obj == 1001) {
														obj = 0.6 * nfp_avg + 0.4 * nfp_min - diff_nfp_avg;
													}
													if (i_obj == 1002) {
														obj = nfp_min * nfp_avg / (1 + diff_nfp_avg);
													}
													if (i_obj == 1003) {
														obj = 0.8 * nfp_avg - 0.2 * diff_nfp_avg;
													}
													if (i_obj == 1004) {
														obj = 0.5 * nfp_avg + 0.5 * nfp_min - 0.5 * diff_nfp_avg;
													}
													if (i_obj == 1005) {
														obj = nfp_avg;
													}
													if (i_obj == 1011) {
														double space_score = 0.3 * nfp_max + 0.3 * nfp_min + 0.4 * nfp_avg;
														double penalty = 0.4 * diff_nfp_avg + 0.6 * diff_nfp_max;
														obj = space_score - penalty;
													}
													if (i_obj == 1012) {
														const double epsilon = 1e-6;
														obj = (nfp_min * nfp_min * nfp_avg) / ((1.0 + diff_nfp_avg) * (nfp_max + epsilon));
													}
													if (i_obj == 1013) {
														obj = (0.5 * nfp_avg + 0.5 * nfp_min) - 0.25 * diff_nfp_avg;
													}
													if (i_obj == 1014) {
														obj = (0.5 * nfp_avg + 0.5 * nfp_min) - (0.5 * diff_nfp_avg + 0.5 * diff_nfp_max);
													}
													if (i_obj == 1015) {
														obj = nfp_avg - diff_nfp_avg;
													}
													if (i_obj == 1021) {
														obj = (0.7 * nfp_avg + 0.3 * nfp_min) - (0.6 * diff_nfp_avg + 0.4 * diff_nfp_max);
													}
													if (i_obj == 1022) {
														const double epsilon = 1e-6;
														double freeSpace = nfp_avg + nfp_min;
														double loss = diff_nfp_avg + diff_nfp_max + 1.0;
														obj = freeSpace / (loss + epsilon);
													}
													if (i_obj == 1023) {
														obj = (0.7 * nfp_avg + 0.3 * nfp_min) - (0.4 * diff_nfp_avg + 0.6 * diff_nfp_max);
													}
													if (i_obj == 1024) {
														obj = (0.6 * nfp_avg + 0.4 * nfp_min) - (0.5 * diff_nfp_avg + 0.5 * diff_nfp_max);
													}
													if (i_obj == 1025) {
														obj = nfp_avg - diff_nfp_avg;
													}
													if (i_obj == 1031) {
														const double epsilon = 1e-6;
														double numerator = 0.6 * nfp_avg + 0.4 * nfp_min;
														double denominator = 1.0 + 0.5 * diff_nfp_avg + 0.5 * diff_nfp_max;
														obj = numerator / (denominator + epsilon);
													}
													if (i_obj == 1032) {
														const double epsilon = 1e-6;
														double freeSpaceProduct = nfp_avg * nfp_min;
														double lossProduct = diff_nfp_avg * diff_nfp_max;
														obj = freeSpaceProduct / (lossProduct + 1.0 + epsilon);
													}
													if (i_obj == 1033) {
														obj = (0.65 * nfp_avg + 0.35 * nfp_min) - (0.55 * diff_nfp_avg + 0.45 * diff_nfp_max);
													}
													if (i_obj == 1034) {
														const double epsilon = 1e-6;
														double ratioScore = (nfp_avg + nfp_min) / (diff_nfp_avg + diff_nfp_max + 1.0 + epsilon);
														double diffScore = (0.7 * nfp_avg + 0.3 * nfp_min) - (0.6 * diff_nfp_avg + 0.4 * diff_nfp_max);
														obj = 0.5 * ratioScore + 0.5 * diffScore;
													}
													if (i_obj == 1035) {
														obj = nfp_avg - diff_nfp_avg;
													}
													if (i_obj == 1041) {
														double freeSpace = 0.65 * nfp_avg + 0.35 * nfp_min;
														double loss = 0.5 * diff_nfp_avg + 0.5 * diff_nfp_max;
														obj = freeSpace * std::exp(-loss);
													}
													if (i_obj == 1042) {
														const double epsilon = 1e-6;
														double freeSpaceMetric = std::sqrt(nfp_avg * nfp_min);
														double lossMetric = std::sqrt(diff_nfp_avg * diff_nfp_max);
														obj = freeSpaceMetric / (1.0 + lossMetric + epsilon);
													}
													if (i_obj == 1043) {
														const double epsilon = 1e-6;
														double numerator = 0.65 * nfp_avg + 0.35 * nfp_min;
														double denominator = 1.0 + 0.55 * diff_nfp_avg + 0.45 * diff_nfp_max;
														obj = numerator / (denominator + epsilon);
													}
													if (i_obj == 1044) {
														const double epsilon = 1e-6;
														double ratioScore = (nfp_avg + nfp_min) / (0.6 * diff_nfp_max + 0.4 * diff_nfp_avg + 1.0 + epsilon);
														double diffScore = (0.65 * nfp_avg + 0.35 * nfp_min) - (0.55 * diff_nfp_avg + 0.45 * diff_nfp_max);
														obj = 0.6 * ratioScore + 0.4 * diffScore;
													}
													if (i_obj == 1045) {
															const double epsilon = 1e-6;
															double freeSpace = nfp_avg + nfp_min;
															double loss = diff_nfp_avg + diff_nfp_max + 1.0;
															obj = freeSpace / (loss + epsilon);
													}
													if (i_obj == 1051) {
														const double epsilon = 1e-6;
														// Compute geometric mean of nfp_avg and nfp_min as a free space factor
														double freeSpaceFactor = sqrt(nfp_avg * nfp_min + epsilon);
														// Compute penalty using weighted differences for nfp reductions
														double lossPenalty = 0.5 * diff_nfp_avg + 0.3 * diff_nfp_max + 0.2 * diff_nfp_min;
														// Final obj: higher is better when free space is high and loss is low
														obj = freeSpaceFactor - lossPenalty;
													}
													if (i_obj == 1052) {
														const double epsilon = 1e-6;
														double freeSpaceScore = log(1.0 + nfp_min + nfp_avg);
														double reductionPenalty = log(1.0 + diff_nfp_max + diff_nfp_avg);
														double adjustment = tanh(diff_nfp_min - diff_nfp_avg);
														obj = freeSpaceScore - reductionPenalty + adjustment;
													}
													if (i_obj == 1053) {
														const double epsilon = 1e-6;
														double ratioScore = (nfp_avg + 0.8 * nfp_min) / (diff_nfp_avg + 0.9 * diff_nfp_max + 1.0 + epsilon);
														double diffScore = (0.8 * nfp_avg + 0.2 * nfp_min) - (0.5 * diff_nfp_avg + 0.5 * diff_nfp_max);
														obj = 0.4 * ratioScore + 0.6 * diffScore;
													}
													if (i_obj == 1054) {
														const double epsilon = 1e-6;
														double ratioScore = (nfp_avg + nfp_min) / (diff_nfp_avg + diff_nfp_max + 1.0 + epsilon);
														double diffScore = (0.65 * nfp_avg + 0.35 * nfp_min) - (0.55 * diff_nfp_avg + 0.45 * diff_nfp_max);
														obj = 0.4 * ratioScore + 0.6 * diffScore;
													}
													if (i_obj == 1055) {
														obj = (0.7 * nfp_avg + 0.3 * nfp_min) - (0.6 * diff_nfp_avg + 0.4 * diff_nfp_max);
													}
													if (i_obj == 1061) {
														const double epsilon = 1e-6;
														double freeSpaceScore = log(1.0 + nfp_avg + 2.0 * nfp_min);
														double penalty = sqrt(diff_nfp_max + 2.0 * diff_nfp_avg + 1.0);
														double adjustment = tanh(diff_nfp_min - diff_nfp_avg);
														obj = (freeSpaceScore / (penalty + epsilon)) + 0.1 * adjustment;
													}
													if (i_obj == 1062) {
														const double epsilon = 1e-6;
														double freeSpace = sqrt((nfp_min + epsilon) * (nfp_avg + epsilon));
														double penalty = exp(0.5 * (diff_nfp_max + diff_nfp_avg));
														obj = freeSpace / (penalty + epsilon);
													}
													if (i_obj == 1063) {
														const double epsilon = 1e-6;
														double ratioScore = (nfp_avg + 1.5 * nfp_min) / (diff_nfp_avg + 1.2 * diff_nfp_max + 1.0 + epsilon);
														double diffScore = (0.6 * nfp_avg + 0.4 * nfp_min) - (0.5 * diff_nfp_avg + 0.5 * diff_nfp_max);
														obj = 0.6 * ratioScore + 0.4 * diffScore;
													}
													if (i_obj == 1064) {
														const double epsilon = 1e-6;
														double ratioScore = (nfp_avg + nfp_min) / (diff_nfp_avg + diff_nfp_max + 1.0 + epsilon);
														double diffScore = (0.7 * nfp_avg + 0.3 * nfp_min) - (0.6 * diff_nfp_avg + 0.4 * diff_nfp_max);
														double logScore = log(1.0 + nfp_avg + nfp_min) - log(1.0 + diff_nfp_avg + diff_nfp_max);
														obj = 0.4 * ratioScore + 0.4 * diffScore + 0.2 * logScore;
													}
													if (i_obj == 1065) {
														const double epsilon = 1e-6;
														double freeSpace = nfp_avg + nfp_min;
														double loss = diff_nfp_avg + diff_nfp_max + 1.0;
														obj = freeSpace / (loss + epsilon);
													}
													if (i_obj == 1071) {
														const double epsilon = 1e-6;
														// Compute geometric mean (cube root of the product) for free space measures.
														double freeSpace = cbrt((nfp_avg + epsilon) * (nfp_min + epsilon) * (nfp_max + epsilon));
														// Compute geometric mean (cube root of the product) for space loss measures.
														double loss = cbrt((diff_nfp_avg + epsilon) * (diff_nfp_min + epsilon) * (diff_nfp_max + epsilon));
														// Compute final obj by rewarding high free space and penalizing space loss.
														obj = freeSpace / (1.0 + loss);
													}
													if (i_obj == 1072) {
														const double epsilon = 1e-6;
														double harmonicFree = 3.0 / ((1.0 / (nfp_max + epsilon)) +
															(1.0 / (nfp_min + epsilon)) +
															(1.0 / (nfp_avg + epsilon)));
														double harmonicPenalty = 3.0 / ((1.0 / (diff_nfp_max + epsilon)) +
															(1.0 / (diff_nfp_min + epsilon)) +
															(1.0 / (diff_nfp_avg + epsilon)));
														obj = harmonicFree / (1.0 + harmonicPenalty);
													}
													if (i_obj == 1073) {
														const double epsilon = 1e-6;
														// Modified ratio: giving more emphasis to nfp_avg and a higher offset.
														double ratioScore = (nfp_avg + 0.5 * nfp_min) / (diff_nfp_avg + diff_nfp_max + 2.0 + epsilon);

														// Modified weighted difference: adjusting the weights between free space and penalty.
														double diffScore = (0.6 * nfp_avg + 0.4 * nfp_min) - (0.5 * diff_nfp_avg + 0.5 * diff_nfp_max);

														// Modified logarithmic obj: applying a different weight to nfp_min and diff measures.
														double logScore = log(1.0 + nfp_avg + 0.8 * nfp_min) - log(1.0 + diff_nfp_avg + 0.8 * diff_nfp_max);

														// Combine the scores with altered weights.
														obj = 0.45 * ratioScore + 0.35 * diffScore + 0.2 * logScore;
													}
													if (i_obj == 1074) {
														const double epsilon = 1e-6;
														double ratioScore = (nfp_avg + nfp_min) / (diff_nfp_avg + diff_nfp_max + 1.0 + epsilon);
														double diffScore = (0.6 * nfp_avg + 0.4 * nfp_min) - (0.5 * diff_nfp_avg + 0.5 * diff_nfp_max);
														obj = 0.6 * ratioScore + 0.4 * diffScore;
													}
													if (i_obj == 1075) {
														const double epsilon = 1e-6;
														double ratioScore = (nfp_avg + nfp_min) / (diff_nfp_avg + diff_nfp_max + 1.0 + epsilon);
														double diffScore = (0.7 * nfp_avg + 0.3 * nfp_min) - (0.6 * diff_nfp_avg + 0.4 * diff_nfp_max);
														obj = 0.5 * ratioScore + 0.5 * diffScore;
													}
													if (i_obj == 1081) {
														const double epsilon = 1e-6;
														// Compute a weighted free space value, giving moderate bonus to the maximum available free space.
														double freeSpaceWeighted = 0.5 * (nfp_avg + nfp_min) + 0.5 * nfp_max;

														// Compute a weighted loss value, giving more penalty to the minimum loss component.
														double lossWeighted = 0.4 * (diff_nfp_max + diff_nfp_avg) + 0.6 * diff_nfp_min;

														// Optionally add a small logarithmic bonus to the free space.
														double bonus = log(1.0 + nfp_max);

														// Final obj is the adjusted free space (with bonus) divided by one plus the loss.
														obj = (freeSpaceWeighted + bonus) / (1.0 + lossWeighted + epsilon);
													}
													if (i_obj == 1082) {
														double prod_free = (1.0 + nfp_max) * (1.0 + nfp_avg) * (1.0 + nfp_min);
														double prod_loss = (1.0 + diff_nfp_max) * (1.0 + diff_nfp_avg) * (1.0 + diff_nfp_min);
														obj = log(prod_free) - log(prod_loss);
													}
													if (i_obj == 1083) {
														const double epsilon = 1e-6;
														double numerator = 0.5 * nfp_avg + 0.3 * nfp_min + 0.2 * nfp_max;
														double denominator = 1.0 + 0.4 * diff_nfp_avg + 0.3 * diff_nfp_max + 0.3 * diff_nfp_min;
														obj = numerator / (denominator + epsilon);
													}
													if (i_obj == 1084) {
														const double epsilon = 1e-6;
														double ratioScore = (nfp_avg + nfp_min) / (diff_nfp_avg + diff_nfp_max + 1.0 + epsilon);
														double diffScore = (0.65 * nfp_avg + 0.35 * nfp_min) - (0.55 * diff_nfp_avg + 0.45 * diff_nfp_max);
														double logScore = log(1.0 + nfp_avg + nfp_min) - log(1.0 + diff_nfp_avg + diff_nfp_max);
														obj = 0.35 * ratioScore + 0.35 * diffScore + 0.3 * logScore;
													}
													if (i_obj == 1085) {
														const double epsilon = 1e-6;
														double freeSpace = 0.7 * nfp_avg + 0.3 * nfp_min;
														double loss = 1.0 + 0.6 * diff_nfp_avg + 0.4 * diff_nfp_max;
														obj = freeSpace / (loss + epsilon);
													}
													if (i_obj == 1091) {
														const double epsilon = 1e-6;
														double freeSpaceWeighted = 0.4 * nfp_max + 0.4 * nfp_avg + 0.2 * nfp_min;
														double lossWeighted = 0.5 * diff_nfp_max + 0.3 * diff_nfp_avg + 0.2 * diff_nfp_min;
														obj = freeSpaceWeighted / (1.0 + lossWeighted + epsilon);
													}
													if (i_obj == 1092) {
														const double epsilon = 1e-6;
														double freeSpace = 0.3 * nfp_max + 0.4 * nfp_avg + 0.3 * nfp_min;
														double penalty = 0.4 * diff_nfp_max + 0.3 * diff_nfp_avg + 0.3 * diff_nfp_min;
														obj = (freeSpace * freeSpace) * exp(-penalty);
													}
													if (i_obj == 1093) {
														const double epsilon = 1e-6;
														double numerator = 0.5 * nfp_avg + 0.5 * nfp_min;
														double denominator = 1.0 + 0.6 * diff_nfp_max + 0.4 * diff_nfp_avg;
														obj = numerator / (denominator + epsilon);
													}
													if (i_obj == 1094) {
														const double epsilon = 1e-6;
														double ratioTerm = (nfp_avg + nfp_min) / (diff_nfp_avg + diff_nfp_max + 1.0 + epsilon);
														double diffTerm = (0.6 * nfp_avg + 0.4 * nfp_min) - (0.5 * diff_nfp_avg + 0.5 * diff_nfp_max);
														double logTerm = log(1.0 + nfp_avg + nfp_min) - log(1.0 + diff_nfp_avg + diff_nfp_max);
														obj = 0.4 * ratioTerm + 0.4 * diffTerm + 0.2 * logTerm;
													}
													if (i_obj == 1095) {
														const double epsilon = 1e-6;
														double freeSpace = nfp_avg + nfp_min;
														double loss = diff_nfp_max + diff_nfp_avg + 1.0;
														obj = freeSpace / (loss + epsilon);
													}
													if (i_obj == 1101) {
														const double epsilon = 1e-6;
														double geomFree = std::sqrt(nfp_avg * nfp_min);
														double harmLoss = (2.0 * diff_nfp_max * diff_nfp_avg) / (diff_nfp_max + diff_nfp_avg + epsilon);
														obj = geomFree / (1.0 + harmLoss);
													}
													if (i_obj == 1102) {
														// Compute average free space
														double freeSpace = (nfp_avg + nfp_min) / 2.0;
														// Compute average penalty from space reduction
														double lossFactor = (diff_nfp_max + diff_nfp_avg) / 2.0;
														// Exponential decay factor to penalize high loss
														double penalty = std::exp(-lossFactor);
														obj = freeSpace * penalty;
													}
													if (i_obj == 1103) {
														const double epsilon = 1e-6;
														// Modified weights for free space
														double numerator = 0.6 * nfp_avg + 0.4 * nfp_min;
														// Modified weights for the reduction terms
														double denominator = 1.0 + 0.7 * diff_nfp_max + 0.3 * diff_nfp_avg;
														obj = numerator / (denominator + epsilon);
													}
													if (i_obj == 1104) {
														const double epsilon = 1e-6;
														// Ratio-based obj similar to Heuristic No.1
														double ratioScore = (0.5 * nfp_avg + 0.5 * nfp_min) / (1.0 + 0.6 * diff_nfp_max + 0.4 * diff_nfp_avg + epsilon);
														// Logarithmic ratio penalizing high loss relative to free space
														double logScore = log((1.0 + nfp_avg + nfp_min) / (1.0 + diff_nfp_avg + diff_nfp_max + epsilon));
														// Combine the two scores with equal weights
														obj = 0.5 * ratioScore + 0.5 * logScore;
													}
													if (i_obj == 1105) {
														// Compute weighted free space measure.
														double freeSpaceScore = 0.7 * nfp_avg + 0.3 * nfp_min;
														// Compute penalty using the most significant reduction measures.
														double penaltyScore = 0.6 * diff_nfp_avg + 0.4 * diff_nfp_max;
														// Final obj is the free space minus the penalty.
														obj = freeSpaceScore - penaltyScore;
													}
													if (i_obj == 1111) {
														const double epsilon = 1e-6;
														// Ratio term: weighted free space divided by penalized space loss
														double ratioTerm = (0.6 * nfp_avg + 0.4 * nfp_min) /
															(1.0 + 0.5 * diff_nfp_max + 0.5 * diff_nfp_avg + epsilon);
														// Logarithmic term: difference between log of weighted free space and log of weighted space loss
														double weightedFree = 1.0 + 0.7 * nfp_avg + 0.3 * nfp_min;
														double weightedLoss = 1.0 + 0.6 * diff_nfp_max + 0.4 * diff_nfp_avg;
														double logTerm = log(weightedFree) - log(weightedLoss + epsilon);
														// Final obj: weighted sum of ratioTerm and logTerm
														obj = 0.5 * ratioTerm + 0.5 * logTerm;
													}
													if (i_obj == 1112) {
														const double epsilon = 1e-6;
														double numerator = 0.5 * nfp_max + sqrt(nfp_avg * nfp_min);
														double denominator = 1.0 + 0.35 * sqrt(diff_nfp_max * diff_nfp_avg) + 0.3 * diff_nfp_min;
														obj = numerator / (denominator + epsilon);
													}
													if (i_obj == 1113) {
														const double epsilon = 1e-6;
														double ratioScore = (0.55 * nfp_avg + 0.45 * nfp_min) / (1.0 + 0.4 * diff_nfp_max + 0.6 * diff_nfp_avg + epsilon);
														double logScore = log((1.0 + 0.8 * nfp_avg + 0.2 * nfp_min) / (1.0 + 0.5 * diff_nfp_avg + 0.5 * diff_nfp_max + epsilon));
														obj = 0.6 * ratioScore + 0.4 * logScore;
													}
													if (i_obj == 1114) {
														const double epsilon = 1e-6;
														double ratioScore = (0.55 * nfp_avg + 0.45 * nfp_min) /
															(1.0 + 0.6 * diff_nfp_max + 0.4 * diff_nfp_avg + epsilon);
														double diffScore = (0.65 * nfp_avg + 0.35 * nfp_min) - (0.55 * diff_nfp_avg + 0.45 * diff_nfp_max);
														obj = 0.5 * ratioScore + 0.5 * diffScore;
													}
													if (i_obj == 1115) {
														const double epsilon = 1e-6;
														double numerator = 0.6 * nfp_avg + 0.4 * nfp_min;
														double denominator = 1.0 + 0.7 * diff_nfp_max + 0.3 * diff_nfp_avg;
														obj = numerator / (denominator + epsilon);
													}
													if (i_obj == 1121) {
														const double epsilon = 1e-6;
														// Compute the harmonic mean of nfp_avg and nfp_min
														double harmonic_free = 2.0 / ((1.0 / (nfp_avg + epsilon)) + (1.0 / (nfp_min + epsilon)));

														// Compute the weighted penalty from the differences in free space
														double penalty = 1.0 + 0.5 * diff_nfp_max + 0.5 * diff_nfp_avg;

														// Final obj: high free space and lower penalty lead to a higher obj
														obj = harmonic_free / (penalty + epsilon);
													}
													if (i_obj == 1122) {
														const double epsilon = 1e-6;
														double free_quality = sqrt((nfp_avg + epsilon) * (nfp_min + epsilon));
														double loss_penalty = 0.5 * (diff_nfp_max + diff_nfp_avg);
														obj = free_quality - loss_penalty;
													}
													if (i_obj == 1123) {
														const double epsilon = 1e-6;
														double numerator = 0.55 * nfp_avg + 0.45 * nfp_min;
														double denominator = 1.0 + 0.65 * diff_nfp_max + 0.35 * diff_nfp_avg;
														obj = numerator / (denominator + epsilon);
													}
													if (i_obj == 1124) {
														const double epsilon = 1e-6;
														double ratioTerm = (0.55 * nfp_avg + 0.45 * nfp_min) / (1.0 + 0.55 * diff_nfp_max + 0.45 * diff_nfp_avg + epsilon);
														double weightedFree = 1.0 + 0.65 * nfp_avg + 0.35 * nfp_min;
														double weightedLoss = 1.0 + 0.65 * diff_nfp_max + 0.35 * diff_nfp_avg;
														double logTerm = log(weightedFree / (weightedLoss + epsilon));
														obj = 0.5 * ratioTerm + 0.5 * logTerm;
													}
													if (i_obj == 1125) {
														const double epsilon = 1e-6;
														// Using only nfp_avg, nfp_min, diff_nfp_max, and diff_nfp_avg; nfp_max and diff_nfp_min are redundant.
														double numerator = 0.6 * nfp_avg + 0.4 * nfp_min;
														double denominator = 1.0 + 0.7 * diff_nfp_max + 0.3 * diff_nfp_avg;
														obj = numerator / (denominator + epsilon);
													}
													if (i_obj == 1131) {
														// Compute the weighted free space using 55% weight on nfp_min and 45% on nfp_avg
														double free_space = 0.55 * nfp_min + 0.45 * nfp_avg;
														// Compute the weighted penalty using 60% weight on diff_nfp_max and 40% on diff_nfp_avg
														double penalty = 0.6 * diff_nfp_max + 0.4 * diff_nfp_avg;
														// Compute the final obj by exponentially penalizing the free space value
														obj = free_space * exp(-penalty);
													}
													if (i_obj == 1132) {
														double freeSpace = 0.5 * nfp_avg + 0.5 * nfp_min;
														double penalty = 0.2 * diff_nfp_max + 0.15 * diff_nfp_avg + 0.15 * diff_nfp_min;
														obj = freeSpace - penalty;
													}
													if (i_obj == 1133) {
														const double epsilon = 1e-6;
														double numerator = 0.50 * nfp_avg + 0.50 * nfp_min;
														double denominator = 1.0 + 0.60 * diff_nfp_max + 0.40 * diff_nfp_avg;
														obj = numerator / (denominator + epsilon);
													}
													if (i_obj == 1134) {
														const double epsilon = 1e-6;
														double ratioTerm = (0.53 * nfp_avg + 0.47 * nfp_min) / (1.0 + 0.60 * diff_nfp_max + 0.40 * diff_nfp_avg + epsilon);
														double logTerm = log((1.0 + 0.60 * nfp_avg + 0.40 * nfp_min) / (1.0 + 0.60 * diff_nfp_max + 0.40 * diff_nfp_avg + epsilon));
														obj = 0.55 * ratioTerm + 0.45 * logTerm;
													}
													if (i_obj == 1135) {
														const double epsilon = 1e-6;
														double numerator = 0.55 * nfp_avg + 0.45 * nfp_min;
														double denominator = 1.0 + 0.65 * diff_nfp_max + 0.35 * diff_nfp_avg;
														obj = numerator / (denominator + epsilon);
													}
													if (i_obj == 1141) {
														const double epsilon = 1e-6;
														// Compute a ratio-based obj that weights nfp_max more to account for potential space
														double ratioScore = (0.5 * nfp_max + 0.3 * nfp_avg + 0.2 * nfp_min) /
															(1.0 + 0.6 * diff_nfp_max + 0.4 * diff_nfp_avg + epsilon);
														// Compute a logarithmic penalty term balancing total free space with total space loss
														double logScore = log((1.0 + nfp_max + nfp_avg + nfp_min) /
															(1.0 + diff_nfp_max + diff_nfp_avg + epsilon));
														// Final obj is an average of the ratioScore and logScore with slightly higher weight on the ratioScore
														obj = 0.7 * ratioScore + 0.3 * logScore;
													}
													if (i_obj == 1142) {
														const double epsilon = 1e-6;
														// Compute geometric mean of the free space values
														double geomMean = pow((nfp_max + epsilon) * (nfp_min + epsilon) * (nfp_avg + epsilon), 1.0 / 3.0);
														// Compute total loss
														double totalLoss = diff_nfp_max + diff_nfp_min + diff_nfp_avg;
														// Exponential decay factor based on the loss, with a chosen decay rate
														double decayFactor = exp(-0.1 * totalLoss);
														obj = geomMean * decayFactor;
													}
													if (i_obj == 1143) {
														const double epsilon = 1e-6;
														double numerator = 0.6 * nfp_avg + 0.4 * nfp_min;
														double denominator = 1.0 + 0.60 * diff_nfp_max + 0.40 * diff_nfp_avg;
														obj = numerator / (denominator + epsilon);
													}
													if (i_obj == 1144) {
														const double epsilon = 1e-6;
														double ratioTerm = (0.56 * nfp_avg + 0.44 * nfp_min) / (1.0 + 0.62 * diff_nfp_max + 0.38 * diff_nfp_avg + epsilon);
														double logTerm = log((1.0 + 0.63 * nfp_avg + 0.37 * nfp_min) / (1.0 + 0.63 * diff_nfp_max + 0.37 * diff_nfp_avg + epsilon));
														obj = 0.6 * ratioTerm + 0.4 * logTerm;
													}
													if (i_obj == 1145) {
														const double epsilon = 1e-6;
														double numerator = 0.55 * nfp_avg + 0.45 * nfp_min;
														double denominator = 1.0 + 0.65 * diff_nfp_max + 0.35 * diff_nfp_avg;
														obj = numerator / (denominator + epsilon);
													}
													if (i_obj == 1151) {
														const double epsilon = 1e-6;
														// Compute the modified free-space ratio term
														double ratioTerm = (0.58 * nfp_avg + 0.42 * nfp_min) /
															(1.0 + 0.60 * diff_nfp_max + 0.40 * diff_nfp_avg + epsilon);
														// Compute a logarithmic term based on a slightly different weighted combination
														double freeSpaceNumerator = 1.0 + 0.65 * nfp_avg + 0.35 * nfp_min;
														double lossDenom = 1.0 + 0.65 * diff_nfp_max + 0.35 * diff_nfp_avg;
														double logTerm = log(freeSpaceNumerator / (lossDenom + epsilon));
														// Combine with a 70/30 weighting favoring the ratio
														obj = 0.70 * ratioTerm + 0.30 * logTerm;
													}
													if (i_obj == 1152) {
														const double epsilon = 1e-6;
														// Compute geometric means for free space and losses
														double free_geo = pow((nfp_max * nfp_min * nfp_avg) + epsilon, 1.0 / 3.0);
														double loss_geo = pow((diff_nfp_max * diff_nfp_min * diff_nfp_avg) + epsilon, 1.0 / 3.0);
														// Compute obj: free space multiplied by an exponential decay based on loss
														obj = free_geo * exp(-loss_geo);
													}
													if (i_obj == 1153) {
														const double epsilon = 1e-6;
														double numerator = 0.58 * nfp_avg + 0.42 * nfp_min;
														double denominator = 1.0 + 0.70 * diff_nfp_max + 0.30 * diff_nfp_avg;
														obj = numerator / (denominator + epsilon);
													}
													if (i_obj == 1154) {
														const double epsilon = 1e-6;
														double ratioTerm = (0.57 * nfp_avg + 0.43 * nfp_min) / (1.0 + 0.63 * diff_nfp_max + 0.37 * diff_nfp_avg + epsilon);
														double logTerm = log((1.0 + 0.62 * nfp_avg + 0.38 * nfp_min) / (1.0 + 0.62 * diff_nfp_max + 0.38 * diff_nfp_avg + epsilon));
														obj = 0.65 * ratioTerm + 0.35 * logTerm;
													}
													if (i_obj == 1155) {
														const double epsilon = 1e-6;
														double numerator = 0.57 * nfp_avg + 0.43 * nfp_min;
														double denominator = 1.0 + 0.63 * diff_nfp_max + 0.37 * diff_nfp_avg;
														obj = numerator / (denominator + epsilon);
													}
													if (i_obj == 1161) {
														const double epsilon = 1e-6;
														double weightedFree = 0.58 * nfp_avg + 0.42 * nfp_min;
														double weightedLoss = 1.0 + 0.65 * diff_nfp_max + 0.35 * diff_nfp_avg;
														double ratioTerm = weightedFree / (weightedLoss + epsilon);
														double logTerm = log((1.0 + 0.60 * nfp_avg + 0.40 * nfp_min) / (1.0 + 0.60 * diff_nfp_max + 0.40 * diff_nfp_avg + epsilon));
														obj = ratioTerm + 0.1 * logTerm;
													}
													if (i_obj == 1162) {
														double free_space = 0.55 * nfp_avg + 0.45 * nfp_min;
														double loss = 0.6 * diff_nfp_max + 0.4 * diff_nfp_avg;
														obj = free_space * exp(-loss);
													}
													if (i_obj == 1163) {
														const double epsilon = 1e-6;
														double numerator = 0.58 * nfp_avg + 0.42 * nfp_min;
														double denominator = 1.0 + 0.66 * diff_nfp_max + 0.34 * diff_nfp_avg;
														obj = numerator / (denominator + epsilon);
													}
													if (i_obj == 1164) {
														const double epsilon = 1e-6;
														// Weighted numerator: average of parameters from two heuristics
														double numerator = 0.585 * nfp_avg + 0.415 * nfp_min;
														// Weighted denominator: average loss penalty from two heuristics
														double denominator = 1.0 + 0.665 * diff_nfp_max + 0.335 * diff_nfp_avg;
														double ratioTerm = numerator / (denominator + epsilon);

														// Logarithmic term with similar weighted averages for free space and loss
														double numerator_log = 1.0 + 0.62 * nfp_avg + 0.38 * nfp_min;
														double denominator_log = 1.0 + 0.62 * diff_nfp_max + 0.38 * diff_nfp_avg;
														double logTerm = log(numerator_log / (denominator_log + epsilon));

														obj = 0.625 * ratioTerm + 0.375 * logTerm;
													}
													if (i_obj == 1165) {
														const double epsilon = 1e-6;
														double numerator = 0.57 * nfp_avg + 0.43 * nfp_min;
														double denominator = 1.0 + 0.63 * diff_nfp_max + 0.37 * diff_nfp_avg;
														obj = numerator / (denominator + epsilon);
													}
													if (i_obj == 1171) {
														const double epsilon = 1e-6;
														double free_space = 0.56 * nfp_avg + 0.44 * nfp_min;
														double loss = 1.0 + 0.62 * diff_nfp_max + 0.30 * diff_nfp_avg + 0.08 * diff_nfp_min;
														double ratio = free_space / (loss + epsilon);
														obj = sqrt(ratio);
													}
													if (i_obj == 1172) {
														// Calculate the free-space metric as the geometric mean of nfp_avg and nfp_min.
														double free_metric = std::sqrt(nfp_avg * nfp_min);

														// Calculate the loss metric as the combination of the geometric mean of diff_nfp_max and diff_nfp_avg,
														// augmented by a smaller linear contribution from diff_nfp_min.
														double loss_metric = 0.7 * std::sqrt(diff_nfp_max * diff_nfp_avg) + 0.3 * diff_nfp_min;

														// The final obj is the free metric reduced by the loss penalty.
														obj = free_metric - loss_metric;
													}
													if (i_obj == 1173) {
														const double epsilon = 1e-6;
														double numerator = 0.59 * nfp_avg + 0.41 * nfp_min;
														double denominator = 1.0 + 0.67 * diff_nfp_max + 0.33 * diff_nfp_avg;
														obj = numerator / (denominator + epsilon);
													}
													if (i_obj == 1174) {
														const double epsilon = 1e-6;
														double ratioTerm = (0.57 * nfp_avg + 0.43 * nfp_min) / (1.0 + 0.63 * diff_nfp_max + 0.37 * diff_nfp_avg + epsilon);
														double logTerm = log((1.0 + 0.60 * nfp_avg + 0.40 * nfp_min) / (1.0 + 0.60 * diff_nfp_max + 0.60 * diff_nfp_avg + epsilon));
														obj = 0.6 * ratioTerm + 0.4 * logTerm;
													}
													if (i_obj == 1175) {
														const double epsilon = 1e-6;
														double freeSpace = 0.57 * nfp_avg + 0.43 * nfp_min;
														double lossPenalty = 1.0 + 0.63 * diff_nfp_max + 0.37 * diff_nfp_avg;
														obj = freeSpace / (lossPenalty + epsilon);
													}
													if (i_obj == 1181) {
														const double epsilon = 1e-6;
														double baseRatio = (0.56 * nfp_avg + 0.44 * nfp_min) /
															(1.0 + 0.64 * diff_nfp_max + 0.36 * diff_nfp_avg + epsilon);
														double logAdjustment = log((1.0 + 0.60 * nfp_avg + 0.40 * nfp_min) /
															(1.0 + 0.60 * diff_nfp_max + 0.40 * diff_nfp_avg + epsilon) + epsilon);
														double minDiffPenalty = 0.1 * diff_nfp_min;
														obj = baseRatio + 0.5 * logAdjustment - minDiffPenalty;
													}
													if (i_obj == 1182) {
														const double epsilon = 1e-6;
														double freeScore = log(1.0 + 0.3 * nfp_max + 0.3 * nfp_avg + 0.4 * nfp_min + epsilon);
														double lossPenalty = 0.4 * diff_nfp_max + 0.3 * diff_nfp_avg + 0.3 * diff_nfp_min;
														obj = freeScore - lossPenalty;
													}
													if (i_obj == 1183) {
														const double epsilon = 1e-6;
														double ratioTerm = (0.56 * nfp_avg + 0.44 * nfp_min) /
															(1.0 + 0.62 * diff_nfp_max + 0.38 * diff_nfp_avg + epsilon);
														double logTerm = log((1.0 + 0.61 * nfp_avg + 0.39 * nfp_min) /
															(1.0 + 0.61 * diff_nfp_max + 0.39 * diff_nfp_avg + epsilon));
														obj = 0.60 * ratioTerm + 0.40 * logTerm;
													}
													if (i_obj == 1184) {
														const double epsilon = 1e-6;
														double ratioTerm = (0.57 * nfp_avg + 0.43 * nfp_min) /
															(1.0 + 0.63 * diff_nfp_max + 0.37 * diff_nfp_avg + epsilon);
														double logTerm = log((1.0 + 0.60 * nfp_avg + 0.40 * nfp_min) /
															(1.0 + 0.60 * diff_nfp_max + 0.40 * diff_nfp_avg + epsilon));
														obj = 0.60 * ratioTerm + 0.40 * logTerm;
													}
													if (i_obj == 1185) {
														const double epsilon = 1e-6;
														double numerator = 0.57 * nfp_avg + 0.43 * nfp_min;
														double denominator = 1.0 + 0.63 * diff_nfp_max + 0.37 * diff_nfp_avg;
														obj = numerator / (denominator + epsilon);
													}
													if (i_obj == 1191) {
														const double epsilon = 1e-6;
														// Compute weighted free space using avg and min values
														double weightedFree = 0.56 * nfp_avg + 0.44 * nfp_min;
														// Penalize by aggregating difference losses, including diff_nfp_min with a smaller weight
														double weightedLoss = 1.0 + 0.64 * diff_nfp_max + 0.18 * diff_nfp_avg + 0.18 * diff_nfp_min;
														double ratioTerm = weightedFree / (weightedLoss + epsilon);
														// Compute separate logarithmic terms for a complementary adjustment
														double freeLog = log(1.0 + 0.55 * nfp_avg + 0.45 * nfp_min);
														double diffLog = log(1.0 + 0.55 * diff_nfp_max + 0.275 * diff_nfp_avg + 0.275 * diff_nfp_min);
														double logTerm = freeLog / (diffLog + epsilon);
														// Combine the ratio and log terms with a 60/40 mix
														obj = 0.60 * ratioTerm + 0.40 * logTerm;
													}
													if (i_obj == 1192) {
														// Compute a weighted free-space metric.
														double weightedFree = 0.60 * nfp_avg + 0.40 * nfp_min;
														// Compute a weighted penalty including all three difference metrics.
														double weightedLoss = 0.50 * diff_nfp_max + 0.30 * diff_nfp_avg + 0.20 * diff_nfp_min;
														// Apply an exponential decay to the free-space metric based on the loss.
														obj = weightedFree * exp(-weightedLoss);
													}
													if (i_obj == 1193) {
														const double epsilon = 1e-6;
														double numerator = 0.56 * nfp_avg + 0.44 * nfp_min;
														double denominator = 1.0 + 0.64 * diff_nfp_max + 0.36 * diff_nfp_avg;
														obj = numerator / (denominator + epsilon);
													}
													if (i_obj == 1194) {
														const double epsilon = 1e-6;
														double ratioTerm = (0.57 * nfp_avg + 0.43 * nfp_min) /
															(1.0 + 0.63 * diff_nfp_max + 0.37 * diff_nfp_avg + epsilon);
														double logTerm = log((1.0 + 0.62 * nfp_avg + 0.38 * nfp_min) /
															(1.0 + 0.62 * diff_nfp_max + 0.38 * diff_nfp_avg + epsilon));
														obj = 0.70 * ratioTerm + 0.30 * logTerm;
													}
													if (i_obj == 1195) {
														const double epsilon = 1e-6;
														double numerator = 0.57 * nfp_avg + 0.43 * nfp_min;
														double denominator = 1.0 + 0.63 * diff_nfp_max + 0.37 * diff_nfp_avg;
														obj = numerator / (denominator + epsilon);
													}
													if (i_obj == 1201) {
														const double epsilon = 1e-6;
														double numerator = 0.56 * nfp_avg + 0.44 * nfp_min;
														double denominator = 1.0 + 0.64 * diff_nfp_max + 0.36 * diff_nfp_avg;
														obj = numerator / (denominator + epsilon);
													}
													if (i_obj == 1202) {
														const double epsilon = 1e-6;
														double numerator = 0.57 * nfp_avg + 0.43 * nfp_min;
														double denominator = 1.0 + 0.63 * diff_nfp_max + 0.37 * diff_nfp_avg;
														obj = numerator / (denominator + epsilon);
													}
													if (i_obj == 1203) {
														const double epsilon = 1e-6;
														double ratioTerm = (0.57 * nfp_avg + 0.43 * nfp_min) /
															(1.0 + 0.63 * diff_nfp_max + 0.37 * diff_nfp_avg + epsilon);
														double logTerm = log((1.0 + 0.62 * nfp_avg + 0.38 * nfp_min) /
															(1.0 + 0.62 * diff_nfp_max + 0.38 * diff_nfp_avg + epsilon));
														obj = 0.70 * ratioTerm + 0.30 * logTerm;
													}
													if (i_obj == 1204) {
														const double epsilon = 1e-6;
														double ratioTerm = (0.57 * nfp_avg + 0.43 * nfp_min) / (1.0 + 0.63 * diff_nfp_max + 0.37 * diff_nfp_avg + epsilon);
														double logTerm = log((1.0 + 0.62 * nfp_avg + 0.38 * nfp_min) / (1.0 + 0.62 * diff_nfp_max + 0.38 * diff_nfp_avg + epsilon));
														obj = 0.65 * ratioTerm + 0.35 * logTerm;
													}
													if (i_obj == 1205) {
														const double epsilon = 1e-6;
														double numerator = 0.58 * nfp_avg + 0.42 * nfp_min;
														double denominator = 1.0 + 0.66 * diff_nfp_max + 0.34 * diff_nfp_avg;
														obj = numerator / (denominator + epsilon);
													}
													best_coords_local[i_poi] = { obj, vi_x, vi_y };
													best_feasibles_vec_local[i_poi] = feasible_vec_local;
													area_nfps_vec[i_poi] = area_nfps;
												});

										}

										for (int i_poi = 0; i_poi < coord_ll_to_compare.size(); ++i_poi) {
											t_poi[i_poi].join();
										}

										double best_obj_local = -100000000;
										std::vector<double> best_coord_local;
										std::vector<double> best_area_nfps_local;
										std::vector<Polygon_set_2> best_feasible_vec_local;
										for (int i_poi = 0; i_poi < coord_ll_to_compare.size(); ++i_poi) {
											if (best_coords_local[i_poi][0] > best_obj_local) {
												best_obj_local = best_coords_local[i_poi][0];
												best_coord_local = { best_coords_local[i_poi][1], best_coords_local[i_poi][2] };
												best_feasible_vec_local = best_feasibles_vec_local[i_poi];
												best_area_nfps_local = area_nfps_vec[i_poi];
											}
										}

										if (best_obj_local > best_obj) {
											best_obj = best_obj_local;
											best_coord = best_coord_local;
											best_i_eve = i_eve;
											best_feasible_vec = best_feasible_vec_local;
											best_area_nfps = best_area_nfps_local;
										}
									}

									if (best_obj == -100000000)
										break;

									//pgns_to_draw.push_back(Polygon_2_trans(Polygon_2_turn_acw(piece, 2.0 * PI / eve_n * best_i_eve),
									//	best_coord[0], best_coord[1]));
									res_coords.push_back({ best_coord[0], best_coord[1] });
									i_eves.push_back(best_i_eve);
									//std::cout << "best_i_eve: " << best_i_eve << std::endl;

									/*
									if (feasible.number_of_polygons_with_holes() == 0) {
										break;
									}
									std::list<Polygon_with_holes_2> res;
									std::list<Polygon_with_holes_2>::const_iterator it;

									double best_obj = 100000;
									std::vector<double> best_coord(2);
									feasible.polygons_with_holes(std::back_inserter(res));
									for (it = res.begin(); it != res.end(); ++it) {
										Polygon_2 ob = it->outer_boundary();
										for (VertexIterator vi = ob.vertices_begin(); vi != ob.vertices_end(); ++vi) {
											double vi_x = to_double(vi->x().approx());
											double vi_y = to_double(vi->y().approx());
											double obj = vi_x * x_para + vi_y * y_para;
											if (obj < best_obj) {
												best_obj = obj;
												best_coord = {vi_x, vi_y};
											}
										}
									}
									res_coords.push_back(best_coord);
									Polygon_with_holes_2 mink_res_2d = CGAL::minkowski_sum_2(Polygon_2_trans(piece,
										best_coord[0], best_coord[1]), Polygon_2_turn_acw(piece, PI));
									feasible.difference(mink_res_2d);
									num_packed++;
									std::cout << num_packed << std::endl;
									*/

									feasible_vec = best_feasible_vec;
									/*
									for (int i_eve = 0; i_eve < eve_n; ++i_eve) {
										//std::cout << "updating: i_eve: " << i_eve << std::endl;
										/*
										if (i_eve == 2) {
											Polygon_set_2 pgn_set_temp = feasible_vec[i_eve];
											CGAL::draw(pgn_set_temp);
											Polygon_2 nfp_trans = Polygon_2_trans(nfp_vv[i_eve][best_i_eve], best_coord[0],
												best_coord[1]);
											nfp_trans = nfp_vv[i_eve][best_i_eve];
											std::cout << nfp_trans << std::endl;
											CGAL::draw(nfp_trans);
											Polygon_set_2 test;
											test.insert(nfp_trans);
											CGAL::draw(test);
											test.difference(pgn_set_temp);
											CGAL::draw(test);
											test.difference(nfp_trans);
											CGAL::draw(test);
											pgn_set_temp.difference(test);
											CGAL::draw(pgn_set_temp);
										}
										/
										feasible_vec[i_eve].difference(Polygon_2_trans(nfp_vv[i_eve][best_i_eve], best_coord[0],
											best_coord[1]));
									}
									*/
									fin_nfp_perc = pre_area_nfps[best_i_eve] / bbox_area;
									pre_area_nfps = best_area_nfps;
									num_packed++;
									std::cout << "num_packed: " << num_packed << std::endl;
								}
							}

							DWORD t_heu2 = GetTickCount64();
							double t_heu = (t_heu2 - t_heu1) * 1.0 / 1000;

							kp_str = "D:/Ph.D/Code/Packing/data/packing/plane results/p"
								+ std::to_string(id_piece) + "s" + std::to_string(id_sheet) + "e"
								+ std::to_string(eve_n) + "t" + std::to_string(i_obj) + ".txt";
							out_num.open(kp_str.c_str(), std::ios::out | std::ios::app);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
							out_num << num_packed << " " << t_heu << "\n";
							for (int i_piece = 0; i_piece < num_packed; ++i_piece) {
								out_num << res_coords[i_piece][0] << " " << res_coords[i_piece][1] << " "
									<< 360.0 / eve_n * i_eves[i_piece] << "\n";
							}
							out_num.close();

							if (num_packed > targ_num[id_piece - 1][id_sheet - 1])
								whe_targ[id_piece - 1][id_sheet - 1] = 1;
							std::vector<double> res_output = { double(id_piece), double(id_sheet), double(eve_n), double(i_obj),
									double(num_packed), t_heu, fin_nfp_perc, double(whe_targ[id_piece - 1][id_sheet - 1]) };
							if (num_packed > best_num[id_piece - 1][id_sheet - 1]) {
								best_res_output[id_sheet - 1] = res_output;
							}

							kp_str = "D:/Ph.D/Code/Packing/data/packing/plane results/all_1.txt";
							out_num.open(kp_str.c_str(), std::ios::out | std::ios::app);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
							for (int i_res = 0; i_res < res_output.size(); ++i_res) {
								out_num << res_output[i_res] << " ";
							}
							out_num << "\n";
							out_num.close();
						}
					}
				}
				/*
				kp_str = "D:/Ph.D/Code/Packing/data/packing/plane results/all.txt";
				out_num.open(kp_str.c_str(), std::ios::out | std::ios::app);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
				for (int i_sh = 0; i_sh < best_res_output.size(); ++i_sh) {
					for (int i_res = 0; i_res < best_res_output[i_sh].size(); ++i_res) {
						out_num << best_res_output[i_sh][i_res] << " ";
					}
					out_num << "\n";
				}
				out_num.close();
				*/
			}
		}
	}
	else {
		std::cout << "请输入选择几个均分角度进行比较，按回车结束" << std::endl;
		std::cin >> eve_n;

		std::cout << "请输入要使用哪一个零件（编号1-9），按回车结束" << std::endl;
		std::cin >> id_piece;

		std::cout << "请输入要使用哪一块板材（编号1-5），按回车结束" << std::endl;
		std::cin >> id_sheet;

		c_Point_list_2 c_points_piece = input_polygon("D:/Ph.D/Code/Packing/data/packing/Plane with key points/Pieces/piece " + std::to_string(id_piece) + ".xyz");

		FILE* fp;
		std::string kp_str = "D:/Ph.D/Code/Packing/data/packing/Plane with key points/Pieces/key points " + std::to_string(id_piece) + ".txt";
		fp = fopen(kp_str.c_str(), "r");
		std::vector<std::vector<double>> key_points;
		for (int i_case = 0; i_case < 3; ++i_case) {
			std::vector<double> key_point(2);
			for (int i_id = 0; i_id < 2; ++i_id) {
				fscanf(fp, "%lf", &key_point[i_id]);
			}
			key_points.push_back(key_point);
		}
		fclose(fp);

		std::vector<double> cc_piece(2);
		Polygon_2 piece;
		// for (c_Point_list_2::const_iterator it = c_points_piece.begin(); it != c_points_piece.end(); ++it)
		//	piece.push_back(Point_2(it->x(), it->y()));
		// CGAL::draw(piece);
		piece = init_min_c_c(c_points_piece, cc_piece).outer_boundary();
		Polygon_2 key_point_hole;
		for (int i_poi = 0; i_poi < 3; ++i_poi)
			key_point_hole.push_back(Point_2(key_points[i_poi][0] - cc_piece[0], key_points[i_poi][1]
				- cc_piece[1]));

		c_Point_list_2 c_points_sheet = input_polygon("D:/Ph.D/Code/Packing/data/packing/Plane with key points/Sheets/sheet " + std::to_string(id_sheet) + ".xyz");

		std::vector < c_Point_list_2 > vec_c_points_holes;
		for (int i_p_num = 0; i_p_num < sheet_holes[id_sheet - 1]; ++i_p_num) {
			c_Point_list_2 vec_c_points_hole = input_polygon("D:/Ph.D/Code/Packing/data/packing/Plane with key points/Sheets/sheet " + std::to_string(id_sheet) + "h" + std::to_string(i_p_num + 1) + ".xyz");
			vec_c_points_holes.push_back(vec_c_points_hole);
		}

		Polygon_2 sheet;
		for (c_Point_list_2::const_iterator it = c_points_sheet.begin(); it != c_points_sheet.end(); ++it)
			sheet.push_back(Point_2(it->x(), it->y()));

		std::vector<Polygon_2> holes(sheet_holes[id_sheet - 1]);
		for (int i_p_num = 0; i_p_num < sheet_holes[id_sheet - 1]; ++i_p_num) {
			for (c_Point_list_2::const_iterator it = vec_c_points_holes[i_p_num].begin(); it
				!= vec_c_points_holes[i_p_num].end(); ++it)
				holes[i_p_num].push_back(Point_2(it->x(), it->y()));
		}

		std::vector<Polygon_2> pgns_to_draw;
		pgns_to_draw.push_back(sheet);
		for (int i_p_num = 0; i_p_num < sheet_holes[id_sheet - 1]; ++i_p_num)
			pgns_to_draw.push_back(holes[i_p_num]);

		kp_str = "D:/Ph.D/Code/Packing/data/packing/plane results/p"
			+ std::to_string(id_piece) + "s" + std::to_string(id_sheet) + "e"
			+ std::to_string(eve_n) + "t" + std::to_string(i_obj) + ".txt";
		fp = fopen(kp_str.c_str(), "r");
		int num_packed;
		fscanf(fp, "%d", &num_packed);
		double time_spent;
		fscanf(fp, "%lf", &time_spent);
		std::vector<std::vector<double>> pack_results;
		for (int i_case = 0; i_case < num_packed; ++i_case) {
			std::vector<double> pack_result(3);
			for (int i_id = 0; i_id < 3; ++i_id) {
				fscanf(fp, "%lf", &pack_result[i_id]);
			}
			pgns_to_draw.push_back(Polygon_2_trans(Polygon_2_turn_acw(piece, 2.0 * PI / 360 * pack_result[2]),
				pack_result[0], pack_result[1]));
			pack_results.push_back(pack_result);
		}
		fclose(fp);

		double length = 0;
		double width = 0;
		for (VertexIterator vi = sheet.vertices_begin(); vi != sheet.vertices_end(); ++vi) {
			double vi_x = to_double(vi->x().approx());
			double vi_y = to_double(vi->y().approx());
			if (vi_x > length)
				length = vi_x;
			if (vi_y > width)
				width = vi_y;
		}
		draw_whole_res(length, width, pgns_to_draw, max(width / 40, length / 100));
	}
	//for (int i_num = 0; i_num < num_packed; i_num++) {
	//	pgns_to_draw.push_back(Polygon_2_trans(piece, res_coords[i_num][0], res_coords[i_num][1]));
	//}
	/*
	pgns_to_draw.push_back(sheet);

	double length = 0;
	double width = 0;
	for (VertexIterator vi = sheet.vertices_begin(); vi != sheet.vertices_end(); ++vi) {
		double vi_x = to_double(vi->x().approx());
		double vi_y = to_double(vi->y().approx());
		if (vi_x > length)
			length = vi_x;
		if (vi_y > width)
			width = vi_y;
	}
	draw_whole_res(length, width, pgns_to_draw, length / 80);
	*/

	return 0;
}

/*
\n 换行符(LF)

\r 回车(CR) ，相当于键盘上的"Enter"

\t 跳到下一个TAB位置

\0 空字符(NULL)

\' 单引号（撇号）

\" 双引号

\\ 代表一个反斜线字符''\'

\ 继续符，可用于一行的结尾，表示本行与下一行连接起来
*/