﻿//一个个加入多边形，一个个优化，数据集用poly，故意拖慢一点，不用bin，而用每一个多边形凸分解，用竞争性角度启发式求解
#include <list>
#include <iostream>
#include <fstream>
#include <cassert>

#include <thread>

#include <ilcplex\ilocplex.h>
ILOSTLBEGIN // 等同于 using namespace std; 声明命名空间

#include <Eigen/Dense>

#include <CGAL/IO/read_points.h>

#include <CGAL/Simple_cartesian.h>
#include <CGAL/Min_sphere_of_spheres_d.h>
#include <CGAL/Min_sphere_of_points_d_traits_2.h>
#include <CGAL/Random.h>

#include <CGAL/Exact_predicates_exact_constructions_kernel.h>
#include <CGAL/Polygon_2.h>
#include <CGAL/Polygon_with_holes_2.h>
#include <CGAL/Polygon_set_2.h>

#include <CGAL/Boolean_set_operations_2.h>

#include <CGAL/draw_polygon_set_2.h>
#include <CGAL/draw_polygon_2.h>
#include <CGAL/draw_polygon_with_holes_2.h>

#include <CGAL/Polyhedron_3.h>
#include <CGAL/Nef_polyhedron_3.h>
#include <CGAL/minkowski_sum_2.h>
#include <CGAL/minkowski_sum_3.h>
#include <CGAL/partition_2.h>
#include <CGAL/Partition_traits_2.h>
#include <CGAL/IO/Nef_polyhedron_iostream_3.h>
#include <CGAL/Nef_3/SNC_indexed_items.h>
#include <CGAL/convex_decomposition_3.h>
#include <CGAL/convex_hull_3.h>

#include <CGAL/draw_polyhedron.h>
#include <CGAL/draw_nef_3.h>

#include <CGAL/Epick_d.h>
#include <CGAL/Triangulation.h>

#include "gurobi_c++.h"

#include <draw_res.h>
#include <point_calculation.h>
#include <input_initialize.h>
#include <calculate_2d.h>
#include <calculate_3d.h>
#include <generate_para_2d.h>
#include <generate_para_3d.h>
#include <generate_para_4d.h>
#include <test_draw.h>
#include <try_program.h>
#include <draw_whole_res.h>
#include <scip_program.h>
#include <gurobi_program.h>


#define PI 3.1415926535

#define Epsilon 0.00000001

typedef CGAL::Exact_predicates_exact_constructions_kernel K;
typedef CGAL::Polygon_2<K>                                Polygon_2;
typedef CGAL::Polygon_with_holes_2<K>                     Polygon_with_holes_2;
typedef CGAL::Polygon_set_2<K>                            Polygon_set_2;
typedef CGAL::Point_2<K>                                  Point_2;
typedef CGAL::Vector_2<K>                                 Vector_2;
typedef CGAL::Point_3<K>                                  Point_3;
typedef CGAL::Polyhedron_3<K>							  Polyhedron;
typedef CGAL::Nef_polyhedron_3<K>						  Nef_polyhedron;
//typedef K::Point_2										  Point;
using std::cout;
using std::endl;

typedef CGAL::Simple_cartesian<double>                   c_K;//引自参考min_circle_2的例子
typedef CGAL::Min_sphere_of_points_d_traits_2<c_K, double>   c_Traits;
typedef CGAL::Min_sphere_of_spheres_d<c_Traits>            Min_circle;
typedef CGAL::Point_2<c_K>                                 c_Point_2;
typedef CGAL::Polygon_2<c_K>                                c_Polygon_2;
typedef c_K::Point_3									   input_Point;

typedef CGAL::Partition_traits_2<K>                         Traits;
typedef Traits::Polygon_2                                   p_Polygon_2;
typedef Traits::Point_2                                     p_Point_2;

typedef Polygon_2::Vertex_iterator						  VertexIterator;
typedef Polygon_2::Edge_const_iterator					  EdgeIterator;
typedef p_Polygon_2::Vertex_iterator					  p_VertexIterator;
typedef Nef_polyhedron::Volume_const_iterator			  Volume_const_iterator;
typedef Polyhedron::Vertex_iterator						  phd_VertexIterator;
typedef Polyhedron::Facet_iterator					      phd_FacetIterator;
//typedef Nef_polyhedron::Vertex_iterator					  N_phd_VertexIterator;
typedef Nef_polyhedron::Aff_transformation_3			  Aff_transformation_3;
typedef Polyhedron::Halfedge_around_facet_circulator	  Halfedge_facet_circulator;

typedef CGAL::Epick_d<CGAL::Dynamic_dimension_tag>		  D_dim;
typedef CGAL::Triangulation<D_dim>                        Triangulation;
typedef CGAL::Triangulation_data_structure<D_dim>         TDS;
typedef Triangulation::Point			                  D_dim_point;
typedef Triangulation::Full_cell_handle					  Full_cell_handle;
typedef Triangulation::Facet							  Facet;
typedef Triangulation::Face								  Face;

typedef std::list<Point_2>								  Point_list_2;
typedef std::list<c_Point_2>							  c_Point_list_2;
typedef std::list<p_Polygon_2>                            p_Pgn_list_2;
typedef std::list<Point_3>								  Point_list_3;
typedef std::list<Polygon_with_holes_2>                   Pwh_list_2;
typedef std::list<Polygon_2>							  Pgn_list_2;
typedef std::list<Nef_polyhedron>						  N_phd_list;
typedef std::list<Polyhedron>							  phd_list;
typedef std::vector<Full_cell_handle>					  Full_cells;
typedef std::vector<Face>								  Faces;

bool res_sort_nfp(std::vector<double> a, std::vector<double> b) {
	if (a[0] < b[0] + Epsilon && b[0] < a[0] + Epsilon)
		return a[1] < b[1];//如果目标函数一样，重合面积升序
	else
		return a[0] < b[0];//目标函数升序(小的放前面)
}

bool res_sort_ifp(std::vector<double> a, std::vector<double> b) {
	if (a[4] == b[4])
		return a[0] < b[0];//如果ifp编号一样，目标函数升序
	else
		return a[4] < b[4];//ifp编号升序(小的放前面)
}

//根据数组第一位（下标为0），升序排序（小的放前面）
bool res_sort_0(std::vector<double> a, std::vector<double> b) {
	return a[0] < b[0];//ifp编号升序(小的放前面)
}

int main()
{
	std::cout.precision(14);
	std::ofstream out_try;
	out_try.precision(14);
	out_try.open("D:/Ph.D/Code/Packing/data/packing/run_try.txt", std::ios::out);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
	out_try.close();
	//std::ofstream out_eve;
	//out_eve.precision(14);
	//out_eve.open("D:/Ph.D/Code/Packing/data/packing/run_eve.txt", std::ios::out);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
	//out_eve.close();
	std::ofstream out_coord;
	out_coord.precision(14);
	out_coord.open("D:/Ph.D/Code/Packing/data/packing/coord_testtest.txt", std::ios::out);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
	out_coord.close();
	int polygon_num;
	polygon_num = 30;
	//std::cout << "请输入多边形数量，按回车结束" << std::endl;
	//std::cin >> polygon_num;
	std::vector < c_Point_list_2 > vec_c_points = input_polygons(polygon_num, "D:/Ph.D/Code/Packing/data/packing/poly/polygon_");

	double width;
	width = 40;
	//std::cout << "请输入箱子宽度，按回车结束" << std::endl;
	//std::cin >> width;
	double length;
	length = 40;
	//std::cout << "请输入箱子长度，按回车结束" << std::endl;
	//std::cin >> length;

	double alpha_obj;
	alpha_obj = 0.001;
	//std::cout << "请输入目标函数x+αy中的系数α，按回车结束" << std::endl;
	//std::cin >> alpha_obj;

	double beta_obj;
	beta_obj = 0.00001;
	//std::cout << "请输入目标函数中零件坐标x+y的系数β，按回车结束" << std::endl;
	//std::cin >> beta_obj;

	double ang_step_size;
	ang_step_size = 30;
	//std::cout << "请输入角度步长，按回车结束" << std::endl;
	//std::cin >> ang_step_size;

	int eve_n;
	eve_n = 8;
	//std::cout << "请输入选择几个均分角度进行比较，按回车结束" << std::endl;
	//std::cin >> eve_n;

	int try_n;
	try_n = 3;
	//std::cout << "请输入选择前几个竞争力角度进行比较，按回车结束" << std::endl;
	//std::cin >> try_n;

	std::vector<double> polygons_symm(polygon_num, 1);
	//要改！

	//非线性规划情况下，D-function，大概是最大的图形的最长的一条线的长度*sqrt(2)*length
	double big_m_nonlin = 2 * max(length, width) * max(length, width);

	double time_lim = 3600;

	std::vector<Polygon_with_holes_2> pwhs(polygon_num);
	std::vector<Polygon_2> pgns(polygon_num);
	std::vector<Polygon_2> pgns_trans(polygon_num);
	std::vector<Polygon_2> pgns_inset(polygon_num);
	//std::vector<std::list<Nef_polyhedron>> N_pgn_par_lists;
	std::vector<std::vector<double>> pgns_bbox;//每个图形都有一个四维变量，保存着minx，miny，maxx，maxy

	for (int i_p_num = 0; i_p_num < polygon_num; ++i_p_num) {
		std::vector<double> pgn_bbox;
		//调整图形位置，后续需要
		pwhs[i_p_num] = init_min_c(vec_c_points[i_p_num], pgn_bbox);
		//对图形不进行旋转
		pgns[i_p_num] = pwhs[i_p_num].outer_boundary();
		pgns_inset[i_p_num] = Polygon_2_inset(pgns[i_p_num], 0.0000001);
		//CGAL::draw(pwhs[i_p_num]);
		pgn_bbox = bbox_cal(pgns[i_p_num]);
		pgns_bbox.push_back(pgn_bbox);
		//std::list<Nef_polyhedron> N_pgn_par_list;
		//decomp_2(pgns[i_p_num], N_pgn_par_list);
		//N_pgn_par_lists.push_back(N_pgn_par_list);
	}

	std::vector<double> angles_o;//origin（用来对比的）
	angles_o.push_back(0);
	angles_o.push_back(PI / 2);
	angles_o.push_back(PI);
	angles_o.push_back(3 * PI / 2);

	//bin只包含箱子的形状
	std::vector<Polygon_with_holes_2> bin_pwh_vec;
	//Pwh_list_2                  ifp_pwh_list;
	std::vector<Polygon_with_holes_2>::const_iterator  it;

	Point_list_2 poi_box = { Point_2(-1, -1), Point_2(length + 1, -1),
			Point_2(length + 1, width + 1), Point_2(-1, width + 1) };
	Polygon_with_holes_2 ifp_box(Polygon_2(poi_box.begin(), poi_box.end()));
	Point_list_2 poi_bin = { Point_2(0, 0), Point_2(length, 0),
			Point_2(length, width), Point_2(0, width) };
	Polygon_with_holes_2 bin_pwh(Polygon_2(poi_bin.begin(), poi_bin.end()));
	bin_pwh_vec.push_back(bin_pwh);

	//ifp是将箱子挖空后的有孔多边形
	std::vector<Polygon_with_holes_2> ifp_pwh_vec;
	Polygon_with_holes_2 ifp_pwh;
	//如果报错说明difference结果不是一个图形，而是多个图形
	difference(ifp_box, bin_pwh, &ifp_pwh);
	ifp_pwh_vec.push_back(ifp_pwh);

	//CGAL::intersection(pgn_n, Polygon_2(poi_obj.begin(), poi_obj.end()), std::back_inserter(ifp_pwh_vec));
	std::vector<std::list<Nef_polyhedron>> N_pgn_par_lists;
	std::vector<std::vector<double>> coord_all;

	for (int i_p_num = 0; i_p_num < polygon_num; ++i_p_num) {

		std::vector<std::vector<double>> res_fin;

		//测试竞争力角度情况
		DWORD t_try1 = GetTickCount64();
		//obj, ra_turn, lowerbound, upperbound, x_coord, y_coord, xobj, time
		std::vector<double> res_try(8);
		{
			std::vector<double> obj_try_min;
			std::vector<double> coord_try_min;
			double ra_try_min;

			try_program_one_by_one_try(length, width, alpha_obj, i_p_num, pgns, coord_all, angles_o,
				polygons_symm[i_p_num], obj_try_min, coord_try_min, ra_try_min);

			res_try[0] = obj_try_min[2];
			res_try[1] = ra_try_min;
			res_try[2] = 0;
			res_try[3] = obj_try_min[2];
			res_try[4] = coord_try_min[0];
			res_try[5] = coord_try_min[1];
			res_try[6] = obj_try_min[0];
		}
		DWORD t_try2 = GetTickCount64();
		res_try[7] = (t_try2 - t_try1) * 1.0 / 1000;
		res_fin.push_back(res_try);
		out_try.open("D:/Ph.D/Code/Packing/data/packing/run_try.txt", std::ios::out | std::ios::app);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
		for (int i = 0; i < res_try.size(); ++i) {
			out_try << res_try[i] << " ";
		}
		out_try << "\n";
		out_try.close();

		sort(res_fin.begin(), res_fin.end(), res_sort_0);

		std::vector<double> obj_fin = { 0,0,res_fin[0][0] };
		std::vector<double> coord_fin = { res_fin[0][4], res_fin[0][5] };

		coord_all.push_back({ coord_fin[0], coord_fin[1] });

		out_coord.open("D:/Ph.D/Code/Packing/data/packing/coord_testtest.txt", std::ios::out | std::ios::app);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
		out_coord << coord_fin[0] << " " << coord_fin[1] << " " << res_fin[0][1] << "\n";
		out_coord.close();

		for (int i_output_co = 0; i_output_co < coord_all.size(); ++i_output_co) {
			std::cout << coord_all[i_output_co][0] << " " << coord_all[i_output_co][1] << std::endl;
		}

		if (i_p_num >= 29)
			draw_whole_res(i_p_num, length, width, pgns, res_fin[0][1], obj_fin, coord_all);

		//为下一个图形做准备
		if (i_p_num < polygon_num - 1) {
			pgns[i_p_num] = Polygon_2_turn_acw(pgns[i_p_num], res_fin[0][1]);
			pgns_inset[i_p_num] = Polygon_2_turn_acw(pgns_inset[i_p_num], res_fin[0][1]);
			pgns_bbox[i_p_num] = bbox_cal(pgns[i_p_num]);
			pgns_trans[i_p_num] = Polygon_2_trans(pgns[i_p_num], coord_fin[0],
				coord_fin[1]);
			std::list<Nef_polyhedron> N_pgn_par_list;
			decomp_2(pgns_trans[i_p_num], N_pgn_par_list);
			N_pgn_par_lists.push_back(N_pgn_par_list);
			//为try做准备
			for (EdgeIterator ei = pgns[i_p_num].edges_begin(); ei != pgns[i_p_num].edges_end(); ++ei) {
				//ang_o要多加180°，也就是多加PI，保证o中的边角度和p中的边角度相同时，边可以贴在一起（不干涉）
				double ang_o = acos(to_double(ei->to_vector().hx().approx()) /
					sqrt(to_double(ei->squared_length().approx()))) + PI;
				if (to_double(ei->to_vector().hy().approx()) < 0)
					ang_o = 2 * PI - ang_o;
				angles_o.push_back(ang_o);
			}
		}

	}
	return 0;
}

/*
\n 换行符(LF)

\r 回车(CR) ，相当于键盘上的"Enter"

\t 跳到下一个TAB位置

\0 空字符(NULL)

\' 单引号（撇号）

\" 双引号

\\ 代表一个反斜线字符''\'

\ 继续符，可用于一行的结尾，表示本行与下一行连接起来
*/