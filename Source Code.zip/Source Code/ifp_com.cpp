﻿#include <list>
#include <iostream>
#include <fstream>
#include <cassert>

#include <thread>

#include <ilcplex\ilocplex.h>
ILOSTLBEGIN // 等同于 using namespace std; 声明命名空间

#include <Eigen/Dense>

#include <CGAL/IO/read_points.h>

#include <CGAL/Simple_cartesian.h>
#include <CGAL/Min_sphere_of_spheres_d.h>
#include <CGAL/Min_sphere_of_points_d_traits_2.h>
#include <CGAL/Random.h>

#include <CGAL/Exact_predicates_exact_constructions_kernel.h>
#include <CGAL/Polygon_2.h>
#include <CGAL/Polygon_with_holes_2.h>
#include <CGAL/Polygon_set_2.h>

#include <CGAL/Boolean_set_operations_2.h>

#include <CGAL/draw_polygon_set_2.h>
#include <CGAL/draw_polygon_2.h>
#include <CGAL/draw_polygon_with_holes_2.h>

#include <CGAL/Polyhedron_3.h>
#include <CGAL/Nef_polyhedron_3.h>
#include <CGAL/minkowski_sum_2.h>
#include <CGAL/minkowski_sum_3.h>
#include <CGAL/partition_2.h>
#include <CGAL/Partition_traits_2.h>
#include <CGAL/IO/Nef_polyhedron_iostream_3.h>
#include <CGAL/Nef_3/SNC_indexed_items.h>
#include <CGAL/convex_decomposition_3.h>
#include <CGAL/convex_hull_3.h>

#include <CGAL/draw_polyhedron.h>
#include <CGAL/draw_nef_3.h>

#include <CGAL/Epick_d.h>
#include <CGAL/Triangulation.h>

#include <draw_res.h>
#include <point_calculation.h>
#include <input_initialize.h>
#include <calculate_2d.h>
#include <calculate_3d.h>
#include <generate_para_2d.h>
#include <generate_para_3d.h>
#include <generate_para_4d.h>
#include <test_draw.h>
#include <try_program.h>
#include <draw_whole_res.h>
#include <scip_program.h>


#define PI 3.1415926535

#define Epsilon 0.00000001

typedef CGAL::Exact_predicates_exact_constructions_kernel K;
typedef CGAL::Polygon_2<K>                                Polygon_2;
typedef CGAL::Polygon_with_holes_2<K>                     Polygon_with_holes_2;
typedef CGAL::Polygon_set_2<K>                            Polygon_set_2;
typedef CGAL::Point_2<K>                                  Point_2;
typedef CGAL::Vector_2<K>                                 Vector_2;
typedef CGAL::Point_3<K>                                  Point_3;
typedef CGAL::Polyhedron_3<K>							  Polyhedron;
typedef CGAL::Nef_polyhedron_3<K>						  Nef_polyhedron;
//typedef K::Point_2										  Point;
using std::cout;
using std::endl;

typedef CGAL::Simple_cartesian<double>                   c_K;//引自参考min_circle_2的例子
typedef CGAL::Min_sphere_of_points_d_traits_2<c_K, double>   c_Traits;
typedef CGAL::Min_sphere_of_spheres_d<c_Traits>            Min_circle;
typedef CGAL::Point_2<c_K>                                 c_Point_2;
typedef CGAL::Polygon_2<c_K>                                c_Polygon_2;
typedef c_K::Point_3									   input_Point;

typedef CGAL::Partition_traits_2<K>                         Traits;
typedef Traits::Polygon_2                                   p_Polygon_2;
typedef Traits::Point_2                                     p_Point_2;

typedef Polygon_2::Vertex_iterator						  VertexIterator;
typedef Polygon_2::Edge_const_iterator					  EdgeIterator;
typedef p_Polygon_2::Vertex_iterator					  p_VertexIterator;
typedef Nef_polyhedron::Volume_const_iterator			  Volume_const_iterator;
typedef Polyhedron::Vertex_iterator						  phd_VertexIterator;
typedef Polyhedron::Facet_iterator					      phd_FacetIterator;
//typedef Nef_polyhedron::Vertex_iterator					  N_phd_VertexIterator;
typedef Nef_polyhedron::Aff_transformation_3			  Aff_transformation_3;
typedef Polyhedron::Halfedge_around_facet_circulator	  Halfedge_facet_circulator;

typedef CGAL::Epick_d<CGAL::Dynamic_dimension_tag>		  D_dim;
typedef CGAL::Triangulation<D_dim>                        Triangulation;
typedef CGAL::Triangulation_data_structure<D_dim>         TDS;
typedef Triangulation::Point			                  D_dim_point;
typedef Triangulation::Full_cell_handle					  Full_cell_handle;
typedef Triangulation::Facet							  Facet;
typedef Triangulation::Face								  Face;

typedef std::list<Point_2>								  Point_list_2;
typedef std::list<c_Point_2>							  c_Point_list_2;
typedef std::list<p_Polygon_2>                            p_Pgn_list_2;
typedef std::list<Point_3>								  Point_list_3;
typedef std::list<Polygon_with_holes_2>                   Pwh_list_2;
typedef std::list<Polygon_2>							  Pgn_list_2;
typedef std::list<Nef_polyhedron>						  N_phd_list;
typedef std::list<Polyhedron>							  phd_list;
typedef std::vector<Full_cell_handle>					  Full_cells;
typedef std::vector<Face>								  Faces;

bool res_sort_nfp(std::vector<double> a, std::vector<double> b) {
	if (a[0] < b[0] + Epsilon && b[0] < a[0] + Epsilon)
		return a[1] < b[1];//如果目标函数一样，重合面积升序
	else
		return a[0] < b[0];//目标函数升序(小的放前面)
}

bool res_sort_ifp(std::vector<double> a, std::vector<double> b) {
	if (a[4] == b[4])
		return a[0] < b[0];//如果ifp编号一样，目标函数升序
	else
		return a[4] < b[4];//ifp编号升序(小的放前面)
}

//根据数组第一位（下标为0），升序排序（小的放前面）
bool res_sort_0(std::vector<double> a, std::vector<double> b) {
	return a[0] < b[0];//ifp编号升序(小的放前面)
}

int main()
{
	std::cout.precision(14);
	std::ofstream out_4d;
	out_4d.open("D:/Ph.D/Code/Packing/data/packing/record.txt", std::ios::out);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
	std::ofstream out_test;
	out_test.precision(14);
	out_test.open("D:/Ph.D/Code/Packing/data/packing/run_test.txt", std::ios::out);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
	out_test.close();
	std::ofstream out_coord;
	out_coord.precision(14);
	out_coord.open("D:/Ph.D/Code/Packing/data/packing/coord_test.txt", std::ios::out);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
	out_coord.close();
	int polygon_num;
	polygon_num = 7;
	//std::cout << "请输入多边形数量，按回车结束" << std::endl;
	//std::cin >> polygon_num;
	std::vector < c_Point_list_2 > vec_c_points = input_polygons(polygon_num, "D:/Ph.D/Code/Packing/data/packing/polygon_obo_");

	double width;
	width = 15;
	//std::cout << "请输入箱子宽度，按回车结束" << std::endl;
	//std::cin >> width;
	double length;
	length = 15;
	//std::cout << "请输入箱子长度，按回车结束" << std::endl;
	//std::cin >> length;

	double alpha_obj;
	alpha_obj = 0.001;
	//std::cout << "请输入目标函数x+αy中的系数α，按回车结束" << std::endl;
	//std::cin >> alpha_obj;

	double beta_obj;
	beta_obj = 0.00001;
	//std::cout << "请输入目标函数中零件坐标x+y的系数β，按回车结束" << std::endl;
	//std::cin >> beta_obj;

	double ang_step_size;
	ang_step_size = 30;
	//std::cout << "请输入角度步长，按回车结束" << std::endl;
	//std::cin >> ang_step_size;

	int eve_n;
	eve_n = 8;
	//std::cout << "请输入选择几个均分角度进行比较，按回车结束" << std::endl;
	//std::cin >> eve_n;

	int try_n;
	try_n = 3;
	//std::cout << "请输入选择前几个竞争力角度进行比较，按回车结束" << std::endl;
	//std::cin >> try_n;

	std::vector<double> polygons_symm = { 1, 2, 1, 2, 4, 4, 1 };
	//要改！
	
	//非线性规划情况下，D-function，大概是最大的图形的最长的一条线的长度*sqrt(2)*length
	double big_m_nonlin = 2 * max(length, width) * max(length, width);

	std::vector<double> ran_nums;
	FILE* fp;
	fp = fopen("D:/Ph.D/Code/Packing/data/packing/random.txt", "r");
	for (int i_ran = 0; i_ran < 100; ++i_ran) {
		double ran_num;
		fscanf(fp, "%lf", &ran_num);
		ran_nums.push_back(ran_num);
	}

	double time_lim = 3600;

	std::vector<Polygon_with_holes_2> pwhs(polygon_num);
	std::vector<Polygon_2> pgns(polygon_num);
	//std::vector<std::list<Nef_polyhedron>> N_pgn_par_lists;
	std::vector<std::vector<double>> pgns_bbox;//每个图形都有一个四维变量，保存着minx，miny，maxx，maxy

	for (int i_p_num = 0; i_p_num < polygon_num; ++i_p_num) {
		std::vector<double> pgn_bbox;
		//调整图形位置，后续需要
		pwhs[i_p_num] = init_min_c(vec_c_points[i_p_num], pgn_bbox);
		//对图形进行初始化旋转（随机）
		pgns[i_p_num] = Polygon_2_turn_acw(pwhs[i_p_num].outer_boundary(), ran_nums[i_p_num] * 2 * PI);
		pwhs[i_p_num] = Polygon_with_holes_2(pgns[i_p_num]);
		pgn_bbox = bbox_cal(pgns[i_p_num]);
		pgns_bbox.push_back(pgn_bbox);
		//std::list<Nef_polyhedron> N_pgn_par_list;
		//decomp_2(pgns[i_p_num], N_pgn_par_list);
		//N_pgn_par_lists.push_back(N_pgn_par_list);
	}

	std::vector<double> angles_o;//origin（用来对比的）
	angles_o.push_back(0);
	angles_o.push_back(PI / 2);
	angles_o.push_back(PI);
	angles_o.push_back(3 * PI / 2);

	//bin只包含箱子的形状
	std::vector<Polygon_with_holes_2> bin_pwh_vec;
	//Pwh_list_2                  ifp_pwh_list;
	std::vector<Polygon_with_holes_2>::const_iterator  it;

	Point_list_2 poi_box = { Point_2(-1, -1), Point_2(length + 1, -1),
			Point_2(length + 1, width + 1), Point_2(-1, width + 1) };
	Polygon_with_holes_2 ifp_box(Polygon_2(poi_box.begin(), poi_box.end()));
	Point_list_2 poi_bin = { Point_2(0, 0), Point_2(length, 0),
			Point_2(length, width), Point_2(0, width) };
	Polygon_with_holes_2 bin_pwh(Polygon_2(poi_bin.begin(), poi_bin.end()));
	bin_pwh_vec.push_back(bin_pwh);

	//ifp是将箱子挖空后的有孔多边形
	std::vector<Polygon_with_holes_2> ifp_pwh_vec;
	Polygon_with_holes_2 ifp_pwh;
	//如果报错说明difference结果不是一个图形，而是多个图形
	difference(ifp_box, bin_pwh, &ifp_pwh);
	ifp_pwh_vec.push_back(ifp_pwh);

	//CGAL::intersection(pgn_n, Polygon_2(poi_obj.begin(), poi_obj.end()), std::back_inserter(ifp_pwh_vec));

	std::vector<std::vector<double>> coord_all;

	for (int i_p_num = 0; i_p_num < polygon_num; ++i_p_num) {

		std::vector<std::vector<double>> res_fin;

		DWORD t_nfp1 = GetTickCount64();
		double ifp_time = 0;
		//obj, ra_turn, lowerbound, upperbound, i_ifp, time, intersection, iteration, ifp_time
		std::vector<double> res_nfp(9, 10000);
		{
			for (int i_ifp = 0; i_ifp < ifp_pwh_vec.size(); ++i_ifp) {
				//CGAL::draw(ifp_pwh_vec[i_ifp]);
				std::list<Nef_polyhedron> N_ifp_to_cal_list;
				//if (i_p_num >= 4)
					//CGAL::draw(bin_pwh_vec[i_ifp]);
				decomp_2_ifp(bin_pwh_vec[i_ifp].outer_boundary(), N_ifp_to_cal_list, length, width);
				std::vector<double> polygon_angles;
				init_angles(polygon_angles, ang_step_size, polygons_symm[i_p_num]);
				std::vector<std::vector<double>> best_results(polygon_angles.size() - 1);
				//std::vector<std::thread> t_ang(polygon_angles.size() - 1);
				for (int i_p_a = 0; i_p_a < polygon_angles.size() - 1; ++i_p_a) {
					//t_ang[i_p_a] = std::thread([length, width, alpha_obj, i_p_num, i_p_a, i_ifp, 
						//polygon_angles, pgns_bbox, pwhs, pgns, N_ifp_to_cal_list, ifp_pwh_vec,
						//&best_results] {
					{
						std::vector<std::vector<std::vector<std::vector<double>>>> polygons_paras_nfps_nfp;
						std::vector<double> obj_nfp;
						std::vector<double> coord_nfp;
						double ra_turn_nfp;
						double intersection;

						single_polygon_ifp(length, width, alpha_obj, i_p_num,
							polygon_angles[i_p_a], polygon_angles[i_p_a + 1], pwhs, pgns,
							N_ifp_to_cal_list, ifp_pwh_vec[i_ifp], ifp_time, obj_nfp, coord_nfp,
							ra_turn_nfp, intersection);

						best_results[i_p_a] = { obj_nfp[2], intersection, ra_turn_nfp,
							polygon_angles[i_p_a], polygon_angles[i_p_a + 1] };
					}
					//});
				}
				//for (int i_p_a = 0; i_p_a < polygon_angles.size() - 1; ++i_p_a) {
					//t_ang[i_p_a].join();
				//}
				sort(best_results.begin(), best_results.end(), res_sort_nfp);

				if (best_results[0][0] == 100)
					continue;
				std::vector<double> obj_ub;
				std::vector<double> coord_ub;
				double ra_turn_ub = best_results[0][2];

				single_polygon_ifp_no_turn(length, width, alpha_obj, i_p_num,
					pgns[i_p_num], ifp_pwh_vec[i_ifp], ra_turn_ub, obj_ub, coord_ub);

				//out_4d << "Intersection area = " << best_results[0][1] << "\n";
				//out_4d << "Obj low = " << best_results[0][0] << "\n";
				//out_4d << "Obj high = " << obj[2] << "\n";
				out_4d << best_results[0][0] << " " << best_results[0][1] << " " << ra_turn_ub / PI * 180 << " " <<
					best_results[0][3] << " " << best_results[0][4] << " " << obj_ub[2] << "\n";
				std::cout << "Intersection area = " << best_results[0][1] << std::endl;
				std::cout << "Obj difference = " << obj_ub[2] - best_results[0][0] << std::endl;

				//draw_whole_res(i_p_num, length, width, pgns, best_results[0][2], obj, coord);

				int it_num = 0;

				while (obj_ub[2] - best_results[0][0] > 0.001) {
					best_results.push_back({});
					best_results.push_back({});
					//std::vector<std::thread> t_it(2);
					if (best_results[0][3] + 1 < best_results[0][2] / PI * 180 &&
						best_results[0][2] / PI * 180 + 1 < best_results[0][4])
					{
						//t_it[0] = std::thread([length, width, alpha_obj, i_p_num, i_ifp, 
							//polygon_angles, pgns_bbox, pwhs, pgns, N_ifp_to_cal_list, ifp_pwh_vec,
							//&best_results] {
						{
							std::vector<std::vector<std::vector<std::vector<double>>>> polygons_paras_nfps_nfp;
							std::vector<double> obj_nfp;
							std::vector<double> coord_nfp;
							double ra_turn_nfp;
							double intersection;

							single_polygon_ifp(length, width, alpha_obj, i_p_num,
								best_results[0][3], best_results[0][2] / PI * 180, pwhs, pgns,
								N_ifp_to_cal_list, ifp_pwh_vec[i_ifp], ifp_time, obj_nfp, coord_nfp,
								ra_turn_nfp, intersection);

							best_results[best_results.size() - 2] = { obj_nfp[2], intersection, ra_turn_nfp,
								best_results[0][3], best_results[0][2] / PI * 180 };
						}
						//});

					//t_it[1] = std::thread([length, width, alpha_obj, i_p_num, i_ifp,
						//polygon_angles, pgns_bbox, pwhs, pgns, N_ifp_to_cal_list, ifp_pwh_vec,
						//&best_results] {
						{
							std::vector<std::vector<std::vector<std::vector<double>>>> polygons_paras_nfps_nfp;
							std::vector<double> obj_nfp;
							std::vector<double> coord_nfp;
							double ra_turn_nfp;
							double intersection;

							single_polygon_ifp(length, width, alpha_obj, i_p_num,
								best_results[0][2] / PI * 180, best_results[0][4], pwhs, pgns,
								N_ifp_to_cal_list, ifp_pwh_vec[i_ifp], ifp_time, obj_nfp, coord_nfp,
								ra_turn_nfp, intersection);

							best_results[best_results.size() - 1] = { obj_nfp[2], intersection, ra_turn_nfp,
								best_results[0][2] / PI * 180, best_results[0][4] };
						}
						//});
					}
					else {
						//t_it[0] = std::thread([length, width, alpha_obj, i_p_num, i_ifp,
							//polygon_angles, pgns_bbox, pwhs, pgns, N_ifp_to_cal_list, ifp_pwh_vec,
							//&best_results] {
						{
							std::vector<std::vector<std::vector<std::vector<double>>>> polygons_paras_nfps_nfp;
							std::vector<double> obj_nfp;
							std::vector<double> coord_nfp;
							double ra_turn_nfp;
							double intersection;

							single_polygon_ifp(length, width, alpha_obj, i_p_num,
								best_results[0][3], (best_results[0][3] + best_results[0][4]) / 2, pwhs, pgns,
								N_ifp_to_cal_list, ifp_pwh_vec[i_ifp], ifp_time, obj_nfp, coord_nfp,
								ra_turn_nfp, intersection);

							best_results[best_results.size() - 2] = { obj_nfp[2], intersection, ra_turn_nfp,
								best_results[0][3], (best_results[0][3] + best_results[0][4]) / 2 };
						}
						//});

					//t_it[1] = std::thread([length, width, alpha_obj, i_p_num, i_ifp,
						//polygon_angles, pgns_bbox, pwhs, pgns, N_ifp_to_cal_list, ifp_pwh_vec,
						//&best_results] {
						{
							std::vector<std::vector<std::vector<std::vector<double>>>> polygons_paras_nfps_nfp;
							std::vector<double> obj_nfp;
							std::vector<double> coord_nfp;
							double ra_turn_nfp;
							double intersection;

							single_polygon_ifp(length, width, alpha_obj, i_p_num,
								(best_results[0][3] + best_results[0][4]) / 2, best_results[0][4], pwhs, pgns,
								N_ifp_to_cal_list, ifp_pwh_vec[i_ifp], ifp_time, obj_nfp, coord_nfp,
								ra_turn_nfp, intersection);

							best_results[best_results.size() - 1] = { obj_nfp[2], intersection, ra_turn_nfp,
								(best_results[0][3] + best_results[0][4]) / 2, best_results[0][4] };
						}
						//});
					}

					//t_it[0].join();
					//t_it[1].join();
					best_results.erase(best_results.begin());

					sort(best_results.begin(), best_results.end(), res_sort_nfp);

					if (best_results[0][0] == 100)
						break;

					std::vector<double> obj;
					std::vector<double> coord;

					single_polygon_ifp_no_turn(length, width, alpha_obj, i_p_num,
						pgns[i_p_num], ifp_pwh_vec[i_ifp], best_results[0][2], obj, coord);

					if (obj[2] < obj_ub[2]) {
						ra_turn_ub = best_results[0][2];
						obj_ub = obj;
						coord_ub = coord;
					}
					//out_4d << "Intersection area = " << best_results[0][1] << "\n";
					//out_4d << "Obj low = " << best_results[0][0] << "\n";
					//out_4d << "Obj high = " << obj[2] << "\n";
					out_4d << best_results[0][0] << " " << best_results[0][1] << " " << best_results[0][2] / PI * 180 << " " <<
						best_results[0][3] << " " << best_results[0][4] << " " << obj_ub[2] << "\n";
					std::cout << "Intersection area = " << best_results[0][1] << std::endl;
					std::cout << "Obj difference = " << obj_ub[2] - best_results[0][0] << std::endl;
					it_num++;
				}

				if (best_results[0][0] == 100)
					continue;

				out_4d << "Iteration time = " << it_num << "\n";
				std::cout << "Iteration time = " << it_num << std::endl;
				//draw_whole_res(i_p_num, length, width, pgns, ra_turn_ub, obj_ub, coord_all);
				res_nfp[0] = obj_ub[2];
				res_nfp[1] = ra_turn_ub;
				res_nfp[2] = best_results[0][0];
				res_nfp[3] = obj_ub[2];
				res_nfp[4] = i_ifp;
				res_nfp[6] = best_results[0][1];
				res_nfp[7] = it_num;
				res_nfp[8] = ifp_time;

				break;
			}
		}
		DWORD t_nfp2 = GetTickCount64();
		res_nfp[5] = (t_nfp2 - t_nfp1) * 1.0 / 1000;
		std::cout << "time = " << res_nfp[5] << std::endl;
		res_fin.push_back(res_nfp);

		DWORD t_dfunc1 = GetTickCount64();
		//obj, ra_turn, lowerbound, upperbound, i_ifp, time
		std::vector<double> res_dfunc(6, 10000);
		{
			for (int i_ifp = 0; i_ifp < ifp_pwh_vec.size(); ++i_ifp) {
				//CGAL::draw(ifp_pwh_vec[i_ifp]);
				std::vector<std::vector<std::vector<double>>> poi_conv_pgns_bin;
				poi_conv_pgns_bin = generate_poi_conv_pgn_bin(bin_pwh_vec[i_ifp].outer_boundary(), length, width);
				std::vector<std::vector<std::vector<double>>> poi_conv_pgns_n;
				poi_conv_pgns_n = generate_poi_conv_pgn(pgns[i_p_num]);

				std::vector<double> obj;
				std::vector<double> coord;
				std::vector<double> bound;
				double ra_turn;
				scip_program_d_function_obo(polygon_num, length, width, alpha_obj, i_p_num, big_m_nonlin,
					pgns[i_p_num], polygons_symm[i_p_num], ifp_pwh_vec[i_ifp], poi_conv_pgns_bin,
					poi_conv_pgns_n, time_lim, ra_turn, bound, obj, coord);

				if (ra_turn == 100)
					continue;

				res_dfunc[0] = obj[2];
				res_dfunc[1] = ra_turn;
				res_dfunc[2] = bound[0];
				res_dfunc[3] = bound[1];
				res_dfunc[4] = i_ifp;
				break;
			}
		}
		DWORD t_dfunc2 = GetTickCount64();
		res_dfunc[5] = (t_dfunc2 - t_dfunc1) * 1.0 / 1000;
		res_fin.push_back(res_dfunc);

		DWORD t_seplin1 = GetTickCount64();
		//obj, ra_turn, lowerbound, upperbound, i_ifp, time
		std::vector<double> res_seplin(6, 10000);
		{
			for (int i_ifp = 0; i_ifp < ifp_pwh_vec.size(); ++i_ifp) {
				//CGAL::draw(ifp_pwh_vec[i_ifp]);
				std::vector<std::vector<std::vector<double>>> poi_conv_pgns_bin;
				poi_conv_pgns_bin = generate_poi_conv_pgn_bin(bin_pwh_vec[i_ifp].outer_boundary(), length, width);
				std::vector<std::vector<std::vector<double>>> poi_conv_pgns_n;
				poi_conv_pgns_n = generate_poi_conv_pgn(pgns[i_p_num]);

				std::vector<double> obj;
				std::vector<double> coord;
				std::vector<double> bound;
				double ra_turn;
				scip_program_sep_lin_obo(polygon_num, length, width, alpha_obj, i_p_num, big_m_nonlin,
					pgns[i_p_num], polygons_symm[i_p_num], ifp_pwh_vec[i_ifp], poi_conv_pgns_bin,
					poi_conv_pgns_n, time_lim, ra_turn, bound, obj, coord);

				if (ra_turn == 100)
					continue;

				res_seplin[0] = obj[2];
				res_seplin[1] = ra_turn;
				res_seplin[2] = bound[0];
				res_seplin[3] = bound[1];
				res_seplin[4] = i_ifp;
				break;
			}
		}
		DWORD t_seplin2 = GetTickCount64();
		res_seplin[5] = (t_seplin2 - t_seplin1) * 1.0 / 1000;
		res_fin.push_back(res_seplin);

		out_test.open("D:/Ph.D/Code/Packing/data/packing/run_test.txt", std::ios::out | std::ios::app);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
		for (int i = 0; i < res_fin.size(); ++i) {
			for (int j = 0; j < res_fin[i].size(); ++j) {
				out_test << res_fin[i][j] << " ";
			}
			out_test << "\n";
		}

		sort(res_fin.begin(), res_fin.end(), res_sort_ifp);

		std::vector<double> obj_fin;
		std::vector<double> coord_fin;
		single_polygon_ifp_no_turn(length, width, alpha_obj, i_p_num,
			pgns[i_p_num], ifp_pwh_vec[res_fin[0][4]], res_fin[0][1], obj_fin, coord_fin);

		coord_all.push_back({ coord_fin[0] - Epsilon, coord_fin[1] - Epsilon });

		out_test << res_fin[0][1] << "\n";
		out_test.close();

		out_coord.open("D:/Ph.D/Code/Packing/data/packing/coord_test.txt", std::ios::out | std::ios::app);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
		out_coord << coord_fin[0] - Epsilon << " " << coord_fin[1] - Epsilon << " " << res_fin[0][1] << "\n";
		out_coord.close();

		for (int i_output_co = 0; i_output_co < coord_all.size(); ++i_output_co) {
			std::cout << coord_all[i_output_co][0] << " " << coord_all[i_output_co][1] << std::endl;
		}
		if (i_p_num == polygon_num - 1)
			draw_whole_res(i_p_num, length, width, pgns, res_fin[0][1], obj_fin, coord_all);

		//为下一个图形做准备
		if (i_p_num < polygon_num - 1) {
			pgns[i_p_num] = Polygon_2_turn_acw(pgns[i_p_num], res_fin[0][1]);
			pgns_bbox[i_p_num] = bbox_cal(pgns[i_p_num]);

			bin_pwh_vec.clear();
			bin_pwh_vec.push_back(bin_pwh);
			std::vector<std::vector<double>> bin_area;
			for (int j_p_num = 0; j_p_num <= i_p_num; ++j_p_num) {
				Polygon_with_holes_2 pwh_n(Polygon_2_trans(pgns[j_p_num],
					coord_all[j_p_num][0], coord_all[j_p_num][1]));
				difference(ifp_box, pwh_n, &pwh_n);
				std::vector<Polygon_with_holes_2> intR_temp;
				for (it = bin_pwh_vec.begin(); it != bin_pwh_vec.end(); ++it) {
					CGAL::intersection(*it, pwh_n, std::back_inserter(intR_temp));
				}
				bin_pwh_vec = intR_temp;
			}

			double i_area = 0;
			for (it = bin_pwh_vec.begin(); it != bin_pwh_vec.end();) {
				//if (i_p_num >= 4)
					//CGAL::draw(*it);
				if (it->outer_boundary().area() < pgns[i_p_num + 1].area()) {
					bin_pwh_vec.erase(it);//这里it会++
				}
				else {
					bin_area.push_back({ to_double(it->outer_boundary().area().approx()), i_area });
					++i_area;
					++it;
				}
			}
			sort(bin_area.begin(), bin_area.end(), res_sort_0);
			std::vector<Polygon_with_holes_2> bin_pwh_vec_temp;
			for (int i_area_sort = 0; i_area_sort < bin_area.size(); ++i_area_sort) {
				bin_pwh_vec_temp.push_back(bin_pwh_vec[bin_area[i_area_sort][1]]);
			}
			bin_pwh_vec = bin_pwh_vec_temp;

			ifp_pwh_vec.clear();
			for (it = bin_pwh_vec.begin(); it != bin_pwh_vec.end(); ++it) {
				Polygon_with_holes_2 ifp_pwh;
				//如果报错说明difference结果不是一个图形，而是多个图形
				difference(ifp_box, *it, &ifp_pwh);
				//if (i_p_num >= 4)
					//CGAL::draw(ifp_pwh);
				ifp_pwh_vec.push_back(ifp_pwh);
			}

			//为try做准备
			for (EdgeIterator ei = pgns[i_p_num].edges_begin(); ei != pgns[i_p_num].edges_end(); ++ei) {
				//ang_o要多加180°，也就是多加PI，保证o中的边角度和p中的边角度相同时，边可以贴在一起（不干涉）
				double ang_o = acos(to_double(ei->to_vector().hx().approx()) /
					sqrt(to_double(ei->squared_length().approx()))) + PI;
				if (to_double(ei->to_vector().hy().approx()) < 0)
					ang_o = 2 * PI - ang_o;
				angles_o.push_back(ang_o);
			}
			//为NFP做准备
			//std::list<Nef_polyhedron> N_pgn_par_list_t;
			//decomp_2(pgns[i_p_num], N_pgn_par_list_t);
			//N_pgn_par_lists[i_p_num] = N_pgn_par_list_t;
		}
	}
	out_4d.close();
	out_test.close();
	return 0;
}

/*
\n 换行符(LF)

\r 回车(CR) ，相当于键盘上的"Enter"

\t 跳到下一个TAB位置

\0 空字符(NULL)

\' 单引号（撇号）

\" 双引号

\\ 代表一个反斜线字符''\'

\ 继续符，可用于一行的结尾，表示本行与下一行连接起来
*/