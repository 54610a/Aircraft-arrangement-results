﻿//一个个加入多边形，一个个优化，数据集用poly，故意拖慢一点，不用bin，而用每一个多边形凸分解，比较
// 只用了poly
//final
//输入已有的num_done个坐标，继续做后面的
#include <list>
#include <iostream>
#include <fstream>
#include <cassert>

#include <thread>

#include <ilcplex\ilocplex.h>
ILOSTLBEGIN // 等同于 using namespace std; 声明命名空间

#include <Eigen/Dense>

#include <CGAL/IO/read_points.h>

#include <CGAL/Simple_cartesian.h>
#include <CGAL/Min_sphere_of_spheres_d.h>
#include <CGAL/Min_sphere_of_points_d_traits_2.h>
#include <CGAL/Random.h>

#include <CGAL/Exact_predicates_exact_constructions_kernel.h>
#include <CGAL/Polygon_2.h>
#include <CGAL/Polygon_with_holes_2.h>
#include <CGAL/Polygon_set_2.h>

#include <CGAL/Boolean_set_operations_2.h>

#include <CGAL/draw_polygon_set_2.h>
#include <CGAL/draw_polygon_2.h>
#include <CGAL/draw_polygon_with_holes_2.h>

#include <CGAL/Polyhedron_3.h>
#include <CGAL/Nef_polyhedron_3.h>
#include <CGAL/minkowski_sum_2.h>
#include <CGAL/minkowski_sum_3.h>
#include <CGAL/partition_2.h>
#include <CGAL/Partition_traits_2.h>
#include <CGAL/IO/Nef_polyhedron_iostream_3.h>
#include <CGAL/Nef_3/SNC_indexed_items.h>
#include <CGAL/convex_decomposition_3.h>
#include <CGAL/convex_hull_3.h>

#include <CGAL/draw_polyhedron.h>
#include <CGAL/draw_nef_3.h>

#include <CGAL/Epick_d.h>
#include <CGAL/Triangulation.h>

#include "gurobi_c++.h"

#include <draw_res.h>
#include <point_calculation.h>
#include <input_initialize.h>
#include <calculate_2d.h>
#include <calculate_3d.h>
#include <generate_para_2d.h>
#include <generate_para_3d.h>
#include <generate_para_4d.h>
#include <test_draw.h>
#include <try_program.h>
#include <draw_whole_res.h>
#include <scip_program.h>
#include <gurobi_program.h>


#define PI 3.1415926535

#define Epsilon 0.00000001

typedef CGAL::Exact_predicates_exact_constructions_kernel K;
typedef CGAL::Polygon_2<K>                                Polygon_2;
typedef CGAL::Polygon_with_holes_2<K>                     Polygon_with_holes_2;
typedef CGAL::Polygon_set_2<K>                            Polygon_set_2;
typedef CGAL::Point_2<K>                                  Point_2;
typedef CGAL::Vector_2<K>                                 Vector_2;
typedef CGAL::Point_3<K>                                  Point_3;
typedef CGAL::Polyhedron_3<K>							  Polyhedron;
typedef CGAL::Nef_polyhedron_3<K>						  Nef_polyhedron;
//typedef K::Point_2										  Point;
using std::cout;
using std::endl;

typedef CGAL::Simple_cartesian<double>                   c_K;//引自参考min_circle_2的例子
typedef CGAL::Min_sphere_of_points_d_traits_2<c_K, double>   c_Traits;
typedef CGAL::Min_sphere_of_spheres_d<c_Traits>            Min_circle;
typedef CGAL::Point_2<c_K>                                 c_Point_2;
typedef CGAL::Polygon_2<c_K>                                c_Polygon_2;
typedef c_K::Point_3									   input_Point;

typedef CGAL::Partition_traits_2<K>                         Traits;
typedef Traits::Polygon_2                                   p_Polygon_2;
typedef Traits::Point_2                                     p_Point_2;

typedef Polygon_2::Vertex_iterator						  VertexIterator;
typedef Polygon_2::Edge_const_iterator					  EdgeIterator;
typedef p_Polygon_2::Vertex_iterator					  p_VertexIterator;
typedef Nef_polyhedron::Volume_const_iterator			  Volume_const_iterator;
typedef Polyhedron::Vertex_iterator						  phd_VertexIterator;
typedef Polyhedron::Facet_iterator					      phd_FacetIterator;
//typedef Nef_polyhedron::Vertex_iterator					  N_phd_VertexIterator;
typedef Nef_polyhedron::Aff_transformation_3			  Aff_transformation_3;
typedef Polyhedron::Halfedge_around_facet_circulator	  Halfedge_facet_circulator;

typedef CGAL::Epick_d<CGAL::Dynamic_dimension_tag>		  D_dim;
typedef CGAL::Triangulation<D_dim>                        Triangulation;
typedef CGAL::Triangulation_data_structure<D_dim>         TDS;
typedef Triangulation::Point			                  D_dim_point;
typedef Triangulation::Full_cell_handle					  Full_cell_handle;
typedef Triangulation::Facet							  Facet;
typedef Triangulation::Face								  Face;

typedef std::list<Point_2>								  Point_list_2;
typedef std::list<c_Point_2>							  c_Point_list_2;
typedef std::list<p_Polygon_2>                            p_Pgn_list_2;
typedef std::list<Point_3>								  Point_list_3;
typedef std::list<Polygon_with_holes_2>                   Pwh_list_2;
typedef std::list<Polygon_2>							  Pgn_list_2;
typedef std::list<Nef_polyhedron>						  N_phd_list;
typedef std::list<Polyhedron>							  phd_list;
typedef std::vector<Full_cell_handle>					  Full_cells;
typedef std::vector<Face>								  Faces;

bool res_sort_nfp(std::vector<double> a, std::vector<double> b) {
	if (a[0] < b[0] + Epsilon && b[0] < a[0] + Epsilon)
		return a[1] < b[1];//如果目标函数一样，重合面积升序
	else
		return a[0] < b[0];//目标函数升序(小的放前面)
}

bool res_sort_ifp(std::vector<double> a, std::vector<double> b) {
	if (a[4] == b[4])
		return a[0] < b[0];//如果ifp编号一样，目标函数升序
	else
		return a[4] < b[4];//ifp编号升序(小的放前面)
}

//根据数组第一位（下标为0），升序排序（小的放前面）
bool res_sort_0(std::vector<double> a, std::vector<double> b) {
	return a[0] < b[0];//ifp编号升序(小的放前面)
}

int main()
{
	std::cout.precision(14);
	std::ofstream out_nfp;
	out_nfp.precision(14);
	std::ofstream out_dfunc;
	out_dfunc.precision(14);
	std::ofstream out_seplin;
	out_seplin.precision(14);
	std::ofstream out_phif;
	out_phif.precision(14);
	std::ofstream out_qa_f;
	out_qa_f.precision(14);
	std::ofstream out_qa_s;
	out_qa_s.precision(14);
	std::ofstream out_cirs;
	out_cirs.precision(14);
	std::ofstream out_test;
	out_test.precision(14);
	std::ofstream out_coord;
	out_coord.precision(14);
	int polygon_num;
	polygon_num = 30;
	//std::cout << "请输入多边形数量，按回车结束" << std::endl;
	//std::cin >> polygon_num;
	std::vector < c_Point_list_2 > vec_c_points_75 = input_polygons(75, "D:/Ph.D/Code/Packing/data/packing/poly/polygon_");

	FILE* fp;
	fp = fopen("D:/Ph.D/Code/Packing/data/packing/random_poly_0.txt", "r");
	std::vector<std::vector<double>> vec_cases;
	for (int i_case = 0; i_case < 100; ++i_case) {
		std::vector<double> vec_case(75);
		for (int i_id = 0; i_id < 75; ++i_id) {
			fscanf(fp, "%lf", &vec_case[i_id]);
		}
		vec_cases.push_back(vec_case);
	}

	int which_case;
	//which_case = 0;
	std::cout << "请输入要使用哪一个随机序列（如使用1-30原始序列，输入10000），按回车结束" << std::endl;
	std::cin >> which_case;

	std::vector<c_Point_list_2> vec_c_points;
	if (which_case == 10000) {
		for (int i_pgn = 0; i_pgn < polygon_num; ++i_pgn) {
			vec_c_points.push_back(vec_c_points_75[i_pgn]);
		}
	}
	else {
		for (int i_pgn = 0; i_pgn < polygon_num; ++i_pgn) {
			vec_c_points.push_back(vec_c_points_75[vec_cases[which_case][i_pgn]]);
		}
	}

	double width;
	width = 40;
	//std::cout << "请输入箱子宽度，按回车结束" << std::endl;
	//std::cin >> width;
	double length;
	length = 60;
	//std::cout << "请输入箱子长度，按回车结束" << std::endl;
	//std::cin >> length;

	double alpha_obj;
	alpha_obj = 0.001;
	//std::cout << "请输入目标函数x+αy中的系数α，按回车结束" << std::endl;
	//std::cin >> alpha_obj;

	double beta_obj;
	beta_obj = 0.00001;
	//std::cout << "请输入目标函数中零件坐标x+y的系数β，按回车结束" << std::endl;
	//std::cin >> beta_obj;

	double ang_step_size;
	ang_step_size = 30;
	//std::cout << "请输入角度步长，按回车结束" << std::endl;
	//std::cin >> ang_step_size;

	int eve_n;
	eve_n = 8;
	//std::cout << "请输入选择几个均分角度进行比较，按回车结束" << std::endl;
	//std::cin >> eve_n;

	int try_n;
	try_n = 3;
	//std::cout << "请输入选择前几个竞争力角度进行比较，按回车结束" << std::endl;
	//std::cin >> try_n;

	int cir_num;
	cir_num = 5;
	//std::cout << "请输入选择前几个竞争力角度进行比较，按回车结束" << std::endl;
	//std::cin >> cir_num;

	int type_of_al;
	//type_of_al = 0;
	std::cout << "请输入算法编号（0为dfunc，1为seplin，2为phifunc，3为qa-net fast，4为qa-net slow），按回车结束" << std::endl;
	std::cin >> type_of_al;

	int num_done;
	//num_done = 28;
	std::cout << "请输入num_done，按回车结束" << std::endl;
	std::cin >> num_done;


	std::vector<double> polygons_symm(polygon_num, 1);
	//要改！

	//非线性规划情况下，D-function，大概是最大的图形的最长的一条线的长度*sqrt(2)*length
	double big_m_nonlin = 2 * max(length, width) * max(length, width);

	double time_lim = 3600;

	std::vector<Polygon_with_holes_2> pwhs(polygon_num);
	std::vector<Polygon_2> pgns(polygon_num);
	std::vector<Polygon_2> pgns_trans(polygon_num);
	std::vector<Polygon_2> pgns_inset(polygon_num);
	//std::vector<std::list<Nef_polyhedron>> N_pgn_par_lists;
	std::vector<std::vector<double>> pgns_bbox;//每个图形都有一个四维变量，保存着minx，miny，maxx，maxy

	for (int i_p_num = 0; i_p_num < polygon_num; ++i_p_num) {
		std::vector<double> pgn_bbox;
		//调整图形位置，后续需要
		pwhs[i_p_num] = init_min_c(vec_c_points[i_p_num], pgn_bbox);
		//对图形不进行旋转
		pgns[i_p_num] = pwhs[i_p_num].outer_boundary();
		pgns_inset[i_p_num] = Polygon_2_inset(pgns[i_p_num], 0.0000001);
		//CGAL::draw(pwhs[i_p_num]);
		pgn_bbox = bbox_cal(pgns[i_p_num]);
		pgns_bbox.push_back(pgn_bbox);
		//std::list<Nef_polyhedron> N_pgn_par_list;
		//decomp_2(pgns[i_p_num], N_pgn_par_list);
		//N_pgn_par_lists.push_back(N_pgn_par_list);
	}

	std::vector<Polygon_2> pgns_origin = pgns;
	std::vector<Polygon_2> pgns_inset_origin = pgns_inset;

	//CGAL::intersection(pgn_n, Polygon_2(poi_obj.begin(), poi_obj.end()), std::back_inserter(ifp_pwh_vec));
	std::vector<std::list<Nef_polyhedron>> N_pgn_par_lists;
	std::vector<std::vector<double>> coord_all;
	std::vector<double> ra_all;

	fp = fopen("D:/Ph.D/Code/Packing/data/packing/coord_fin.txt", "r");
	for (int i_read = 0; i_read < polygon_num; ++i_read) {
		std::vector<double> coord_0(2);
		fscanf(fp, "%lf", &coord_0[0]);
		fscanf(fp, "%lf", &coord_0[1]);
		coord_all.push_back(coord_0);
		double ra_turn_0;
		fscanf(fp, "%lf", &ra_turn_0);
		ra_all.push_back(ra_turn_0);
		pgns[i_read] = Polygon_2_turn_acw(pgns[i_read], ra_turn_0);
		pgns_inset[i_read] = Polygon_2_turn_acw(pgns_inset[i_read], ra_turn_0);
		pgns_bbox[i_read] = bbox_cal(pgns[i_read]);
		pgns_trans[i_read] = Polygon_2_trans(pgns[i_read], coord_0[0], coord_0[1]);
		std::list<Nef_polyhedron> N_pgn_par_list;
		decomp_2(pgns_trans[i_read], N_pgn_par_list);
		N_pgn_par_lists.push_back(N_pgn_par_list);
	}
	if (num_done > 0) {
		std::vector<double> obj_test = { 0,0,0 };
		draw_whole_res(num_done - 1, length, width, pgns, 0, obj_test, coord_all);
	}

	std::vector<std::vector<double>> cirs_bin;
	std::vector<double> cir_sin({0,0,0});
	fp = fopen("D:/Ph.D/Code/Packing/data/packing/run_cirs.txt", "r");
	while (fscanf(fp, "%lf", &cir_sin[0]) == 1) {
		fscanf(fp, "%lf", &cir_sin[1]);
		fscanf(fp, "%lf", &cir_sin[2]);
		cirs_bin.push_back(cir_sin);
	}

	std::vector<Polygon_2> pgns_adding;
	std::vector<Polygon_2> pgns_trans_adding;
	std::vector<Polygon_2> pgns_inset_adding;
	std::vector<std::vector<double>> coord_adding;
	for (int i_p_num = 0; i_p_num < num_done; ++i_p_num) {
		pgns_adding.push_back(pgns[i_p_num]);
		pgns_trans_adding.push_back(pgns_trans[i_p_num]);
		pgns_inset_adding.push_back(pgns_inset[i_p_num]);
		coord_adding.push_back(coord_all[i_p_num]);
	}

	for (int i_p_num = num_done; i_p_num < polygon_num; ++i_p_num) {

		double min_ang = min_angle(pgns[i_p_num]);
		//std::cout << min_ang << std::endl;
		if (min_ang > 30) {
			ang_step_size = 30;
		}
		else {
			if (min_ang > 22.5) {
				ang_step_size = 22.5;
			}
			else {
				if (min_ang > 18) {
					ang_step_size = 18;
				}
				else {
					if (min_ang > 15) {
						ang_step_size = 15;
					}
					else {
						std::cout << "min_angle < 15" << std::endl;
					}
				}
			}
		}

		std::vector<Polygon_2> pgns_temp = pgns_adding;
		pgns_temp.push_back(pgns_origin[i_p_num]);
		std::vector<Polygon_2> pgns_inset_temp = pgns_inset_adding;
		pgns_inset_temp.push_back(pgns_inset_origin[i_p_num]);

		std::vector<std::vector<std::vector<double>>> poi_conv_pgns_bin;
		for (int i_p_con = 0; i_p_con < i_p_num; ++i_p_con) {
			std::vector<std::vector<std::vector<double>>> poi_conv_pgns_poly;
			std::vector<std::vector<std::vector<double>>> poi_conv_pgns_bin_temp = poi_conv_pgns_bin;
			poi_conv_pgns_bin.clear();
			poi_conv_pgns_bin = generate_poi_conv_pgn(pgns_trans[i_p_con]);
			std::merge(poi_conv_pgns_bin_temp.begin(), poi_conv_pgns_bin_temp.end(),
				poi_conv_pgns_poly.begin(), poi_conv_pgns_poly.end(), std::back_inserter(poi_conv_pgns_bin));
		}
		std::vector<std::vector<std::vector<double>>> poi_conv_pgns_n;
		poi_conv_pgns_n = generate_poi_conv_pgn(pgns_origin[i_p_num]);

		std::cout << "bin convex = " << poi_conv_pgns_bin.size() << std::endl;
		std::cout << "n convex = " << poi_conv_pgns_n.size() << std::endl;

		std::vector<std::vector<double>> circles;
		std::vector<std::vector<double>> cirs_s;
		if (type_of_al >= 3){
			inner_circle(pgns_origin[i_p_num], cir_num, circles);
			cirs_s = circles;
			for (int ci = 0; ci < circles.size(); ++ci) {
				circles[ci] = cir_enlarge(10, pgns_origin[i_p_num], circles[ci]);
			}
		}

		if (type_of_al == 0) {
			DWORD t_dfunc1 = GetTickCount64();
			//obj, ra_turn, lowerbound, upperbound, x_coord, y_coord, xobj, time
			std::vector<double> res_dfunc(8);
			{
				std::vector<double> obj;
				std::vector<double> coord;
				std::vector<double> bound;
				double ra_turn;
				gurobi_program_d_function_obo(polygon_num, length, width, alpha_obj, i_p_num, big_m_nonlin,
					pgns_origin[i_p_num], polygons_symm[i_p_num], poi_conv_pgns_bin,
					poi_conv_pgns_n, time_lim, ra_turn, bound, obj, coord);

				std::vector<std::vector<double>> coord_all_temp = coord_adding;
				coord_all_temp.push_back(coord);
				//if (i_p_num >= polygon_num - 2)
					//draw_whole_res(i_p_num, length, width, pgns_temp, ra_turn, obj, coord_all_temp);

				res_dfunc[0] = obj[2];
				res_dfunc[1] = ra_turn;
				res_dfunc[2] = bound[0];
				res_dfunc[3] = bound[1];
				res_dfunc[4] = coord[0];
				res_dfunc[5] = coord[1];
				res_dfunc[6] = obj[0];
			}
			DWORD t_dfunc2 = GetTickCount64();
			res_dfunc[7] = (t_dfunc2 - t_dfunc1) * 1.0 / 1000;
			out_dfunc.open("D:/Ph.D/Code/Packing/data/packing/run_dfunc.txt", std::ios::out | std::ios::app);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
			for (int i = 0; i < res_dfunc.size(); ++i) {
				out_dfunc << res_dfunc[i] << " ";
			}
			out_dfunc << "\n";
			out_dfunc.close();
		}

		if (type_of_al == 1) {
			DWORD t_seplin1 = GetTickCount64();
			//obj, ra_turn, lowerbound, upperbound, x_coord, y_coord, xobj, time
			std::vector<double> res_seplin(8);
			{
				std::vector<double> obj;
				std::vector<double> coord;
				std::vector<double> bound;
				double ra_turn;
				gurobi_program_sep_lin_obo(polygon_num, length, width, alpha_obj, i_p_num, big_m_nonlin,
					pgns_origin[i_p_num], polygons_symm[i_p_num], poi_conv_pgns_bin,
					poi_conv_pgns_n, time_lim, ra_turn, bound, obj, coord);

				std::vector<std::vector<double>> coord_all_temp = coord_adding;
				coord_all_temp.push_back(coord);
				//if (i_p_num >= 5)
					//draw_whole_res(i_p_num, length, width, pgns_temp, ra_turn, obj, coord_all_temp);

				res_seplin[0] = obj[2];
				res_seplin[1] = ra_turn;
				res_seplin[2] = bound[0];
				res_seplin[3] = bound[1];
				res_seplin[4] = coord[0];
				res_seplin[5] = coord[1];
				res_seplin[6] = obj[0];
			}
			DWORD t_seplin2 = GetTickCount64();
			res_seplin[7] = (t_seplin2 - t_seplin1) * 1.0 / 1000;
			out_seplin.open("D:/Ph.D/Code/Packing/data/packing/run_seplin.txt", std::ios::out | std::ios::app);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
			for (int i = 0; i < res_seplin.size(); ++i) {
				out_seplin << res_seplin[i] << " ";
			}
			out_seplin << "\n";
			out_seplin.close();
		}

		if (type_of_al == 2) {
			DWORD t_phif1 = GetTickCount64();
			//obj, ra_turn, lowerbound, upperbound, x_coord, y_coord, xobj, time
			std::vector<double> res_phif(8);
			{
				std::vector<double> obj;
				std::vector<double> coord;
				std::vector<double> bound;
				double ra_turn;
				gurobi_program_phi_function_obo(polygon_num, length, width, alpha_obj, i_p_num, big_m_nonlin,
					pgns_origin[i_p_num], polygons_symm[i_p_num], poi_conv_pgns_bin,
					poi_conv_pgns_n, time_lim, ra_turn, bound, obj, coord);

				std::vector<std::vector<double>> coord_all_temp = coord_adding;
				coord_all_temp.push_back(coord);
				//if (i_p_num >= polygon_num - 2)
					//draw_whole_res(i_p_num, length, width, pgns_temp, ra_turn, obj, coord_all_temp);

				res_phif[0] = obj[2];
				res_phif[1] = ra_turn;
				res_phif[2] = bound[0];
				res_phif[3] = bound[1];
				res_phif[4] = coord[0];
				res_phif[5] = coord[1];
				res_phif[6] = obj[0];
			}
			DWORD t_phif2 = GetTickCount64();
			res_phif[7] = (t_phif2 - t_phif1) * 1.0 / 1000;
			out_phif.open("D:/Ph.D/Code/Packing/data/packing/run_phif.txt", std::ios::out | std::ios::app);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
			for (int i = 0; i < res_phif.size(); ++i) {
				out_phif << res_phif[i] << " ";
			}
			out_phif << "\n";
			out_phif.close();
		}

		if (type_of_al == 3) {
			std::vector<std::vector<double>> pgn_to_draw;
			for (VertexIterator vi = pgns[i_p_num].vertices_begin(); vi != pgns[i_p_num].vertices_end(); ++vi) {
				pgn_to_draw.push_back({ to_double(vi->x().approx()),
						to_double(vi->y().approx()) });
			}
			//draw_circle(pgn_to_draw, circles);

			DWORD t_qanet1 = GetTickCount64();

			std::vector<std::vector<double>> cirs_n = circles;
			double qa_ub = length + width, qa_lb = 0, ra_ub, ra_lb;
			std::vector<double> obj_ub({ 10000,0,0 }), obj_lb({ 0,0,0 });
			std::vector<double> coord_ub, coord_lb;
			int iter_time = 0;
			//obj, ra_turn, lowerbound, upperbound, x_coord, y_coord, xobj, time, iteration time
			std::vector<double> res_qa_f(9);
			{
				{
					double ra_turn;
					std::vector<double> bound;
					std::vector<double> obj;
					std::vector<double> coord;

					DWORD t_qanet_temp = GetTickCount64();
					double time_qa_temp = (t_qanet_temp - t_qanet1) * 1.0 / 1000;
					gurobi_program_qa_net_obo(polygon_num, length, width, alpha_obj, i_p_num, 1, cirs_bin,
						cirs_n, time_lim - time_qa_temp, ra_turn, bound, obj, coord);
					//std::cout << "obj = " << obj[0] << std::endl;

					if (qa_lb < obj[2]) {
						qa_lb = obj[2];
					}
					obj_lb = obj;
					ra_lb = ra_turn;
					coord_lb = coord;
					if (i_p_num == 10000) {
						std::vector<std::vector<double>> cirs_draw;
						std::vector<std::vector<double>> circles_merge = circle_trans(
							circle_rot(cirs_n, ra_turn), coord[0], coord[1]);
						std::merge(cirs_bin.begin(), cirs_bin.end(),
							circles_merge.begin(), circles_merge.end(), std::back_inserter(cirs_draw));
						std::vector<std::vector<double>> coord_temp = coord_adding;
						coord_temp.push_back(coord);
						draw_whole_res_with_cirs(i_p_num, length, width, pgns_temp, cirs_draw, ra_turn, obj, coord_temp);
						//draw_circle(pgn_to_draw, cirs_n);
					}
					//out_qanet.open("D:/Ph.D/Code/Packing/data/packing/run_qanet_test.txt", std::ios::out | std::ios::app);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
					//out_qanet << time_qa << " " << obj[0] << " ";

					//std::vector<std::vector<double>> coord_temp = coord_adding;
					//coord_temp.push_back(coord);
					//if (i_p_num >= 29)
					//draw_whole_res(i_p_num, length, width, pgns, ra_turn, obj, coord_temp);

					try_program_one_by_one_no_turn(length, width, alpha_obj, i_p_num, pgns_inset_temp, ra_turn,
						coord_all, obj, coord);
					//std::cout << "obj = " << obj[0] << std::endl;

					if (qa_ub > obj[2]) {
						qa_ub = obj[2];
						ra_ub = ra_turn;
						obj_ub = obj;
						coord_ub = coord;
					}
				}

				std::vector<std::vector<double>> cirs_bin_temp = cirs_bin;
				while (qa_ub - qa_lb > 0.001) {

					DWORD t_qanet_temp_2 = GetTickCount64();
					double time_qa_temp_2 = (t_qanet_temp_2 - t_qanet1) * 1.0 / 1000;
					if (time_qa_temp_2 >= time_lim)
						break;
					cir_intersection_enlarge(i_p_num, ra_lb, length, width, pgns_temp, coord_lb, obj_lb, coord_all, cirs_n,
						cirs_bin_temp);
					//if (iter_time == 20)
					//draw_circle(pgn_to_draw, cirs_n);
					double ra_turn;
					std::vector<double> bound;
					std::vector<double> obj;
					std::vector<double> coord;

					DWORD t_qanet_temp = GetTickCount64();
					double time_qa_temp = (t_qanet_temp - t_qanet1) * 1.0 / 1000;
					if (time_qa_temp >= time_lim)
						break;
					gurobi_program_qa_net_obo(polygon_num, length, width, alpha_obj, i_p_num, 1, cirs_bin_temp,
						cirs_n, time_lim - time_qa_temp, ra_turn, bound, obj, coord);
					//std::cout << "obj = " << obj[0] << std::endl;
					if (i_p_num == 10000) {
						std::vector<std::vector<double>> cirs_draw;
						std::vector<std::vector<double>> circles_merge = circle_trans(
							circle_rot(cirs_n, ra_turn), coord[0], coord[1]);
						std::merge(cirs_bin_temp.begin(), cirs_bin_temp.end(),
							circles_merge.begin(), circles_merge.end(), std::back_inserter(cirs_draw));
						std::vector<std::vector<double>> coord_temp = coord_adding;
						coord_temp.push_back(coord);
						draw_whole_res_with_cirs(i_p_num, length, width, pgns_temp, cirs_draw, ra_turn, obj, coord_temp);
						//draw_circle(pgn_to_draw, cirs_n);
					}
					t_qanet_temp_2 = GetTickCount64();
					time_qa_temp_2 = (t_qanet_temp_2 - t_qanet1) * 1.0 / 1000;
					if (time_qa_temp_2 >= time_lim)
						break;
					if (qa_lb < obj[2]) {
						qa_lb = obj[2];
					}
					obj_lb = obj;
					ra_lb = ra_turn;
					coord_lb = coord;

					try_program_one_by_one_no_turn(length, width, alpha_obj, i_p_num, pgns_inset_temp, ra_turn,
						coord_all, obj, coord);
					//std::cout << "obj = " << obj[0] << std::endl;

					if (qa_ub > obj[2]) {
						qa_ub = obj[2];
						ra_ub = ra_turn;
						obj_ub = obj;
						coord_ub = coord;
					}

					std::cout << "ub - lb = " << qa_ub - qa_lb << std::endl;
					++iter_time;
				}
				res_qa_f[0] = obj_ub[2];
				res_qa_f[1] = ra_ub;
				res_qa_f[2] = qa_lb;
				res_qa_f[3] = obj_ub[2];
				res_qa_f[4] = coord_ub[0];
				res_qa_f[5] = coord_ub[1];
				res_qa_f[6] = obj_ub[0];
			}
			DWORD t_qanet2 = GetTickCount64();
			res_qa_f[7] = (t_qanet2 - t_qanet1) * 1.0 / 1000;
			res_qa_f[8] = iter_time;

			out_qa_f.open("D:/Ph.D/Code/Packing/data/packing/run_qa_f.txt", std::ios::out | std::ios::app);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
			for (int i = 0; i < res_qa_f.size(); ++i) {
				out_qa_f << res_qa_f[i] << " ";
			}
			out_qa_f << "\n";
			out_qa_f.close();

			std::vector<std::vector<double>> circles_merge = circle_trans(
				circle_rot(circles, ra_all[i_p_num]), coord_all[i_p_num][0], coord_all[i_p_num][1]);
			std::vector<std::vector<double>> cirs_bin_temp;
			//inner_circle(pgns_trans[i_p_num], cir_num, circles_merge);
			std::merge(cirs_bin.begin(), cirs_bin.end(),
				circles_merge.begin(), circles_merge.end(), std::back_inserter(cirs_bin_temp));
			cirs_bin = cirs_bin_temp;
		}

		if (type_of_al == 4) {
			std::vector<std::vector<double>> pgn_to_draw;
			for (VertexIterator vi = pgns[i_p_num].vertices_begin(); vi != pgns[i_p_num].vertices_end(); ++vi) {
				pgn_to_draw.push_back({ to_double(vi->x().approx()),
						to_double(vi->y().approx()) });
			}
			//draw_circle(pgn_to_draw, circles);

			DWORD t_qanet1 = GetTickCount64();

			std::vector<std::vector<double>> cirs_n = cirs_s;
			double qa_ub = length + width, qa_lb = 0, ra_ub, ra_lb;
			std::vector<double> obj_ub({ 10000,0,0 }), obj_lb({ 0,0,0 });
			std::vector<double> coord_ub, coord_lb;
			int iter_time = 0;
			//obj, ra_turn, lowerbound, upperbound, x_coord, y_coord, xobj, time, iteration time
			std::vector<double> res_qa_s(9);
			{
				{
					double ra_turn;
					std::vector<double> bound;
					std::vector<double> obj;
					std::vector<double> coord;

					DWORD t_qanet_temp = GetTickCount64();
					double time_qa_temp = (t_qanet_temp - t_qanet1) * 1.0 / 1000;
					gurobi_program_qa_net_obo(polygon_num, length, width, alpha_obj, i_p_num, 1, cirs_bin,
						cirs_n, time_lim - time_qa_temp, ra_turn, bound, obj, coord);
					//std::cout << "obj = " << obj[0] << std::endl;

					if (qa_lb < obj[2]) {
						qa_lb = obj[2];
					}
					obj_lb = obj;
					ra_lb = ra_turn;
					coord_lb = coord;
					//out_qanet.open("D:/Ph.D/Code/Packing/data/packing/run_qanet_test.txt", std::ios::out | std::ios::app);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
					//out_qanet << time_qa << " " << obj[0] << " ";

					//std::vector<std::vector<double>> coord_temp = coord_adding;
					//coord_temp.push_back(coord);
					//if (i_p_num >= 29)
					//draw_whole_res(i_p_num, length, width, pgns, ra_turn, obj, coord_temp);

					try_program_one_by_one_no_turn(length, width, alpha_obj, i_p_num, pgns_inset_temp, ra_turn,
						coord_all, obj, coord);
					//std::cout << "obj = " << obj[0] << std::endl;

					if (qa_ub > obj[2]) {
						qa_ub = obj[2];
						ra_ub = ra_turn;
						obj_ub = obj;
						coord_ub = coord;
					}
				}
				while (qa_ub - qa_lb > 0.001) {

					DWORD t_qanet_temp_2 = GetTickCount64();
					double time_qa_temp_2 = (t_qanet_temp_2 - t_qanet1) * 1.0 / 1000;
					if (time_qa_temp_2 >= time_lim)
						break;
					cir_intersection(i_p_num, ra_lb, length, width, pgns_temp, coord_lb, obj_lb, coord_all, cirs_n,
						cirs_bin);
					//if (iter_time == 20)
					//draw_circle(pgn_to_draw, cirs_n);
					double ra_turn;
					std::vector<double> bound;
					std::vector<double> obj;
					std::vector<double> coord;

					DWORD t_qanet_temp = GetTickCount64();
					double time_qa_temp = (t_qanet_temp - t_qanet1) * 1.0 / 1000;
					if (time_qa_temp >= time_lim)
						break;
					gurobi_program_qa_net_obo(polygon_num, length, width, alpha_obj, i_p_num, 1, cirs_bin,
						cirs_n, time_lim - time_qa_temp, ra_turn, bound, obj, coord);
					//std::cout << "obj = " << obj[0] << std::endl;
					if (i_p_num == 10000) {
						std::vector<std::vector<double>> cirs_draw;
						std::vector<std::vector<double>> circles_merge = circle_trans(
							circle_rot(cirs_n, ra_turn), coord[0], coord[1]);
						std::merge(cirs_bin.begin(), cirs_bin.end(),
							circles_merge.begin(), circles_merge.end(), std::back_inserter(cirs_draw));
						std::vector<std::vector<double>> coord_temp = coord_adding;
						coord_temp.push_back(coord);
						draw_whole_res_with_cirs(i_p_num, length, width, pgns_temp, cirs_draw, ra_turn, obj, coord_temp);
						//draw_circle(pgn_to_draw, cirs_n);
					}
					t_qanet_temp_2 = GetTickCount64();
					time_qa_temp_2 = (t_qanet_temp_2 - t_qanet1) * 1.0 / 1000;
					if (time_qa_temp_2 >= time_lim)
						break;
					if (qa_lb < obj[2]) {
						qa_lb = obj[2];
					}
					obj_lb = obj;
					ra_lb = ra_turn;
					coord_lb = coord;

					try_program_one_by_one_no_turn(length, width, alpha_obj, i_p_num, pgns_inset_temp, ra_turn,
						coord_all, obj, coord);
					//std::cout << "obj = " << obj[0] << std::endl;

					if (qa_ub > obj[2]) {
						qa_ub = obj[2];
						ra_ub = ra_turn;
						obj_ub = obj;
						coord_ub = coord;
					}

					std::cout << "ub - lb = " << qa_ub - qa_lb << std::endl;
					++iter_time;
				}
				res_qa_s[0] = qa_ub;
				res_qa_s[1] = ra_ub;
				res_qa_s[2] = qa_lb;
				res_qa_s[3] = obj_ub[2];
				res_qa_s[4] = coord_ub[0];
				res_qa_s[5] = coord_ub[1];
				res_qa_s[6] = obj_ub[0];
			}
			DWORD t_qanet2 = GetTickCount64();
			res_qa_s[7] = (t_qanet2 - t_qanet1) * 1.0 / 1000;
			res_qa_s[8] = iter_time;

			out_qa_s.open("D:/Ph.D/Code/Packing/data/packing/run_qa_s.txt", std::ios::out | std::ios::app);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
			for (int i = 0; i < res_qa_s.size(); ++i) {
				out_qa_s << res_qa_s[i] << " ";
			}
			out_qa_s << "\n";
			out_qa_s.close();

			std::vector<std::vector<double>> circles_merge = circle_trans(
				circle_rot(cirs_n, ra_all[i_p_num]), coord_all[i_p_num][0], coord_all[i_p_num][1]);
			std::vector<std::vector<double>> cirs_bin_temp;
			//inner_circle(pgns_trans[i_p_num], cir_num, circles_merge);
			std::merge(cirs_bin.begin(), cirs_bin.end(),
				circles_merge.begin(), circles_merge.end(), std::back_inserter(cirs_bin_temp));
			cirs_bin = cirs_bin_temp;

			out_cirs.open("D:/Ph.D/Code/Packing/data/packing/run_cirs.txt", std::ios::out);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
			for (int i = 0; i < cirs_bin.size(); ++i) {
				out_cirs << cirs_bin[i][0] << " " << cirs_bin[i][1] << " " << cirs_bin[i][2] << "\n";
			}
			out_cirs.close();
		}

		coord_adding.push_back(coord_all[i_p_num]);
		pgns_adding.push_back(pgns[i_p_num]);
		pgns_trans_adding.push_back(pgns_trans[i_p_num]);
		pgns_inset_adding.push_back(pgns_inset[i_p_num]);
	}
	return 0;
}

/*
\n 换行符(LF)

\r 回车(CR) ，相当于键盘上的"Enter"

\t 跳到下一个TAB位置

\0 空字符(NULL)

\' 单引号（撇号）

\" 双引号

\\ 代表一个反斜线字符''\'

\ 继续符，可用于一行的结尾，表示本行与下一行连接起来
*/