﻿// 上汽项目程序
// 为了便于输出，必须更改输出目录
// 测试四边形能不能放进边角料/能不能包住零件
#include <list>
#include <iostream>
#include <fstream>
#include <cassert>
#include <algorithm>

#include <thread>

#include <Eigen/Dense>

#include <CGAL/IO/read_points.h>

#include <CGAL/Simple_cartesian.h>
#include <CGAL/Min_sphere_of_spheres_d.h>
#include <CGAL/Min_sphere_of_points_d_traits_2.h>
#include <CGAL/Random.h>

#include <CGAL/Exact_predicates_exact_constructions_kernel.h>
#include <CGAL/Polygon_2.h>
#include <CGAL/Polygon_with_holes_2.h>
#include <CGAL/Polygon_set_2.h>

#include <CGAL/Boolean_set_operations_2.h>

#include <CGAL/draw_polygon_set_2.h>
#include <CGAL/draw_polygon_2.h>
#include <CGAL/draw_polygon_with_holes_2.h>

#include <CGAL/Polyhedron_3.h>
#include <CGAL/Nef_polyhedron_3.h>
#include <CGAL/minkowski_sum_2.h>
#include <CGAL/minkowski_sum_3.h>
#include <CGAL/partition_2.h>
#include <CGAL/Partition_traits_2.h>
#include <CGAL/IO/Nef_polyhedron_iostream_3.h>
#include <CGAL/Nef_3/SNC_indexed_items.h>
#include <CGAL/convex_decomposition_3.h>
#include <CGAL/convex_hull_3.h>
#include <CGAL/approximated_offset_2.h>
#include <CGAL/Gps_circle_segment_traits_2.h>

#include <CGAL/draw_polyhedron.h>
#include <CGAL/draw_nef_3.h>

#include <CGAL/Epick_d.h>
#include <CGAL/Triangulation.h>

#include <draw_res.h>
#include <point_calculation.h>
#include <input_initialize.h>
#include <calculate_2d.h>
#include <calculate_3d.h>
#include <generate_para_2d.h>
#include <generate_para_3d.h>
#include <generate_para_4d.h>
#include <test_draw.h>
#include <draw_whole_res.h>
#include <simple_cal.h>


#define PI 3.1415926535

#define Epsilon 0.00000001

typedef CGAL::Exact_predicates_exact_constructions_kernel K;
typedef CGAL::Polygon_2<K>                                Polygon_2;
typedef CGAL::Polygon_with_holes_2<K>                     Polygon_with_holes_2;
typedef CGAL::Polygon_set_2<K>                            Polygon_set_2;
typedef CGAL::Point_2<K>                                  Point_2;
typedef CGAL::Vector_2<K>                                 Vector_2;
typedef CGAL::Point_3<K>                                  Point_3;
typedef CGAL::Polyhedron_3<K>							  Polyhedron;
typedef CGAL::Nef_polyhedron_3<K>						  Nef_polyhedron;
//typedef K::Point_2										  Point;
using std::cout;
using std::endl;

typedef CGAL::Simple_cartesian<double>                   c_K;//引自参考min_circle_2的例子
typedef CGAL::Min_sphere_of_points_d_traits_2<c_K, double>   c_Traits;
typedef CGAL::Min_sphere_of_spheres_d<c_Traits>            Min_circle;
typedef CGAL::Point_2<c_K>                                 c_Point_2;
typedef CGAL::Polygon_2<c_K>                                c_Polygon_2;
typedef c_K::Point_3									   input_Point;

typedef CGAL::Partition_traits_2<K>                         Traits;
typedef Traits::Polygon_2                                   p_Polygon_2;
typedef Traits::Point_2                                     p_Point_2;

typedef Polygon_2::Vertex_iterator						  VertexIterator;
typedef Polygon_2::Edge_const_iterator					  EdgeIterator;
typedef p_Polygon_2::Vertex_iterator					  p_VertexIterator;
typedef Nef_polyhedron::Volume_const_iterator			  Volume_const_iterator;
typedef Polyhedron::Vertex_iterator						  phd_VertexIterator;
typedef Polyhedron::Facet_iterator					      phd_FacetIterator;
//typedef Nef_polyhedron::Vertex_iterator					  N_phd_VertexIterator;
typedef Nef_polyhedron::Aff_transformation_3			  Aff_transformation_3;
typedef Polyhedron::Halfedge_around_facet_circulator	  Halfedge_facet_circulator;

typedef CGAL::Epick_d<CGAL::Dynamic_dimension_tag>		  D_dim;
typedef CGAL::Triangulation<D_dim>                        Triangulation;
typedef CGAL::Triangulation_data_structure<D_dim>         TDS;
typedef Triangulation::Point			                  D_dim_point;
typedef Triangulation::Full_cell_handle					  Full_cell_handle;
typedef Triangulation::Facet							  Facet;
typedef Triangulation::Face								  Face;

typedef std::list<Point_2>								  Point_list_2;
typedef std::list<c_Point_2>							  c_Point_list_2;
typedef std::list<p_Polygon_2>                            p_Pgn_list_2;
typedef std::list<Point_3>								  Point_list_3;
typedef std::list<Polygon_with_holes_2>                   Pwh_list_2;
typedef std::list<Polygon_2>							  Pgn_list_2;
typedef std::list<Nef_polyhedron>						  N_phd_list;
typedef std::list<Polyhedron>							  phd_list;
typedef std::vector<Full_cell_handle>					  Full_cells;
typedef std::vector<Face>								  Faces;

typedef CGAL::Gps_circle_segment_traits_2<K>			Traits_gps;
typedef Traits_gps::Polygon_2							Polygon_2_gps;
typedef Traits_gps::Polygon_with_holes_2                Polygon_with_holes_2_gps;

bool res_sort_nfp(std::vector<double> a, std::vector<double> b) {
	if (a[0] < b[0] + Epsilon && b[0] < a[0] + Epsilon)
		return a[1] < b[1];//如果目标函数一样，重合面积升序
	else
		return a[0] < b[0];//目标函数升序(小的放前面)
}

bool res_sort_ifp(std::vector<double> a, std::vector<double> b) {
	if (a[4] == b[4])
		return a[0] < b[0];//如果ifp编号一样，目标函数升序
	else
		return a[4] < b[4];//ifp编号升序(小的放前面)
}

//根据数组第一位（下标为0），升序排序（小的放前面）
bool res_sort_0(std::vector<double> a, std::vector<double> b) {
	return a[0] < b[0];//ifp编号升序(小的放前面)
}

int main()
{
	std::ofstream out_poi;
	out_poi.precision(50);

	int try_quad;
	try_quad = 0;
	std::cout << "请输入选择哪个四边形进行拟合，0为全部尝试，1为矩形，2为平行四边形，3为等腰梯形，4为直角梯形，按回车结束" << std::endl;
	std::cin >> try_quad;

	int whe_sheet;
	whe_sheet = 0;
	std::cout << "请输入是小零件（外部拟合）还是边角料（内部拟合），0为小零件，1为边角料，按回车结束" << std::endl;
	std::cin >> whe_sheet;

	int n_piece;
	n_piece = 0;
	std::cout << "请输入共有多少个小零件/边角料，按回车结束" << std::endl;
	std::cin >> n_piece;

	int eve_n;
	eve_n = 2;
	std::cout << "请输入选择几个均分角度进行比较，按回车结束" << std::endl;
	std::cin >> eve_n;

	int whe_allow_flip;
	whe_allow_flip = 0;
	std::cout << "请输入是否允许镜像（1为允许，0为不允许），按回车结束" << std::endl;
	std::cin >> whe_allow_flip;

	double offset_amount;
	offset_amount = 0;
	std::cout << "请输入需要留的间隙大小，按回车结束" << std::endl;
	std::cin >> offset_amount;

	std::string position = "D:/Ph.D/Code/Packing/data/packing/shang qi test 2";

	for (int i_piece = 1; i_piece <= n_piece; ++i_piece) {
		double p_id, p_n_holes;
		Polygon_2 piece;
		std::vector<Polygon_2> p_holes;
		if (whe_sheet == 0) {
			piece = input_pgn_from_txt_shangqi(position + "/Pieces/piece " + std::to_string(i_piece) + ".txt", p_id, p_n_holes);
			//piece = input_pgn_from_txt_shangqi("../Data/Pieces/piece " + std::to_string(i_piece) + ".txt", p_id, p_n_holes);
			for (int i_p_num = 0; i_p_num < p_n_holes; ++i_p_num) {
				p_holes.push_back(input_hole_from_txt_shangqi(position + "/Pieces/piece " + std::to_string(i_piece) + " hole " + std::to_string(i_p_num + 1) + ".txt"));
				//p_holes.push_back(input_hole_from_txt_shangqi("../Data/Pieces/piece " + std::to_string(i_piece) + " hole " + std::to_string(i_p_num + 1) + ".txt"));
			}
		}
		else {
			piece = input_pgn_from_txt_shangqi(position + "/Sheets/sheet " + std::to_string(i_piece) + ".txt", p_id, p_n_holes);
			//piece = input_pgn_from_txt_shangqi("../Data/Sheets/sheet " + std::to_string(i_piece) + ".txt", p_id, p_n_holes);
			for (int i_p_num = 0; i_p_num < p_n_holes; ++i_p_num) {
				p_holes.push_back(input_hole_from_txt_shangqi(position + "/Sheets/sheet " + std::to_string(i_piece) + " hole " + std::to_string(i_p_num + 1) + ".txt"));
				//p_holes.push_back(input_hole_from_txt_shangqi("../Data/Sheets/sheet " + std::to_string(i_piece) + " hole " + std::to_string(i_p_num + 1) + ".txt"));
			}
		}
		double x_p_min = 1000000, x_p_max = -1000000, y_p_min = 1000000, y_p_max = -1000000;
		for (VertexIterator vi = piece.vertices_begin(); vi != piece.vertices_end(); ++vi) {
			double vi_x = to_double(vi->x().approx());
			double vi_y = to_double(vi->y().approx());
			if (vi_x < x_p_min) x_p_min = vi_x;
			if (vi_x > x_p_max) x_p_max = vi_x;
			if (vi_y < y_p_min) y_p_min = vi_y;
			if (vi_y > y_p_max) y_p_max = vi_y;
		}
		double max_i = std::max(4.0, 1.5 * std::max({ x_p_max - x_p_min, y_p_max - y_p_min }) / 5);
		if (try_quad == 0 || try_quad == 1) {
			int which_quad = 1;
			int i_c = 0;
			if (whe_sheet == 0) {
				int min_b = 4;
				std::vector<double> temp_res_data;
				for (int i_a = floor(max_i) + 1; i_a >= 4; --i_a) {
					int whe_fit = 0;
					for (int i_b = min_b; i_b <= i_a; ++i_b) {
						double a = 5.0 * i_a, b = 5.0 * i_b, c = 5.0 * i_c;
						std::cout << "i_piece = " << i_piece << ", which_quad = " << which_quad << ", a = " << int(a) << ", b = " << int(b) << ", c = " << int(c) << std::endl;
						double x_s_min, x_s_max, y_s_min, y_s_max;
						std::vector<double> res_data;
						piece_whe_fit_quad_full(whe_sheet, eve_n, 0, offset_amount, piece, p_holes, i_piece, which_quad, a, b, c,
							p_id, p_n_holes, x_s_min, x_s_max, y_s_min, y_s_max, res_data);
						//res_data = { whe_sheet, i_piece, p_id, which_quad, a, b, c, eve_n, whe_fit, best_whe_flip, best_ang_d, best_x_co, best_y_co, x_s_max, x_s_min, y_s_max, y_s_min }
						//			   0		  1		   2	 3			 4  5  6  7		 8		  9				 10			 11			12		   13		14		 15		  16

						if (res_data[8] == 1) {
							whe_fit = 1;
							if (temp_res_data.empty() || i_b == min_b) {
								std::cout << "跳过" << std::endl;
								min_b = i_b;
								temp_res_data = res_data;
								break;
							}
							else {
								std::cout << "输出" << std::endl;
								min_b = i_b;
								output_result_quad(position, temp_res_data, p_n_holes, piece, p_holes);
								temp_res_data = res_data;
								break;
							}
						}
					}
					if (whe_fit == 0) {
						break;
					}
				}
				if (!temp_res_data.empty()) {
					std::cout << "输出" << std::endl;
					output_result_quad(position, temp_res_data, p_n_holes, piece, p_holes);
				}
			}
			if (whe_sheet == 1) {
				int max_a = floor(max_i) + 1;
				std::vector<double> temp_res_data;
				for (int i_b = 4; i_b <= floor(max_i) + 1; ++i_b) {
					int whe_fit = 0;
					for (int i_a = max_a; i_a >= i_b; --i_a) {
						double a = 5.0 * i_a, b = 5.0 * i_b, c = 5.0 * i_c;
						std::cout << "i_piece = " << i_piece << ", which_quad = " << which_quad << ", a = " << int(a) << ", b = " << int(b) << ", c = " << int(c) << std::endl;
						double x_s_min, x_s_max, y_s_min, y_s_max;
						std::vector<double> res_data;
						piece_whe_fit_quad_full(whe_sheet, eve_n, 0, offset_amount, piece, p_holes, i_piece, which_quad, a, b, c,
							p_id, p_n_holes, x_s_min, x_s_max, y_s_min, y_s_max, res_data);
						//res_data = { whe_sheet, i_piece, p_id, which_quad, a, b, c, eve_n, whe_fit, best_whe_flip, best_ang_d, best_x_co, best_y_co, x_s_max, x_s_min, y_s_max, y_s_min }
						//			   0		  1		   2	 3			 4  5  6  7		 8		  9				 10			 11			12		   13		14		 15		  16

						if (res_data[8] == 1) {
							whe_fit = 1;
							if (temp_res_data.empty() || i_a == max_a) {
								std::cout << "跳过" << std::endl;
								max_a = i_a;
								temp_res_data = res_data;
								break;
							}
							else {
								std::cout << "输出" << std::endl;
								max_a = i_a;
								output_result_quad(position, temp_res_data, p_n_holes, piece, p_holes);
								temp_res_data = res_data;
								break;
							}
						}
					}
					if (whe_fit == 0) {
						break;
					}
				}
				if (!temp_res_data.empty()) {
					std::cout << "输出" << std::endl;
					output_result_quad(position, temp_res_data, p_n_holes, piece, p_holes);
				}
			}
		}
		if (try_quad == 0 || try_quad == 2) {
			int which_quad = 2;
			if (whe_sheet == 0) {
				for (int i_c = 2; i_c <= 10; ++i_c) {
					if (i_c == 6)
						++i_c;
					int min_b = 4;
					std::vector<double> temp_res_data;
					for (int i_a = floor(max_i) + 1; i_a >= 4; --i_a) {
						int whe_fit = 0;
						for (int i_b = min_b; i_b <= i_a; ++i_b) {
							double a = 5.0 * i_a, b = 5.0 * i_b, c = 15.0 * i_c;
							std::cout << "i_piece = " << i_piece << ", which_quad = " << which_quad << ", a = " << int(a) << ", b = " << int(b) << ", c = " << int(c) << std::endl;
							double x_s_min, x_s_max, y_s_min, y_s_max;
							std::vector<double> res_data;
							piece_whe_fit_quad_full(whe_sheet, eve_n, 0, offset_amount, piece, p_holes, i_piece, which_quad, a, b, c,
								p_id, p_n_holes, x_s_min, x_s_max, y_s_min, y_s_max, res_data);
							//res_data = { whe_sheet, i_piece, p_id, which_quad, a, b, c, eve_n, whe_fit, best_whe_flip, best_ang_d, best_x_co, best_y_co, x_s_max, x_s_min, y_s_max, y_s_min }
							//			   0		  1		   2	 3			 4  5  6  7		 8		  9				 10			 11			12		   13		14		 15		  16

							if (res_data[8] == 1) {
								whe_fit = 1;
								if (temp_res_data.empty() || i_b == min_b) {
									std::cout << "跳过" << std::endl;
									min_b = i_b;
									temp_res_data = res_data;
									break;
								}
								else {
									std::cout << "输出" << std::endl;
									min_b = i_b;
									output_result_quad(position, temp_res_data, p_n_holes, piece, p_holes);
									temp_res_data = res_data;
									break;
								}
							}
						}
						if (whe_fit == 0) {
							break;
						}
					}
					std::cout << "输出" << std::endl;
					output_result_quad(position, temp_res_data, p_n_holes, piece, p_holes);
				}
			}
			if (whe_sheet == 1) {
				for (int i_c = 2; i_c <= 10; ++i_c) {
					if (i_c == 6)
						++i_c;
					int max_a = floor(max_i) + 1;
					std::vector<double> temp_res_data;
					for (int i_b = 4; i_b <= floor(max_i) + 1; ++i_b) {
						int whe_fit = 0;
						for (int i_a = max_a; i_a >= i_b; --i_a) {
							double a = 5.0 * i_a, b = 5.0 * i_b, c = 15.0 * i_c;
							std::cout << "i_piece = " << i_piece << ", which_quad = " << which_quad << ", a = " << int(a) << ", b = " << int(b) << ", c = " << int(c) << std::endl;
							double x_s_min, x_s_max, y_s_min, y_s_max;
							std::vector<double> res_data;
							piece_whe_fit_quad_full(whe_sheet, eve_n, 0, offset_amount, piece, p_holes, i_piece, which_quad, a, b, c,
								p_id, p_n_holes, x_s_min, x_s_max, y_s_min, y_s_max, res_data);
							//res_data = { whe_sheet, i_piece, p_id, which_quad, a, b, c, eve_n, whe_fit, best_whe_flip, best_ang_d, best_x_co, best_y_co, x_s_max, x_s_min, y_s_max, y_s_min }
							//			   0		  1		   2	 3			 4  5  6  7		 8		  9				 10			 11			12		   13		14		 15		  16

							if (res_data[8] == 1) {
								whe_fit = 1;
								if (temp_res_data.empty() || i_a == max_a) {
									std::cout << "跳过" << std::endl;
									max_a = i_a;
									temp_res_data = res_data;
									break;
								}
								else {
									std::cout << "输出" << std::endl;
									max_a = i_a;
									output_result_quad(position, temp_res_data, p_n_holes, piece, p_holes);
									temp_res_data = res_data;
									break;
								}
							}
						}
						if (whe_fit == 0) {
							break;
						}
					}
					if (!temp_res_data.empty()) {
						std::cout << "输出" << std::endl;
						output_result_quad(position, temp_res_data, p_n_holes, piece, p_holes);
					}
				}
			}
		}
		if (try_quad == 0 || try_quad == 3) {
			int which_quad = 3;
			if (whe_sheet == 0) {
				std::vector<std::vector<double>> vec_temp_res_data(floor(max_i) + 1);
				std::vector<int> vec_min_b(floor(max_i) + 2, 4);
				std::vector<int> vec_whe_good(floor(max_i) + 2, 0);
				for (int i_a = floor(max_i) + 1; i_a >= 4; --i_a) {
					for (int i_c = i_a - 1; i_c >= 4; --i_c) {
						int whe_fit = 0;
						for (int i_b = std::max(vec_min_b[i_c + 1], vec_min_b[i_c]); i_b <= floor(max_i) + 1; ++i_b) {
							double a = 5.0 * i_a, b = 5.0 * i_b, c = 5.0 * i_c;
							std::cout << "i_piece = " << i_piece << ", which_quad = " << which_quad << ", a = " << int(a) << ", b = " << int(b) << ", c = " << int(c) << std::endl;
							double x_s_min, x_s_max, y_s_min, y_s_max;
							std::vector<double> res_data;
							piece_whe_fit_quad_full(whe_sheet, eve_n, 0, offset_amount, piece, p_holes, i_piece, which_quad, a, b, c,
								p_id, p_n_holes, x_s_min, x_s_max, y_s_min, y_s_max, res_data);
							//res_data = { whe_sheet, i_piece, p_id, which_quad, a, b, c, eve_n, whe_fit, best_whe_flip, best_ang_d, best_x_co, best_y_co, x_s_max, x_s_min, y_s_max, y_s_min }
							//			   0		  1		   2	 3			 4  5  6  7		 8		  9				 10			 11			12		   13		14		 15		  16

							if (res_data[8] == 1) {
								whe_fit = 1;
								if (vec_temp_res_data[i_c].empty() || i_b == vec_min_b[i_c] || vec_whe_good[i_c] == 0) {
									std::cout << "跳过" << std::endl;
									vec_whe_good[i_c] = 1;
									vec_min_b[i_c] = i_b;
									vec_temp_res_data[i_c] = res_data;
								}
								else {
									std::cout << "输出" << std::endl;
									vec_min_b[i_c] = i_b;
									output_result_quad(position, vec_temp_res_data[i_c], p_n_holes, piece, p_holes);
									vec_temp_res_data[i_c] = res_data;
								}
								if (i_b == vec_min_b[i_c + 1]) {
									vec_whe_good[i_c + 1] = 0;
								}
								if (i_c == i_a - 2 && i_b > vec_min_b[i_c + 1]) {
									std::cout << "输出 i_c = i_a - 1 的情况" << std::endl;
									vec_whe_good[i_c + 1] = 0;
									output_result_quad(position, vec_temp_res_data[i_c + 1], p_n_holes, piece, p_holes);
								}
								break;
							}
						}
						if (whe_fit == 0) {
							vec_min_b[i_c] = floor(max_i) + 2;
							if (!vec_temp_res_data[i_c].empty() && vec_whe_good[i_c] == 1) {
								std::cout << "输出" << std::endl;
								vec_whe_good[i_c] = 0;
								output_result_quad(position, vec_temp_res_data[i_c], p_n_holes, piece, p_holes);
							}
							if (i_c == i_a - 2 && !vec_temp_res_data[i_c + 1].empty() && vec_whe_good[i_c + 1] == 1) {
								std::cout << "输出 i_c = i_a - 1 的情况" << std::endl;
								vec_whe_good[i_c + 1] = 0;
								output_result_quad(position, vec_temp_res_data[i_c + 1], p_n_holes, piece, p_holes);
							}
						}
					}
					if (!vec_temp_res_data[4].empty() && vec_whe_good[4] == 1) {
						std::cout << "输出最后一个解" << std::endl;
						vec_whe_good[4] = 0;
						output_result_quad(position, vec_temp_res_data[4], p_n_holes, piece, p_holes);
					}
				}
			}
			if (whe_sheet == 1) {
				std::vector<std::vector<double>> vec_temp_res_data(floor(max_i) + 2);
				std::vector<int> vec_max_a(floor(max_i) + 2, floor(max_i) + 1);
				std::vector<int> vec_whe_good(floor(max_i) + 2, 0);
				for (int i_b = 4; i_b <= floor(max_i) + 1; ++i_b) {
					for (int i_c = 4; i_c <= floor(max_i) + 1; ++i_c) {
						int whe_fit = 0;
						for (int i_a = std::min(vec_max_a[i_c], vec_max_a[i_c - 1]); i_a >= i_c + 1; --i_a) {
							double a = 5.0 * i_a, b = 5.0 * i_b, c = 5.0 * i_c;
							std::cout << "i_piece = " << i_piece << ", which_quad = " << which_quad << ", a = " << int(a) << ", b = " << int(b) << ", c = " << int(c) << std::endl;
							double x_s_min, x_s_max, y_s_min, y_s_max;
							std::vector<double> res_data;
							piece_whe_fit_quad_full(whe_sheet, eve_n, 0, offset_amount, piece, p_holes, i_piece, which_quad, a, b, c,
								p_id, p_n_holes, x_s_min, x_s_max, y_s_min, y_s_max, res_data);
							//res_data = { whe_sheet, i_piece, p_id, which_quad, a, b, c, eve_n, whe_fit, best_whe_flip, best_ang_d, best_x_co, best_y_co, x_s_max, x_s_min, y_s_max, y_s_min }
							//			   0		  1		   2	 3			 4  5  6  7		 8		  9				 10			 11			12		   13		14		 15		  16

							if (res_data[8] == 1) {
								whe_fit = 1;
								if (vec_temp_res_data[i_c].empty() || i_a == vec_max_a[i_c] || vec_whe_good[i_c] == 0) {
									std::cout << "跳过" << std::endl;
									vec_whe_good[i_c] = 1;
									vec_max_a[i_c] = i_a; 
									vec_temp_res_data[i_c] = res_data;
								}
								else {
									std::cout << "输出" << std::endl;
									//std::cout << "i_piece = " << i_piece << ", which_quad = " << which_quad << ", a = " << int(vec_temp_res_data[i_c][4]) << ", b = " << int(vec_temp_res_data[i_c][5]) << ", c = " << int(vec_temp_res_data[i_c][6]) << std::endl;
									vec_max_a[i_c] = i_a;
									output_result_quad(position, vec_temp_res_data[i_c], p_n_holes, piece, p_holes);
									vec_temp_res_data[i_c] = res_data;
								}
								if (i_a == vec_max_a[i_c - 1]) {
									vec_whe_good[i_c - 1] = 0;
								}
								if (i_b == floor(max_i) + 1 && i_a < vec_max_a[i_c - 1]) {
									std::cout << "输出 i_b == floor(max_i) + 1 的情况" << std::endl;
									vec_whe_good[i_c - 1] = 0;
									output_result_quad(position, vec_temp_res_data[i_c - 1], p_n_holes, piece, p_holes);
								}
								break;
							}
						}
						if (whe_fit == 0) {
							vec_max_a[i_c] = 0;
							if (!vec_temp_res_data[i_c].empty() && vec_whe_good[i_c] == 1) {
								std::cout << "输出" << std::endl;
								//std::cout << "i_piece = " << i_piece << ", which_quad = " << which_quad << ", a = " << int(vec_temp_res_data[i_c][4]) << ", b = " << int(vec_temp_res_data[i_c][5]) << ", c = " << int(vec_temp_res_data[i_c][6]) << std::endl;
								vec_whe_good[i_c] = 0;
								output_result_quad(position, vec_temp_res_data[i_c], p_n_holes, piece, p_holes);
							}
							if (i_b == floor(max_i) + 1 && !vec_temp_res_data[i_c - 1].empty() && vec_whe_good[i_c - 1] == 1) {
								std::cout << "输出 i_c = i_a - 1 的情况" << std::endl;
								vec_whe_good[i_c - 1] = 0;
								output_result_quad(position, vec_temp_res_data[i_c - 1], p_n_holes, piece, p_holes);
							}
						}
					}
					if (!vec_temp_res_data[floor(max_i) + 1].empty() && vec_whe_good[floor(max_i) + 1] == 1) {
						std::cout << "输出最后一个解" << std::endl;
						vec_whe_good[floor(max_i) + 1] = 0;
						output_result_quad(position, vec_temp_res_data[floor(max_i) + 1], p_n_holes, piece, p_holes);
					}
				}
			}
		}
		if (try_quad == 0 || try_quad == 4) {
			int which_quad = 4;
			if (whe_sheet == 0) {
				std::vector<std::vector<double>> vec_temp_res_data(floor(max_i) + 1);
				std::vector<int> vec_min_b(floor(max_i) + 2, 4);
				std::vector<int> vec_whe_good(floor(max_i) + 2, 0);
				for (int i_a = floor(max_i) + 1; i_a >= 4; --i_a) {
					for (int i_c = i_a - 1; i_c >= 4; --i_c) {
						int whe_fit = 0;
						for (int i_b = std::max(vec_min_b[i_c + 1], vec_min_b[i_c]); i_b <= floor(max_i) + 1; ++i_b) {
							double a = 5.0 * i_a, b = 5.0 * i_b, c = 5.0 * i_c;
							std::cout << "i_piece = " << i_piece << ", which_quad = " << which_quad << ", a = " << int(a) << ", b = " << int(b) << ", c = " << int(c) << std::endl;
							double x_s_min, x_s_max, y_s_min, y_s_max;
							std::vector<double> res_data;
							piece_whe_fit_quad_full(whe_sheet, eve_n, whe_allow_flip, offset_amount, piece, p_holes, i_piece, which_quad, a, b, c,
								p_id, p_n_holes, x_s_min, x_s_max, y_s_min, y_s_max, res_data);
							//res_data = { whe_sheet, i_piece, p_id, which_quad, a, b, c, eve_n, whe_fit, best_whe_flip, best_ang_d, best_x_co, best_y_co, x_s_max, x_s_min, y_s_max, y_s_min }
							//			   0		  1		   2	 3			 4  5  6  7		 8		  9				 10			 11			12		   13		14		 15		  16

							if (res_data[8] == 1) {
								whe_fit = 1;
								if (vec_temp_res_data[i_c].empty() || i_b == vec_min_b[i_c] || vec_whe_good[i_c] == 0) {
									std::cout << "跳过" << std::endl;
									vec_whe_good[i_c] = 1;
									vec_min_b[i_c] = i_b;
									vec_temp_res_data[i_c] = res_data;
								}
								else {
									std::cout << "输出" << std::endl;
									vec_min_b[i_c] = i_b;
									output_result_quad(position, vec_temp_res_data[i_c], p_n_holes, piece, p_holes);
									vec_temp_res_data[i_c] = res_data;
								}
								if (i_b == vec_min_b[i_c + 1]) {
									vec_whe_good[i_c + 1] = 0;
								}
								if (i_c == i_a - 2 && i_b > vec_min_b[i_c + 1]) {
									std::cout << "输出 i_c = i_a - 1 的情况" << std::endl;
									vec_whe_good[i_c + 1] = 0;
									output_result_quad(position, vec_temp_res_data[i_c + 1], p_n_holes, piece, p_holes);
								}
								break;
							}
						}
						if (whe_fit == 0) {
							vec_min_b[i_c] = floor(max_i) + 2;
							if (!vec_temp_res_data[i_c].empty() && vec_whe_good[i_c] == 1) {
								std::cout << "输出" << std::endl;
								vec_whe_good[i_c] = 0;
								output_result_quad(position, vec_temp_res_data[i_c], p_n_holes, piece, p_holes);
							}
							if (i_c == i_a - 2 && !vec_temp_res_data[i_c + 1].empty() && vec_whe_good[i_c + 1] == 1) {
								std::cout << "输出 i_c = i_a - 1 的情况" << std::endl;
								vec_whe_good[i_c + 1] = 0;
								output_result_quad(position, vec_temp_res_data[i_c + 1], p_n_holes, piece, p_holes);
							}
						}
					}
					if (!vec_temp_res_data[4].empty() && vec_whe_good[4] == 1) {
						std::cout << "输出最后一个解" << std::endl;
						vec_whe_good[4] = 0;
						output_result_quad(position, vec_temp_res_data[4], p_n_holes, piece, p_holes);
					}
				}
			}
			if (whe_sheet == 1) {
				std::vector<std::vector<double>> vec_temp_res_data(floor(max_i) + 2);
				std::vector<int> vec_max_a(floor(max_i) + 2, floor(max_i) + 1);
				std::vector<int> vec_whe_good(floor(max_i) + 2, 0);
				for (int i_b = 4; i_b <= floor(max_i) + 1; ++i_b) {
					for (int i_c = 4; i_c <= floor(max_i) + 1; ++i_c) {
						int whe_fit = 0;
						for (int i_a = std::min(vec_max_a[i_c], vec_max_a[i_c - 1]); i_a >= i_c + 1; --i_a) {
							double a = 5.0 * i_a, b = 5.0 * i_b, c = 5.0 * i_c;
							std::cout << "i_piece = " << i_piece << ", which_quad = " << which_quad << ", a = " << int(a) << ", b = " << int(b) << ", c = " << int(c) << std::endl;
							double x_s_min, x_s_max, y_s_min, y_s_max;
							std::vector<double> res_data;
							piece_whe_fit_quad_full(whe_sheet, eve_n, whe_allow_flip, offset_amount, piece, p_holes, i_piece, which_quad, a, b, c,
								p_id, p_n_holes, x_s_min, x_s_max, y_s_min, y_s_max, res_data);
							//res_data = { whe_sheet, i_piece, p_id, which_quad, a, b, c, eve_n, whe_fit, best_whe_flip, best_ang_d, best_x_co, best_y_co, x_s_max, x_s_min, y_s_max, y_s_min }
							//			   0		  1		   2	 3			 4  5  6  7		 8		  9				 10			 11			12		   13		14		 15		  16

							if (res_data[8] == 1) {
								whe_fit = 1;
								if (vec_temp_res_data[i_c].empty() || i_a == vec_max_a[i_c] || vec_whe_good[i_c] == 0) {
									std::cout << "跳过" << std::endl;
									vec_whe_good[i_c] = 1;
									vec_max_a[i_c] = i_a;
									vec_temp_res_data[i_c] = res_data;
								}
								else {
									std::cout << "输出" << std::endl;
									//std::cout << "i_piece = " << i_piece << ", which_quad = " << which_quad << ", a = " << int(vec_temp_res_data[i_c][4]) << ", b = " << int(vec_temp_res_data[i_c][5]) << ", c = " << int(vec_temp_res_data[i_c][6]) << std::endl;
									vec_max_a[i_c] = i_a;
									output_result_quad(position, vec_temp_res_data[i_c], p_n_holes, piece, p_holes);
									vec_temp_res_data[i_c] = res_data;
								}
								if (i_a == vec_max_a[i_c - 1]) {
									vec_whe_good[i_c - 1] = 0;
								}
								if (i_b == floor(max_i) + 1 && i_a < vec_max_a[i_c - 1]) {
									std::cout << "输出 i_b == floor(max_i) + 1 的情况" << std::endl;
									vec_whe_good[i_c - 1] = 0;
									output_result_quad(position, vec_temp_res_data[i_c - 1], p_n_holes, piece, p_holes);
								}
								break;
							}
						}
						if (whe_fit == 0) {
							vec_max_a[i_c] = 0;
							if (!vec_temp_res_data[i_c].empty() && vec_whe_good[i_c] == 1) {
								std::cout << "输出" << std::endl;
								//std::cout << "i_piece = " << i_piece << ", which_quad = " << which_quad << ", a = " << int(vec_temp_res_data[i_c][4]) << ", b = " << int(vec_temp_res_data[i_c][5]) << ", c = " << int(vec_temp_res_data[i_c][6]) << std::endl;
								vec_whe_good[i_c] = 0;
								output_result_quad(position, vec_temp_res_data[i_c], p_n_holes, piece, p_holes);
							}
							if (i_b == floor(max_i) + 1 && !vec_temp_res_data[i_c - 1].empty() && vec_whe_good[i_c - 1] == 1) {
								std::cout << "输出 i_c = i_a - 1 的情况" << std::endl;
								vec_whe_good[i_c - 1] = 0;
								output_result_quad(position, vec_temp_res_data[i_c - 1], p_n_holes, piece, p_holes);
							}
						}
					}
					if (!vec_temp_res_data[floor(max_i) + 1].empty() && vec_whe_good[floor(max_i) + 1] == 1) {
						std::cout << "输出最后一个解" << std::endl;
						vec_whe_good[floor(max_i) + 1] = 0;
						output_result_quad(position, vec_temp_res_data[floor(max_i) + 1], p_n_holes, piece, p_holes);
					}
				}
			}
		}
	}
	/*
	for (int i_sheet = 1; i_sheet <= n_sheet; ++i_sheet) {
		for (int i_piece = 1; i_piece <= n_piece; ++i_piece) {
			double s_id, s_n_holes;
			Polygon_2 sheet = input_pgn_from_txt_shangqi("D:/Ph.D/Code/Packing/data/packing/shang qi test/Sheets/sheet " + std::to_string(i_sheet) + ".txt", s_id, s_n_holes);
			//Polygon_2 sheet = input_pgn_from_txt_shangqi("../Data/Sheets/sheet " + std::to_string(i_sheet) + ".txt", s_id, s_n_holes);

			std::vector<Polygon_2> s_holes;
			for (int i_p_num = 0; i_p_num < s_n_holes; ++i_p_num) {
				s_holes.push_back(input_hole_from_txt_shangqi("D:/Ph.D/Code/Packing/data/packing/shang qi test/Sheets/sheet " + std::to_string(i_sheet) + " hole " + std::to_string(i_p_num + 1) + ".txt"));
				//s_holes.push_back(input_hole_from_txt_shangqi("../Data/Sheets/sheet " + std::to_string(i_sheet) + " hole " + std::to_string(i_p_num + 1) + ".txt"));
			}
			double p_id, p_n_holes;
			Polygon_2 piece = input_pgn_from_txt_shangqi("D:/Ph.D/Code/Packing/data/packing/shang qi test/Pieces/piece " + std::to_string(i_piece) + ".txt", p_id, p_n_holes);
			//Polygon_2 piece = input_pgn_from_txt_shangqi("../Data/Pieces/piece " + std::to_string(i_piece) + ".txt", p_id, p_n_holes);
			std::vector<Polygon_2> p_holes;
			for (int i_p_num = 0; i_p_num < p_n_holes; ++i_p_num) {
				p_holes.push_back(input_hole_from_txt_shangqi("D:/Ph.D/Code/Packing/data/packing/shang qi test/Pieces/piece " + std::to_string(i_piece) + " hole " + std::to_string(i_p_num + 1) + ".txt"));
				//p_holes.push_back(input_hole_from_txt_shangqi("../Data/Pieces/piece " + std::to_string(i_piece) + " hole " + std::to_string(i_p_num + 1) + ".txt"));
			}

			double x_s_min, x_s_max, y_s_min, y_s_max;
			std::vector<double> res_data;
			piece_whe_fit_sheet_full(eve_n, whe_allow_flip, offset_amount, sheet, s_holes, piece, p_holes, i_sheet, i_piece, s_id, s_n_holes, 
				p_id, p_n_holes, x_s_min, x_s_max, y_s_min, y_s_max, res_data);
			if (res_data[5] == 1) {
				double best_ang = res_data[7] * (2.0 * PI) / 360;
				Polygon_set_2 fin_res;
				fin_res.insert(sheet);
				for (int i_p_num = 0; i_p_num < s_n_holes; ++i_p_num) {
					fin_res.difference(s_holes[i_p_num]);
				}
				if (res_data[6] == 0) {
					fin_res.difference(Polygon_2_trans(Polygon_2_turn_acw(piece, best_ang), res_data[8], res_data[9]));
					for (int i_p_num = 0; i_p_num < p_n_holes; ++i_p_num) {
						fin_res.join(Polygon_2_trans(Polygon_2_turn_acw(p_holes[i_p_num], best_ang), res_data[8], res_data[9]));
					}
				}
				else {
					fin_res.difference(Polygon_2_trans(Polygon_2_turn_acw(Polygon_2_flip(piece), best_ang), res_data[8], res_data[9]));
					for (int i_p_num = 0; i_p_num < p_n_holes; ++i_p_num) {
						fin_res.join(Polygon_2_trans(Polygon_2_turn_acw(Polygon_2_flip(p_holes[i_p_num]), best_ang), res_data[8], res_data[9]));
					}
				}

				std::vector<Polygon_2> sheet_v_draw;
				sheet_v_draw.push_back(sheet);
				for (int i_p_num = 0; i_p_num < s_n_holes; ++i_p_num)
					sheet_v_draw.push_back(s_holes[i_p_num]);
				std::vector<Polygon_2> piece_v_draw;
				if (res_data[6] == 0) {
					piece_v_draw.push_back(Polygon_2_trans(Polygon_2_turn_acw(piece, best_ang), res_data[8], res_data[9]));
					for (int i_p_num = 0; i_p_num < p_n_holes; ++i_p_num)
						piece_v_draw.push_back(Polygon_2_trans(Polygon_2_turn_acw(p_holes[i_p_num], best_ang), res_data[8], res_data[9]));
				}
				else {
					piece_v_draw.push_back(Polygon_2_trans(Polygon_2_turn_acw(Polygon_2_flip(piece), best_ang), res_data[8], res_data[9]));
					for (int i_p_num = 0; i_p_num < p_n_holes; ++i_p_num)
						piece_v_draw.push_back(Polygon_2_trans(Polygon_2_turn_acw(Polygon_2_flip(p_holes[i_p_num]), best_ang), res_data[8], res_data[9]));
				}

				std::vector<Polygon_2> Ps1 = sheet_v_draw;
				std::vector<Polygon_2> Ps2 = piece_v_draw;
				std::string filename = "D:/Ph.D/Code/Packing/data/packing/shang qi test/Results/result sheet " + std::to_string(i_sheet) + " piece " + std::to_string(i_piece) + ".svg";
				//std::string filename = "../Data/Results/result sheet " + std::to_string(i_sheet) + " piece " + std::to_string(i_piece) + ".svg";
				save_polygon_as_svg(Ps1, Ps2, x_s_max, x_s_min, y_s_max, y_s_min, filename);
			}
			std::string ad_str = "D:/Ph.D/Code/Packing/data/packing/shang qi test/result.txt";
			//std::string ad_str = "../Data/result.txt";
			out_poi.open(ad_str.c_str(), std::ios::out | std::ios::app);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
			for (int i = 0; i < res_data.size(); ++i)
				out_poi << res_data[i] << " ";
			out_poi << "\n";
			out_poi.close();
		}
	}
	*/
	std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
	std::cout << "程序已执行完毕，按回车键关闭窗口" << std::endl;
	std::cin.get();
	return 0;
}

/*
\n 换行符(LF)

\r 回车(CR) ，相当于键盘上的"Enter"

\t 跳到下一个TAB位置

\0 空字符(NULL)

\' 单引号（撇号）

\" 双引号

\\ 代表一个反斜线字符''\'

\ 继续符，可用于一行的结尾，表示本行与下一行连接起来
*/