﻿//尝试plane with key points数据集，计算所有nfp结果
#include <list>
#include <iostream>
#include <fstream>
#include <cassert>

#include <thread>

#include <ilcplex\ilocplex.h>
ILOSTLBEGIN // 等同于 using namespace std; 声明命名空间

#include <Eigen/Dense>

#include <CGAL/IO/read_points.h>

#include <CGAL/Simple_cartesian.h>
#include <CGAL/Min_sphere_of_spheres_d.h>
#include <CGAL/Min_sphere_of_points_d_traits_2.h>
#include <CGAL/Random.h>

#include <CGAL/Exact_predicates_exact_constructions_kernel.h>
#include <CGAL/Polygon_2.h>
#include <CGAL/Polygon_with_holes_2.h>
#include <CGAL/Polygon_set_2.h>

#include <CGAL/Boolean_set_operations_2.h>

#include <CGAL/draw_polygon_set_2.h>
#include <CGAL/draw_polygon_2.h>
#include <CGAL/draw_polygon_with_holes_2.h>

#include <CGAL/Polyhedron_3.h>
#include <CGAL/Nef_polyhedron_3.h>
#include <CGAL/minkowski_sum_2.h>
#include <CGAL/minkowski_sum_3.h>
#include <CGAL/partition_2.h>
#include <CGAL/Partition_traits_2.h>
#include <CGAL/IO/Nef_polyhedron_iostream_3.h>
#include <CGAL/Nef_3/SNC_indexed_items.h>
#include <CGAL/convex_decomposition_3.h>
#include <CGAL/convex_hull_3.h>

#include <CGAL/draw_polyhedron.h>
#include <CGAL/draw_nef_3.h>

#include <CGAL/Epick_d.h>
#include <CGAL/Triangulation.h>

#include "gurobi_c++.h"

#include <draw_res.h>
#include <point_calculation.h>
#include <input_initialize.h>
#include <calculate_2d.h>
#include <calculate_3d.h>
#include <generate_para_2d.h>
#include <generate_para_3d.h>
#include <generate_para_4d.h>
#include <test_draw.h>
#include <try_program.h>
#include <draw_whole_res.h>
#include <scip_program.h>
#include <gurobi_program.h>
#include <simple_cal.h>


#define PI 3.1415926535

#define Epsilon 0.00000001

typedef CGAL::Exact_predicates_exact_constructions_kernel K;
typedef CGAL::Polygon_2<K>                                Polygon_2;
typedef CGAL::Polygon_with_holes_2<K>                     Polygon_with_holes_2;
typedef CGAL::Polygon_set_2<K>                            Polygon_set_2;
typedef CGAL::Point_2<K>                                  Point_2;
typedef CGAL::Vector_2<K>                                 Vector_2;
typedef CGAL::Point_3<K>                                  Point_3;
typedef CGAL::Polyhedron_3<K>							  Polyhedron;
typedef CGAL::Nef_polyhedron_3<K>						  Nef_polyhedron;
//typedef K::Point_2										  Point;
using std::cout;
using std::endl;

typedef CGAL::Simple_cartesian<double>                   c_K;//引自参考min_circle_2的例子
typedef CGAL::Min_sphere_of_points_d_traits_2<c_K, double>   c_Traits;
typedef CGAL::Min_sphere_of_spheres_d<c_Traits>            Min_circle;
typedef CGAL::Point_2<c_K>                                 c_Point_2;
typedef CGAL::Polygon_2<c_K>                                c_Polygon_2;
typedef c_K::Point_3									   input_Point;

typedef CGAL::Partition_traits_2<K>                         Traits;
typedef Traits::Polygon_2                                   p_Polygon_2;
typedef Traits::Point_2                                     p_Point_2;

typedef Polygon_2::Vertex_iterator						  VertexIterator;
typedef Polygon_2::Edge_const_iterator					  EdgeIterator;
typedef p_Polygon_2::Vertex_iterator					  p_VertexIterator;
typedef Nef_polyhedron::Volume_const_iterator			  Volume_const_iterator;
typedef Polyhedron::Vertex_iterator						  phd_VertexIterator;
typedef Polyhedron::Facet_iterator					      phd_FacetIterator;
//typedef Nef_polyhedron::Vertex_iterator					  N_phd_VertexIterator;
typedef Nef_polyhedron::Aff_transformation_3			  Aff_transformation_3;
typedef Polyhedron::Halfedge_around_facet_circulator	  Halfedge_facet_circulator;

typedef CGAL::Epick_d<CGAL::Dynamic_dimension_tag>		  D_dim;
typedef CGAL::Triangulation<D_dim>                        Triangulation;
typedef CGAL::Triangulation_data_structure<D_dim>         TDS;
typedef Triangulation::Point			                  D_dim_point;
typedef Triangulation::Full_cell_handle					  Full_cell_handle;
typedef Triangulation::Facet							  Facet;
typedef Triangulation::Face								  Face;

typedef std::list<Point_2>								  Point_list_2;
typedef std::list<c_Point_2>							  c_Point_list_2;
typedef std::list<p_Polygon_2>                            p_Pgn_list_2;
typedef std::list<Point_3>								  Point_list_3;
typedef std::list<Polygon_with_holes_2>                   Pwh_list_2;
typedef std::list<Polygon_2>							  Pgn_list_2;
typedef std::list<Nef_polyhedron>						  N_phd_list;
typedef std::list<Polyhedron>							  phd_list;
typedef std::vector<Full_cell_handle>					  Full_cells;
typedef std::vector<Face>								  Faces;

bool res_sort_nfp(std::vector<double> a, std::vector<double> b) {
	if (a[0] < b[0] + Epsilon && b[0] < a[0] + Epsilon)
		return a[1] < b[1];//如果目标函数一样，重合面积升序
	else
		return a[0] < b[0];//目标函数升序(小的放前面)
}

bool res_sort_ifp(std::vector<double> a, std::vector<double> b) {
	if (a[4] == b[4])
		return a[0] < b[0];//如果ifp编号一样，目标函数升序
	else
		return a[4] < b[4];//ifp编号升序(小的放前面)
}

//根据数组第一位（下标为0），升序排序（小的放前面）
bool res_sort_0(std::vector<double> a, std::vector<double> b) {
	return a[0] < b[0];//ifp编号升序(小的放前面)
}

int main()
{
	int id_type;
	//id_piece = 0;
	std::cout << "请输入要使用哪一个功能，0为计算nfp数据并记录，1为计算扩大后的bin面积并记录，按回车结束" << std::endl;
	std::cin >> id_type;

	std::ofstream out_num;
	out_num.precision(14);
	std::ofstream out_poi;
	out_poi.precision(14);

	int id_piece;
	//id_piece = 0;
	//std::cout << "请输入要使用哪一个零件（编号1-9），按回车结束" << std::endl;
	//std::cin >> id_piece;

	int id_sheet;
	//id_sheet = 0;
	//std::cout << "请输入要使用哪一块板材（编号1-5），按回车结束" << std::endl;
	//std::cin >> id_sheet;

	std::vector<int> sheet_holes = { 3,2,3,3,6 };

	//std::vector < c_Point_list_2 > vec_c_points_holes = input_polygons(sheet_holes[id_sheet - 1], "D:/Ph.D/Code/Packing/data/packing/Plane with key points/Sheets/sheet " + std::to_string(id_piece) + "h");

	if (id_type == 0) {
		double obj_ang;
		obj_ang = 0;
		//std::cout << "请输入目标函数角度（弧度制），按回车结束" << std::endl;
		//std::cin >> obj_ang;
		double x_para = cos(obj_ang);
		double y_para = sin(obj_ang);
		//std::cout << sin(PI/2) << std::endl;

		int eve_n;
		eve_n = 360;
		//std::cout << "请输入选择几个均分角度进行比较，按回车结束" << std::endl;
		//std::cin >> eve_n;

		for (id_piece = 1; id_piece <= 5; ++id_piece) {

			c_Point_list_2 c_points_piece = input_polygon("D:/Ph.D/Code/Packing/data/packing/Plane with key points/Pieces/piece " + std::to_string(id_piece) + ".xyz");

			FILE* fp;
			std::string kp_str = "D:/Ph.D/Code/Packing/data/packing/Plane with key points/Pieces/key points " + std::to_string(id_piece) + ".txt";
			fp = fopen(kp_str.c_str(), "r");
			std::vector<std::vector<double>> key_points;
			for (int i_case = 0; i_case < 3; ++i_case) {
				std::vector<double> key_point(2);
				for (int i_id = 0; i_id < 2; ++i_id) {
					fscanf(fp, "%lf", &key_point[i_id]);
				}
				key_points.push_back(key_point);
			}

			std::vector<double> cc_piece(2);
			Polygon_2 piece;
			// for (c_Point_list_2::const_iterator it = c_points_piece.begin(); it != c_points_piece.end(); ++it)
			//	piece.push_back(Point_2(it->x(), it->y()));
			// CGAL::draw(piece);
			piece = init_min_c_c(c_points_piece, cc_piece).outer_boundary();
			Polygon_2 key_point_hole;
			for (int i_poi = 0; i_poi < 3; ++i_poi)
				key_point_hole.push_back(Point_2(key_points[i_poi][0] - cc_piece[0], key_points[i_poi][1]
					- cc_piece[1]));

			Polygon_set_2 piece_draw;
			piece_draw.insert(piece);
			piece_draw.difference(key_point_hole);
			//CGAL::draw(piece_draw);

			for (int i_eve_1 = 0; i_eve_1 < eve_n; ++i_eve_1) {
				double ang_r_1 = 2.0 * PI / eve_n * i_eve_1;
				Polygon_2 piece_1 = Polygon_2_turn_acw(piece, ang_r_1);
				for (id_sheet = 1; id_sheet <= 4; ++id_sheet) {
					c_Point_list_2 c_points_sheet = input_polygon("D:/Ph.D/Code/Packing/data/packing/Plane with key points/Sheets/sheet " + std::to_string(id_sheet) + ".xyz");

					std::vector < c_Point_list_2 > vec_c_points_holes;
					for (int i_p_num = 0; i_p_num < sheet_holes[id_sheet - 1]; ++i_p_num) {
						c_Point_list_2 vec_c_points_hole = input_polygon("D:/Ph.D/Code/Packing/data/packing/Plane with key points/Sheets/sheet " + std::to_string(id_sheet) + "h" + std::to_string(i_p_num + 1) + ".xyz");
						vec_c_points_holes.push_back(vec_c_points_hole);
					}

					Polygon_2 sheet;
					for (c_Point_list_2::const_iterator it = c_points_sheet.begin(); it != c_points_sheet.end(); ++it)
						sheet.push_back(Point_2(it->x(), it->y()));

					std::vector<Polygon_2> holes(sheet_holes[id_sheet - 1]);
					for (int i_p_num = 0; i_p_num < sheet_holes[id_sheet - 1]; ++i_p_num) {
						for (c_Point_list_2::const_iterator it = vec_c_points_holes[i_p_num].begin(); it
							!= vec_c_points_holes[i_p_num].end(); ++it)
							holes[i_p_num].push_back(Point_2(it->x(), it->y()));
					}

					Polygon_set_2 sheet_draw;
					sheet_draw.insert(sheet);
					for (int i_p_num = 0; i_p_num < sheet_holes[id_sheet - 1]; ++i_p_num) {
						sheet_draw.difference(holes[i_p_num]);
					}
					//CGAL::draw(sheet_draw);

					Polygon_set_2 feasible;
					feasible.insert(sheet);
					Polygon_2 sheet_kp;
					for (int i_poi = 0; i_poi < 3; ++i_poi) {
						double x_o = cc_piece[0] - key_points[i_poi][0];
						double y_o = cc_piece[1] - key_points[i_poi][1];
						double x_r = x_o * cos(ang_r_1) - y_o * sin(ang_r_1);
						double y_r = x_o * sin(ang_r_1) + y_o * cos(ang_r_1);
						sheet_kp = Polygon_2_trans(sheet, x_r, y_r);
						feasible.intersection(sheet_kp);
					}

					std::list<Polygon_with_holes_2> res;
					std::list<Polygon_with_holes_2>::const_iterator it;
					std::vector<double> best_coord_local;
					feasible.polygons_with_holes(std::back_inserter(res));
					Polygon_2 feasible_sheet = res.begin()->outer_boundary();

					std::string ad_str = "D:/Ph.D/Code/Packing/data/packing/nfp record/p"
						+ std::to_string(id_piece) + "s" + std::to_string(id_sheet) + "_"
						+ std::to_string(i_eve_1) + "feasible_sheet.txt";
					out_poi.open(ad_str.c_str(), std::ios::out | std::ios::app);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
					VertexIterator vi = feasible_sheet.vertices_begin();
					double vi_x_p = to_double(vi->x().approx());
					double vi_y_p = to_double(vi->y().approx());
					double vi_x_first = vi_x_p;
					double vi_y_first = vi_y_p;
					for (; vi != feasible_sheet.vertices_end(); ++vi) {
						double vi_x = to_double(vi->x().approx());
						double vi_y = to_double(vi->y().approx());
						if (!equal_double(vi_x, vi_x_p, 0.001) || !equal_double(vi_y, vi_y_p, 0.001)) {
							out_poi << vi_x_p << " " << vi_y_p << "\n";
							vi_x_p = vi_x;
							vi_y_p = vi_y;
						}
					}
					if (!equal_double(vi_x_first, vi_x_p, 0.001) || !equal_double(vi_y_first, vi_y_p, 0.001)) {
						out_poi << vi_x_p << " " << vi_y_p << "\n";
					}
					out_poi.close();

					for (int i_hole = 0; i_hole < holes.size(); ++i_hole) {
						Polygon_2 mink_res_2d = CGAL::minkowski_sum_2(holes[i_hole],
							Polygon_2_turn_acw(piece_1, PI)).outer_boundary();

						std::string ad_str = "D:/Ph.D/Code/Packing/data/packing/nfp record/p"
							+ std::to_string(id_piece) + "s" + std::to_string(id_sheet) + "h"
							+ std::to_string(i_hole) + "_" + std::to_string(i_eve_1) + "hole_nfp.txt";
						out_poi.open(ad_str.c_str(), std::ios::out | std::ios::app);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
						VertexIterator vi = mink_res_2d.vertices_begin();
						double vi_x_p = to_double(vi->x().approx());
						double vi_y_p = to_double(vi->y().approx());
						double vi_x_first = vi_x_p;
						double vi_y_first = vi_y_p;
						for (; vi != mink_res_2d.vertices_end(); ++vi) {
							double vi_x = to_double(vi->x().approx());
							double vi_y = to_double(vi->y().approx());
							if (!equal_double(vi_x, vi_x_p, 0.001) || !equal_double(vi_y, vi_y_p, 0.001)) {
								out_poi << vi_x_p << " " << vi_y_p << "\n";
								vi_x_p = vi_x;
								vi_y_p = vi_y;
							}
						}
						if (!equal_double(vi_x_first, vi_x_p, 0.001) || !equal_double(vi_y_first, vi_y_p, 0.001)) {
							out_poi << vi_x_p << " " << vi_y_p << "\n";
						}
						out_poi.close();
					}
				}
				for (int i_eve_2 = 0; i_eve_2 < eve_n; ++i_eve_2) {
					double ang_r_2 = 2.0 * PI / eve_n * i_eve_2;
					Polygon_2 piece_2 = Polygon_2_turn_acw(piece, ang_r_2);

					Polygon_2 mink_res_2d = CGAL::minkowski_sum_2(piece_2,
						Polygon_2_turn_acw(piece_1, PI)).outer_boundary();

					std::string ad_str = "D:/Ph.D/Code/Packing/data/packing/nfp record/p"
						+ std::to_string(id_piece) + "_" + std::to_string(i_eve_1) + "_"
						+ std::to_string(i_eve_2) + "piece_nfp.txt";
					out_poi.open(ad_str.c_str(), std::ios::out | std::ios::app);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
					VertexIterator vi = mink_res_2d.vertices_begin();
					double vi_x_p = to_double(vi->x().approx());
					double vi_y_p = to_double(vi->y().approx());
					double vi_x_first = vi_x_p;
					double vi_y_first = vi_y_p;
					for (; vi != mink_res_2d.vertices_end(); ++vi) {
						double vi_x = to_double(vi->x().approx());
						double vi_y = to_double(vi->y().approx());
						if (!equal_double(vi_x, vi_x_p, 0.001) || !equal_double(vi_y, vi_y_p, 0.001)) {
							out_poi << vi_x_p << " " << vi_y_p << "\n";
							vi_x_p = vi_x;
							vi_y_p = vi_y;
						}
					}
					if (!equal_double(vi_x_first, vi_x_p, 0.001) || !equal_double(vi_y_first, vi_y_p, 0.001)) {
						out_poi << vi_x_p << " " << vi_y_p << "\n";
					}
					out_poi.close();
				}
			}
		}
	}

	if (id_type == 1) {
		double radius_lb = 1, radius_ub = 1000, eps = 0.0000000001;
		int edges = 360;

		std::string ad_str = "D:/Ph.D/Code/Packing/data/packing/enlarged area.txt";
		out_num.open(ad_str.c_str(), std::ios::out | std::ios::app);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。

		for (id_piece = 1; id_piece <= 9; ++id_piece) {
			c_Point_list_2 c_points_piece = input_polygon("D:/Ph.D/Code/Packing/data/packing/Plane with key points/Pieces/piece " + std::to_string(id_piece) + ".xyz");

			FILE* fp;
			std::string kp_str = "D:/Ph.D/Code/Packing/data/packing/Plane with key points/Pieces/key points " + std::to_string(id_piece) + ".txt";
			fp = fopen(kp_str.c_str(), "r");
			std::vector<std::vector<double>> key_points;
			for (int i_case = 0; i_case < 3; ++i_case) {
				std::vector<double> key_point(2);
				for (int i_id = 0; i_id < 2; ++i_id) {
					fscanf(fp, "%lf", &key_point[i_id]);
				}
				key_points.push_back(key_point);
			}

			std::vector<double> cc_piece(2);
			Polygon_2 piece;
			// for (c_Point_list_2::const_iterator it = c_points_piece.begin(); it != c_points_piece.end(); ++it)
			//	piece.push_back(Point_2(it->x(), it->y()));
			// CGAL::draw(piece);
			piece = init_min_c_c(c_points_piece, cc_piece).outer_boundary();

			double piece_area = to_double(piece.area().approx());
			double r_s = max_cir_support_point(edges, radius_lb, radius_ub, eps, piece, cc_piece, key_points);
			Polygon_2 pgn_cir = Polygon_2_from_circle(edges, 0, 0, r_s);

			for (id_sheet = 1; id_sheet <= 5; ++id_sheet) {
				c_Point_list_2 c_points_sheet = input_polygon("D:/Ph.D/Code/Packing/data/packing/Plane with key points/Sheets/sheet " + std::to_string(id_sheet) + ".xyz");
				std::vector < c_Point_list_2 > vec_c_points_holes;
				for (int i_p_num = 0; i_p_num < sheet_holes[id_sheet - 1]; ++i_p_num) {
					c_Point_list_2 vec_c_points_hole = input_polygon("D:/Ph.D/Code/Packing/data/packing/Plane with key points/Sheets/sheet " + std::to_string(id_sheet) + "h" + std::to_string(i_p_num + 1) + ".xyz");
					vec_c_points_holes.push_back(vec_c_points_hole);
				}
				Polygon_2 sheet;
				for (c_Point_list_2::const_iterator it = c_points_sheet.begin(); it != c_points_sheet.end(); ++it)
					sheet.push_back(Point_2(it->x(), it->y()));
				double sheet_area = to_double(sheet.area().approx());

				std::vector<Polygon_2> holes(sheet_holes[id_sheet - 1]);
				for (int i_p_num = 0; i_p_num < sheet_holes[id_sheet - 1]; ++i_p_num) {
					for (c_Point_list_2::const_iterator it = vec_c_points_holes[i_p_num].begin(); it
						!= vec_c_points_holes[i_p_num].end(); ++it)
						holes[i_p_num].push_back(Point_2(it->x(), it->y()));
				}
				double defect_area = 0;
				for (int i_p_num = 0; i_p_num < sheet_holes[id_sheet - 1]; ++i_p_num) {
					defect_area += to_double(holes[i_p_num].area().approx());
				}

				Polygon_with_holes_2 mink_res_2d = CGAL::minkowski_sum_2(pgn_cir, sheet);

				double sheet_enlarge_hole_area = 0;
				for (auto it_h = mink_res_2d.holes_begin(); it_h != mink_res_2d.holes_end(); ++it_h) {
					sheet_enlarge_hole_area += to_double(it_h->area().approx());
				}
				double sheet_enlarge_area = to_double(mink_res_2d.outer_boundary().area().approx()) 
					- sheet_enlarge_hole_area;

				double max_num = (sheet_enlarge_area - defect_area) / piece_area;

				out_num << id_piece << " " << id_sheet << " " << r_s << " " << piece_area << " " 
					<< sheet_area << " " << sheet_enlarge_area << " " << defect_area << " "
					<< max_num << "\n";
			}
		}
		out_num.close();
	}

	return 0;
}

/*
\n 换行符(LF)

\r 回车(CR) ，相当于键盘上的"Enter"

\t 跳到下一个TAB位置

\0 空字符(NULL)

\' 单引号（撇号）

\" 双引号

\\ 代表一个反斜线字符''\'

\ 继续符，可用于一行的结尾，表示本行与下一行连接起来
*/