﻿//一个个测试nfp
//debug用
#include <list>
#include <iostream>
#include <fstream>
#include <cassert>

#include <thread>

#include <ilcplex\ilocplex.h>
ILOSTLBEGIN // 等同于 using namespace std; 声明命名空间

#include <Eigen/Dense>

#include <CGAL/IO/read_points.h>

#include <CGAL/Simple_cartesian.h>
#include <CGAL/Min_sphere_of_spheres_d.h>
#include <CGAL/Min_sphere_of_points_d_traits_2.h>
#include <CGAL/Random.h>

#include <CGAL/Exact_predicates_exact_constructions_kernel.h>
#include <CGAL/Polygon_2.h>
#include <CGAL/Polygon_with_holes_2.h>
#include <CGAL/Polygon_set_2.h>

#include <CGAL/Boolean_set_operations_2.h>

#include <CGAL/draw_polygon_set_2.h>
#include <CGAL/draw_polygon_2.h>
#include <CGAL/draw_polygon_with_holes_2.h>

#include <CGAL/Polyhedron_3.h>
#include <CGAL/Nef_polyhedron_3.h>
#include <CGAL/minkowski_sum_2.h>
#include <CGAL/minkowski_sum_3.h>
#include <CGAL/partition_2.h>
#include <CGAL/Partition_traits_2.h>
#include <CGAL/IO/Nef_polyhedron_iostream_3.h>
#include <CGAL/Nef_3/SNC_indexed_items.h>
#include <CGAL/convex_decomposition_3.h>
#include <CGAL/convex_hull_3.h>

#include <CGAL/draw_polyhedron.h>
#include <CGAL/draw_nef_3.h>

#include <CGAL/Epick_d.h>
#include <CGAL/Triangulation.h>

#include "gurobi_c++.h"

#include <draw_res.h>
#include <point_calculation.h>
#include <input_initialize.h>
#include <calculate_2d.h>
#include <calculate_3d.h>
#include <generate_para_2d.h>
#include <generate_para_3d.h>
#include <generate_para_4d.h>
#include <test_draw.h>
#include <try_program.h>
#include <draw_whole_res.h>
#include <scip_program.h>
#include <gurobi_program.h>


#define PI 3.1415926535

#define Epsilon 0.00000001

typedef CGAL::Exact_predicates_exact_constructions_kernel K;
typedef CGAL::Polygon_2<K>                                Polygon_2;
typedef CGAL::Polygon_with_holes_2<K>                     Polygon_with_holes_2;
typedef CGAL::Polygon_set_2<K>                            Polygon_set_2;
typedef CGAL::Point_2<K>                                  Point_2;
typedef CGAL::Vector_2<K>                                 Vector_2;
typedef CGAL::Point_3<K>                                  Point_3;
typedef CGAL::Polyhedron_3<K>							  Polyhedron;
typedef CGAL::Nef_polyhedron_3<K>						  Nef_polyhedron;
//typedef K::Point_2										  Point;
using std::cout;
using std::endl;

typedef CGAL::Simple_cartesian<double>                   c_K;//引自参考min_circle_2的例子
typedef CGAL::Min_sphere_of_points_d_traits_2<c_K, double>   c_Traits;
typedef CGAL::Min_sphere_of_spheres_d<c_Traits>            Min_circle;
typedef CGAL::Point_2<c_K>                                 c_Point_2;
typedef CGAL::Polygon_2<c_K>                                c_Polygon_2;
typedef c_K::Point_3									   input_Point;

typedef CGAL::Partition_traits_2<K>                         Traits;
typedef Traits::Polygon_2                                   p_Polygon_2;
typedef Traits::Point_2                                     p_Point_2;

typedef Polygon_2::Vertex_iterator						  VertexIterator;
typedef Polygon_2::Edge_const_iterator					  EdgeIterator;
typedef p_Polygon_2::Vertex_iterator					  p_VertexIterator;
typedef Nef_polyhedron::Volume_const_iterator			  Volume_const_iterator;
typedef Polyhedron::Vertex_iterator						  phd_VertexIterator;
typedef Polyhedron::Facet_iterator					      phd_FacetIterator;
//typedef Nef_polyhedron::Vertex_iterator					  N_phd_VertexIterator;
typedef Nef_polyhedron::Aff_transformation_3			  Aff_transformation_3;
typedef Polyhedron::Halfedge_around_facet_circulator	  Halfedge_facet_circulator;

typedef CGAL::Epick_d<CGAL::Dynamic_dimension_tag>		  D_dim;
typedef CGAL::Triangulation<D_dim>                        Triangulation;
typedef CGAL::Triangulation_data_structure<D_dim>         TDS;
typedef Triangulation::Point			                  D_dim_point;
typedef Triangulation::Full_cell_handle					  Full_cell_handle;
typedef Triangulation::Facet							  Facet;
typedef Triangulation::Face								  Face;

typedef std::list<Point_2>								  Point_list_2;
typedef std::list<c_Point_2>							  c_Point_list_2;
typedef std::list<p_Polygon_2>                            p_Pgn_list_2;
typedef std::list<Point_3>								  Point_list_3;
typedef std::list<Polygon_with_holes_2>                   Pwh_list_2;
typedef std::list<Polygon_2>							  Pgn_list_2;
typedef std::list<Nef_polyhedron>						  N_phd_list;
typedef std::list<Polyhedron>							  phd_list;
typedef std::vector<Full_cell_handle>					  Full_cells;
typedef std::vector<Face>								  Faces;

bool res_sort_nfp(std::vector<double> a, std::vector<double> b) {
	if (a[0] < b[0] + Epsilon && b[0] < a[0] + Epsilon)
		return a[1] < b[1];//如果目标函数一样，重合面积升序
	else
		return a[0] < b[0];//目标函数升序(小的放前面)
}

bool res_sort_ifp(std::vector<double> a, std::vector<double> b) {
	if (a[4] == b[4])
		return a[0] < b[0];//如果ifp编号一样，目标函数升序
	else
		return a[4] < b[4];//ifp编号升序(小的放前面)
}

//根据数组第一位（下标为0），升序排序（小的放前面）
bool res_sort_0(std::vector<double> a, std::vector<double> b) {
	return a[0] < b[0];//ifp编号升序(小的放前面)
}

int main()
{
	std::cout.precision(14);
	std::ofstream out_4d;
	out_4d.precision(14);
	out_4d.open("D:/Ph.D/Code/Packing/data/packing/record.txt", std::ios::out);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
	out_4d.close();
	std::ofstream out_test;
	out_test.precision(14);
	out_test.open("D:/Ph.D/Code/Packing/data/packing/run_testtest.txt", std::ios::out);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
	out_test.close();
	std::ofstream out_coord;
	out_coord.precision(14);
	out_coord.open("D:/Ph.D/Code/Packing/data/packing/coord_testtest.txt", std::ios::out);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
	out_coord.close();

	int polygon_num;
	polygon_num = 60;
	//std::cout << "请输入多边形数量，按回车结束" << std::endl;
	//std::cin >> polygon_num;
	std::vector < c_Point_list_2 > vec_c_points = input_polygons(polygon_num, "D:/Ph.D/Code/Packing/data/packing/poly/polygon_");

	double width;
	width = 40;
	//std::cout << "请输入箱子宽度，按回车结束" << std::endl;
	//std::cin >> width;
	double length;
	length = 40;
	//std::cout << "请输入箱子长度，按回车结束" << std::endl;
	//std::cin >> length;

	double alpha_obj;
	alpha_obj = 0.001;
	//std::cout << "请输入目标函数x+αy中的系数α，按回车结束" << std::endl;
	//std::cin >> alpha_obj;

	double beta_obj;
	beta_obj = 0.00001;
	//std::cout << "请输入目标函数中零件坐标x+y的系数β，按回车结束" << std::endl;
	//std::cin >> beta_obj;

	double ang_step_size;
	ang_step_size = 30;
	//std::cout << "请输入角度步长，按回车结束" << std::endl;
	//std::cin >> ang_step_size;

	int eve_n;
	eve_n = 8;
	//std::cout << "请输入选择几个均分角度进行比较，按回车结束" << std::endl;
	//std::cin >> eve_n;

	int try_n;
	try_n = 3;
	//std::cout << "请输入选择前几个竞争力角度进行比较，按回车结束" << std::endl;
	//std::cin >> try_n;

	std::vector<double> polygons_symm(polygon_num, 1);
	//要改！

	//非线性规划情况下，D-function，大概是最大的图形的最长的一条线的长度*sqrt(2)*length
	double big_m_nonlin = 2 * max(length, width) * max(length, width);

	double time_lim = 1200;

	std::vector<Polygon_with_holes_2> pwhs(polygon_num);
	std::vector<Polygon_2> pgns(polygon_num);
	std::vector<Polygon_2> pgns_trans(polygon_num);
	std::vector<Polygon_2> pgns_inset(polygon_num);
	//std::vector<std::list<Nef_polyhedron>> N_pgn_par_lists;
	std::vector<std::vector<double>> pgns_bbox;//每个图形都有一个四维变量，保存着minx，miny，maxx，maxy

	for (int i_p_num = 0; i_p_num < polygon_num; ++i_p_num) {
		std::vector<double> pgn_bbox;
		//调整图形位置，后续需要
		pwhs[i_p_num] = init_min_c(vec_c_points[i_p_num], pgn_bbox);
		//对图形不进行旋转
		pgns[i_p_num] = pwhs[i_p_num].outer_boundary();
		pgns_inset[i_p_num] = Polygon_2_inset(pgns[i_p_num], 0.0000001);
		//CGAL::draw(pwhs[i_p_num]);
		pgn_bbox = bbox_cal(pgns[i_p_num]);
		pgns_bbox.push_back(pgn_bbox);
		//std::list<Nef_polyhedron> N_pgn_par_list;
		//decomp_2(pgns[i_p_num], N_pgn_par_list);
		//N_pgn_par_lists.push_back(N_pgn_par_list);
	}

	std::vector<double> angles_o;//origin（用来对比的）
	angles_o.push_back(0);
	angles_o.push_back(PI / 2);
	angles_o.push_back(PI);
	angles_o.push_back(3 * PI / 2);

	//bin只包含箱子的形状
	std::vector<Polygon_with_holes_2> bin_pwh_vec;
	//Pwh_list_2                  ifp_pwh_list;
	std::vector<Polygon_with_holes_2>::const_iterator  it;


	Point_list_2 poi_box = { Point_2(0, 0), Point_2(10, 0), Point_2(0, 10),
			Point_2(10, 20), Point_2(0, 20), Point_2(10, 10) };
	Polygon_2 ifp_box(poi_box.begin(), poi_box.end());

	//CGAL::draw(ifp_box);

	std::cout << ifp_box.is_simple() << std::endl;
	std::cout << pgns[0].is_simple() << std::endl;

	std::vector<std::list<Nef_polyhedron>> N_pgn_par_lists;

	//std::list<Nef_polyhedron> N_pgn_par_list;
	//decomp_2(pgns[i_p_num], N_pgn_par_list);
	//N_pgn_par_lists.push_back(N_pgn_par_list);

	std::vector<std::vector<double>> coord_all;

	int i_p_num = 27;

	FILE* fp;
	fp = fopen("D:/Ph.D/Code/Packing/data/packing/coord_test.txt", "r");
	for (int i_read = 0; i_read < i_p_num; ++i_read) {
		std::vector<double> coord_0(2);
		fscanf(fp, "%lf", &coord_0[0]);
		fscanf(fp, "%lf", &coord_0[1]);
		coord_all.push_back(coord_0);
		double ra_turn_0;
		fscanf(fp, "%lf", &ra_turn_0);
		pgns[i_read] = Polygon_2_turn_acw(pgns[i_read], ra_turn_0);
		pgns_inset[i_read] = Polygon_2_turn_acw(pgns_inset[i_read], ra_turn_0);
		pgns_bbox[i_read] = bbox_cal(pgns[i_read]);
		pgns_trans[i_read] = Polygon_2_trans(pgns[i_read], coord_0[0], coord_0[1]);
		std::list<Nef_polyhedron> N_pgn_par_list;
		decomp_2(pgns_trans[i_read], N_pgn_par_list);
		N_pgn_par_lists.push_back(N_pgn_par_list);
	}
	std::vector<double> obj_test = { 0,0,0 };
	draw_whole_res(i_p_num - 1, length, width, pgns, 0, obj_test, coord_all);

	double min_ang = min_angle(pgns[i_p_num]);
	//std::cout << min_ang << std::endl;
	if (min_ang > 30) {
		ang_step_size = 30;
	}
	else {
		if (min_ang > 22.5) {
			ang_step_size = 22.5;
		}
		else {
			if (min_ang > 18) {
				ang_step_size = 18;
			}
			else {
				if (min_ang > 15) {
					ang_step_size = 15;
				}
				else {
					std::cout << "min_angle < 15" << std::endl;
				}
			}
		}
	}

	std::vector<std::vector<double>> res_fin;

	DWORD t_nfp1 = GetTickCount64();
	//obj, ra_turn, lowerbound, upperbound, x_coord, y_coord, time, intersection, iteration
	std::vector<double> res_nfp(9);
	{
		std::vector<double> polygon_angles;
		init_angles(polygon_angles, ang_step_size, polygons_symm[i_p_num]);
		std::vector<std::vector<double>> best_results(polygon_angles.size() - 1);
		std::vector<std::thread> t_ang(polygon_angles.size() - 1);
		for (int i_p_a = 0; i_p_a < polygon_angles.size() - 1; ++i_p_a) {
			//t_ang[i_p_a] = std::thread([polygon_num, length, width, alpha_obj, i_p_num, i_p_a,
			//	polygon_angles, pwhs, pgns, N_pgn_par_lists, coord_all, &best_results] {
					std::vector<std::vector<std::vector<std::vector<double>>>> polygons_paras_nfps_nfp;
					std::vector<double> obj_nfp;
					std::vector<double> coord_nfp;
					double ra_turn_nfp;
					double intersection;

					try_program_nfp_one_by_one_single_ang(length, width, alpha_obj, i_p_num,
						polygon_angles[i_p_a], polygon_angles[i_p_a + 1], pwhs, pgns, N_pgn_par_lists,
						coord_all, obj_nfp, coord_nfp, ra_turn_nfp, intersection);

					//std::vector<std::vector<double>> coord_all_temp = coord_all;
					//coord_all_temp.push_back(coord_nfp);
					//draw_whole_res(i_p_num, length, width, pgns, ra_turn_nfp, obj_nfp, coord_all_temp);

					best_results[i_p_a] = { obj_nfp[2], intersection, ra_turn_nfp,
						polygon_angles[i_p_a], polygon_angles[i_p_a + 1] };
			//	});
		}
		//for (int i_p_a = 0; i_p_a < polygon_angles.size() - 1; ++i_p_a) {
		//	t_ang[i_p_a].join();
		//}
		sort(best_results.begin(), best_results.end(), res_sort_nfp);

		std::vector<std::vector<std::vector<std::vector<double>>>> polygons_paras_nfps;
		std::vector<double> obj_ub;
		std::vector<double> coord_ub;
		double ra_turn_ub = best_results[0][2];

		try_program_one_by_one_no_turn(length, width, alpha_obj, i_p_num, pgns_inset, ra_turn_ub,
			coord_all, obj_ub, coord_ub);

		//std::vector<std::vector<double>> coord_all_temp = coord_all;
		//coord_all_temp.push_back(coord_ub);
		//draw_whole_res(i_p_num, length, width, pgns, best_results[0][2], obj_ub, coord_all_temp);
		out_4d.open("D:/Ph.D/Code/Packing/data/packing/record.txt", std::ios::out | std::ios::app);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
		out_4d << best_results[0][0] << " " << best_results[0][1] << " " << best_results[0][2] / PI * 180 <<
			" " << best_results[0][2] << " " << best_results[0][3] << " " << best_results[0][4] << " " <<
			obj_ub[2] << "\n";
		out_4d.close();
		std::cout << "Intersection area = " << best_results[0][1] << std::endl;
		std::cout << "Obj difference = " << obj_ub[2] - best_results[0][0] << std::endl;

		//draw_whole_res(i_p_num, length, width, pgns, best_results[0][2], obj, coord);

		int it_num = 0;

		while (obj_ub[2] - best_results[0][0] > 0.001) {
			best_results.push_back({});
			best_results.push_back({});
			if (best_results[0][3] + 1 < best_results[0][2] / PI * 180 &&
				best_results[0][2] / PI * 180 + 1 < best_results[0][4])
			{
						std::vector<std::vector<std::vector<std::vector<double>>>> polygons_paras_nfps_nfp_1;
						std::vector<double> obj_nfp_1;
						std::vector<double> coord_nfp_1;
						double ra_turn_nfp_1;
						double intersection_1;

						try_program_nfp_one_by_one_single_ang(length, width, alpha_obj, i_p_num,
							best_results[0][3], best_results[0][2] / PI * 180, pwhs, pgns, N_pgn_par_lists,
							coord_all, obj_nfp_1, coord_nfp_1, ra_turn_nfp_1, intersection_1);

						best_results[best_results.size() - 2] = { obj_nfp_1[2], intersection_1, ra_turn_nfp_1,
							best_results[0][3], best_results[0][2] / PI * 180 };
						std::vector<std::vector<std::vector<std::vector<double>>>> polygons_paras_nfps_nfp_2;
						std::vector<double> obj_nfp_2;
						std::vector<double> coord_nfp_2;
						double ra_turn_nfp_2;
						double intersection_2;

						try_program_nfp_one_by_one_single_ang(length, width, alpha_obj, i_p_num,
							best_results[0][2] / PI * 180, best_results[0][4], pwhs, pgns, N_pgn_par_lists,
							coord_all, obj_nfp_2, coord_nfp_2, ra_turn_nfp_2, intersection_2);

						best_results[best_results.size() - 1] = { obj_nfp_2[2], intersection_2, ra_turn_nfp_2,
							best_results[0][2] / PI * 180, best_results[0][4] };
			}
			else {
						std::vector<std::vector<std::vector<std::vector<double>>>> polygons_paras_nfps_nfp_1;
						std::vector<double> obj_nfp_1;
						std::vector<double> coord_nfp_1;
						double ra_turn_nfp_1;
						double intersection_1;

						try_program_nfp_one_by_one_single_ang(length, width, alpha_obj, i_p_num,
							best_results[0][3], (best_results[0][3] + best_results[0][4]) / 2,
							pwhs, pgns, N_pgn_par_lists, coord_all, obj_nfp_1, coord_nfp_1, ra_turn_nfp_1,
							intersection_1);

						best_results[best_results.size() - 2] = { obj_nfp_1[2], intersection_1, ra_turn_nfp_1,
							best_results[0][3], (best_results[0][3] + best_results[0][4]) / 2 };
						std::vector<std::vector<std::vector<std::vector<double>>>> polygons_paras_nfps_nfp_2;
						std::vector<double> obj_nfp_2;
						std::vector<double> coord_nfp_2;
						double ra_turn_nfp_2;
						double intersection_2;

						try_program_nfp_one_by_one_single_ang(length, width, alpha_obj, i_p_num,
							(best_results[0][3] + best_results[0][4]) / 2, best_results[0][4], 
							pwhs, pgns, N_pgn_par_lists, coord_all, obj_nfp_2, coord_nfp_2, ra_turn_nfp_2, 
							intersection_2);
						//要大改

						best_results[best_results.size() - 1] = { obj_nfp_2[2], intersection_2, ra_turn_nfp_2,
							(best_results[0][3] + best_results[0][4]) / 2, best_results[0][4] };
			}

			best_results.erase(best_results.begin());

			sort(best_results.begin(), best_results.end(), res_sort_nfp);

			polygons_paras_nfps.clear();
			std::vector<double> obj_new;
			std::vector<double> coord_new;

			try_program_one_by_one_no_turn(length, width, alpha_obj, i_p_num, pgns_inset,
				best_results[0][2], coord_all, obj_new, coord_new);

			//std::vector<std::vector<double>> coord_all_temp = coord_all;
			//coord_all_temp.push_back(coord_new);
			//draw_whole_res(i_p_num, length, width, pgns, best_results[0][2], obj_new, coord_all_temp);

			if (obj_new[2] < obj_ub[2]) {
				ra_turn_ub = best_results[0][2];
				obj_ub = obj_new;
				coord_ub = coord_new;
			}
			//out_4d << "Intersection area = " << best_results[0][1] << "\n";
			//out_4d << "Obj low = " << best_results[0][0] << "\n";
			//out_4d << "Obj high = " << obj[2] << "\n";
			out_4d.open("D:/Ph.D/Code/Packing/data/packing/record.txt", std::ios::out | std::ios::app);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
			out_4d << best_results[0][0] << " " << best_results[0][1] << " " << best_results[0][2] / PI * 180 <<
				" " << best_results[0][2] << " " << best_results[0][3] << " " << best_results[0][4] << " " <<
				obj_ub[2] << "\n";
			out_4d.close();
			std::cout << "Intersection area = " << best_results[0][1] << std::endl;
			std::cout << "Obj difference = " << obj_ub[2] - best_results[0][0] << std::endl;
			std::cout << "Iteration time = " << it_num << std::endl;
			if (it_num == 19)
				std::cout << "Iteration time = " << it_num << std::endl;
			it_num++;
		}
		std::cout << "Iteration time = " << it_num << std::endl;
		//draw_whole_res(i_p_num, length, width, pgns, ra_turn_ub, obj_ub, coord_ub);
		res_nfp[0] = obj_ub[2];
		res_nfp[1] = ra_turn_ub;
		res_nfp[2] = best_results[0][0];
		res_nfp[3] = obj_ub[2];
		res_nfp[4] = coord_ub[0];
		res_nfp[5] = coord_ub[1];
		res_nfp[7] = best_results[0][1];
		res_nfp[8] = it_num;
	}
	DWORD t_nfp2 = GetTickCount64();
	res_nfp[6] = (t_nfp2 - t_nfp1) * 1.0 / 1000;
	res_fin.push_back(res_nfp);
	out_test.open("D:/Ph.D/Code/Packing/data/packing/run_testtest.txt", std::ios::out | std::ios::app);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
	for (int i = 0; i < res_fin.size(); ++i) {
		for (int j = 0; j < res_fin[i].size(); ++j) {
			out_test << res_fin[i][j] << " ";
		}
		out_test << "\n";
	}

	sort(res_fin.begin(), res_fin.end(), res_sort_ifp);

	std::vector<double> obj_fin = { 0,0,res_fin[0][0] };
	std::vector<double> coord_fin = { res_fin[0][4], res_fin[0][5] };

	coord_all.push_back({ coord_fin[0], coord_fin[1] });

	out_test << res_fin[0][1] << "\n";
	out_test.close();

	out_coord.open("D:/Ph.D/Code/Packing/data/packing/coord_testtest.txt", std::ios::out | std::ios::app);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
	out_coord << coord_fin[0] << " " << coord_fin[1] << " " << res_fin[0][1] << "\n";
	out_coord.close();

	for (int i_output_co = 0; i_output_co < coord_all.size(); ++i_output_co) {
		std::cout << coord_all[i_output_co][0] << " " << coord_all[i_output_co][1] << std::endl;
	}
	draw_whole_res(i_p_num, length, width, pgns, res_fin[0][1], obj_fin, coord_all);

	return 0;
}

/*
\n 换行符(LF)

\r 回车(CR) ，相当于键盘上的"Enter"

\t 跳到下一个TAB位置

\0 空字符(NULL)

\' 单引号（撇号）

\" 双引号

\\ 代表一个反斜线字符''\'

\ 继续符，可用于一行的结尾，表示本行与下一行连接起来
*/