﻿// test 用

#include <CGAL/Exact_predicates_exact_constructions_kernel.h>
#include <CGAL/Polyhedron_3.h>
#include <CGAL/Surface_mesh.h>
#include <CGAL/Nef_polyhedron_3.h>
#include <CGAL/boost/graph/convert_nef_polyhedron_to_polygon_mesh.h>

#include <CGAL/IO/Nef_polyhedron_iostream_3.h>

#include <iostream>
#include <sstream>
#include <fstream>
#include <string>  // 用于字符串操作
#include <stdlib.h>
#include <time.h>

#include <list>
#include <CGAL/draw_polygon_set_2.h>
#include <CGAL/draw_polygon_2.h>
#include <CGAL/draw_polygon_with_holes_2.h>
#include <CGAL/draw_polyhedron.h>
#include <CGAL/draw_nef_3.h>
#include <CGAL/connect_holes.h>
#include <calculate_3d.h>

#include <CGAL/Simple_cartesian.h>
#include <CGAL/Min_sphere_of_spheres_d.h>
#include <CGAL/Min_sphere_of_points_d_traits_2.h>
#include <CGAL/minkowski_sum_2.h>

#include <calculate_2d.h>
#include <facets_cal.h>
#include <simple_cal.h>
#include <input_initialize.h>

typedef CGAL::Exact_predicates_exact_constructions_kernel Exact_kernel;
typedef CGAL::Polyhedron_3<Exact_kernel> Polyhedron;
typedef CGAL::Surface_mesh<Exact_kernel::Point_3> Surface_mesh;
typedef CGAL::Nef_polyhedron_3<Exact_kernel> Nef_polyhedron;
typedef CGAL::Polygon_2<K>                                Polygon_2;
typedef CGAL::Polygon_with_holes_2<K>                     Polygon_with_holes_2;
typedef CGAL::Polygon_set_2<K>                            Polygon_set_2;
typedef CGAL::Point_2<K>                                  Point_2;
typedef K::Plane_3  Plane_3;

typedef CGAL::Simple_cartesian<double>                   c_K;//引自参考min_circle_2的例子
typedef CGAL::Min_sphere_of_points_d_traits_2<c_K, double>   c_Traits;
typedef CGAL::Min_sphere_of_spheres_d<c_Traits>            Min_circle;
typedef CGAL::Point_2<c_K>                                 c_Point_2;
typedef std::list<c_Point_2>							  c_Point_list_2;

#define PI 3.1415926535

void fill_cube_1(Polyhedron& poly)
{
	std::string input =
		"OFF\n\
8 11 0\n\
-10 -10 1\n\
-10 10 1\n\
10 10 1\n\
10 -10 1\n\
-10 -10 10\n\
-10 10 10\n\
10 10 10\n\
10 -10 10\n\
3  0 1 3\n\
3  3 1 2\n\
4  1 0 4 5\n\
3  3 2 7\n\
3  7 2 6\n\
3  4 0 3\n\
3  7 4 3\n\
3  6 4 7\n\
3  6 5 4\n\
3  1 5 6\n\
3  2 1 6";

	std::stringstream ss;
	ss << input;
	ss >> poly;
}

void fill_cube_2(Polyhedron& poly, int f_num)
{
	std::string input =
		" 0\n\
		-5 6.5 3\n\
-9 2.5 3\n\
1 4.5 3\n\
-1 7.5 3\n\
-1.5 -4 3\n\
-2 -4.5 3\n\
8 -2.5 3\n\
6 0.5 3\n\
2 -0.5 3\n\
0.2 -2.3 3\n\
-1 -0.5 3\n\
-5 -1.5 3\n\
-9.0000000000002 -5.5 3\n\
-5.2646642146622 -0.20665146929019 2.4509618325137\n\
-9.2646642146624 -4.2066514692902 2.4509618325137\n\
-1.2646642146622 0.79334853070981 2.4509618325137\n\
-10.714102 -2.897114 1.1453540630344e-15\n\
-3.5947915311229 -4.2066514692902 2.4509618325137\n\
-10.559153068505 -3.0371071985155 0.2620146383128\n\
-9.8808618016035 -1.1954463287349 1.1726779724096\n\
-10.446151999982 1.566987 0\n\
4.4052084688771 0.79334853070981 2.4509618325137\n\
1.3759511399954 -0.38521144450485 2.7851589779401\n\
-5.6339094387746 0.12695405777905 1.826577702134\n\
-5.3793256226984 0.17454680188065 1.8501113329635\n\
-1.5863550733156 1.0839896587363 1.9069909050246\n\
-7.2542266137572 -3.533529068168 1.1911297525239\n\
-9.9530279054164 -3.0371071985155 0.26201463831278\n\
-3.6827501664471 -2.2288009696371 0.66170540518531\n\
-9.5218589704016 0.40758846553515 1.9653456314651\n\
-10.757455845615 -0.15688822849726 1.6862235430055\n\
-9.0452077001703 -3.566987 -2.7804223470392e-14\n\
-2.1878220000001 -3.566987 1.8999552704768e-14\n\
-4.151924 -5.531089 0\n\
-6.446152 5.566987 -1.6904554637017e-15\n\
-2.714102 8.031089 -2.9557981749099e-15\n\
1.285898 9.031089 -3.9083526352924e-15\n\
8.446152 1.433013 -3.3043130878017e-15\n\
10.446152 -1.566987 -2.9197058141205e-15\n\
5.233672 -2.609483 -1.7425179494032e-15\n\
5.848076 -3.531089 -1.6243658257138e-15\n\
5.9080490191981 1.3353244313727 1.4365866979199\n\
6.355379347357 0.77382089036761 1.191129752524\n\
-6.661042342167 4.3770108949102 1.1639854734531\n\
-7.6010193552651 3.4370338818121 1.1639854734531\n\
-8.5678292931417 2.032738323976 1.6862235430055\n\
7.8936126530474 -1.533529068168 1.1911297525239\n\
3  0 2 3\n\
3  38 3 2\n\
3  38 2 41\n\
3  38 37 3\n\
3  36 37 38\n\
3  41 42 38\n\
3  34 36 38\n\
3  32 38 39\n\
3  32 34 38\n\
3  42 39 38\n\
3  0 1 2\n\
3  2 1 24\n\
3  25 21 41\n\
3  41 6 42\n\
3  21 7 41\n\
3  2 25 41\n\
3  41 7 6\n\
3  24 13 25\n\
3  24 23 13\n\
3  23 24 1\n\
3  13 15 25\n\
3  25 15 21\n\
3  2 24 25\n\
3  10 13 11\n\
3  13 18 14\n\
3  11 13 14\n\
3  10 15 13\n\
3  13 23 18\n\
3  19 18 23\n\
3  19 23 1\n\
3  29 30 19\n\
3  19 1 29\n\
3  20 19 30\n\
3  18 19 20\n\
3  18 20 16\n\
3  16 20 34\n\
3  34 20 30\n\
3  43 35 34\n\
3  44 34 30\n\
3  34 35 36\n\
3  32 16 34\n\
3  44 43 34\n\
3  39 40 33\n\
3  5 26 33\n\
3  40 5 33\n\
3  39 33 32\n\
3  32 33 26\n\
3  46 39 42\n\
3  46 40 39\n\
3  40 6 5\n\
3  6 40 46\n\
3  6 46 42\n\
3  11 14 12\n\
3  9 10 11\n\
3  11 12 4\n\
3  9 11 4\n\
3  4 6 9\n\
3  4 12 17\n\
3  17 5 4\n\
3  4 5 6\n\
3  6 7 8\n\
3  6 8 9\n\
3  26 17 12\n\
3  16 26 12\n\
3  18 16 12\n\
3  27 16 31\n\
3  32 31 16\n\
3  28 31 32\n\
3  32 26 28\n\
3  21 10 22\n\
3  21 15 10\n\
3  22 7 21\n\
3  26 27 28\n\
3  3 35 0\n\
3  35 43 1\n\
3  1 45 29\n\
3  36 3 37\n\
3  45 30 29\n\
3  8 22 9\n\
3  12 14 18\n\
3  10 9 22\n\
3  28 27 31\n\
3  3 36 35\n\
3  43 44 1\n\
3  1 0 35\n\
3  30 45 44\n\
3  1 44 45\n\
3  22 8 7";

	std::stringstream ss;
	ss << "OFF\n\
47 " << f_num << input;
	ss >> poly;
}

void fill_cube_3(Polyhedron& poly)
{
	std::string input =
		"OFF\n\
8 12 0\n\
-100 -100 -100\n\
-100 100 -100\n\
0 100 -100\n\
0 -100 -100\n\
-100 -100 100\n\
-100 100 100\n\
0 100 100\n\
0 -100 100\n\
3  0 1 3\n\
3  3 1 2\n\
3  0 4 1\n\
3  1 4 5\n\
3  3 2 7\n\
3  7 2 6\n\
3  4 0 3\n\
3  7 4 3\n\
3  6 4 7\n\
3  6 5 4\n\
3  1 5 6\n\
3  2 1 6";

	std::stringstream ss;
	ss << input;
	ss >> poly;
}

void fill_cube_4(Polyhedron& poly, int min, int max)
{
	std::string input =
		"OFF\n\
8 12 0\n\
" + to_string(min) + " " + to_string(min) + " " + to_string(min) + "\n\
" + to_string(min) + " " + to_string(max) + " " + to_string(min) + "\n\
" + to_string(max) + " " + to_string(max) + " " + to_string(min) + "\n\
" + to_string(max) + " " + to_string(min) + " " + to_string(min) + "\n\
" + to_string(min) + " " + to_string(min) + " " + to_string(max) + "\n\
" + to_string(min) + " " + to_string(max) + " " + to_string(max) + "\n\
" + to_string(max) + " " + to_string(max) + " " + to_string(max) + "\n\
" + to_string(max) + " " + to_string(min) + " " + to_string(max) + "\n\
3  0 1 3\n\
3  3 1 2\n\
3  0 4 1\n\
3  1 4 5\n\
3  3 2 7\n\
3  7 2 6\n\
3  4 0 3\n\
3  7 4 3\n\
3  6 4 7\n\
3  6 5 4\n\
3  1 5 6\n\
3  2 1 6";

	std::stringstream ss;
	ss << input;
	ss >> poly;
}

void fill_phd(Polyhedron& poly)
{
	std::string input =
		"OFF\n\
11 8 0\n\
-10 -10 -10\n\
-10 10 -10\n\
0 20 -10\n\
10 10 -10\n\
10 -10 -10\n\
-10 -10 10\n\
-10 10 10\n\
0 20 10\n\
10 10 10\n\
10 -10 10\n\
0 -10 10\n\
5  0 1 2 3 4\n\
4  9 8 7 10\n\
4  10 7 6 5\n\
4  1 0 5 6\n\
4  2 1 6 7\n\
4  3 2 7 8\n\
4  4 3 8 9\n\
4  0 4 9 5";

	std::stringstream ss;
	ss << input;
	ss >> poly;
}

int main()
{
	std::cout << std::fixed << std::setprecision(14);

	std::vector<int> sheet_holes = { 3,2,3,3,6 };

	int id_piece;
	id_piece = 1;
	std::cout << "请输入要使用哪一个零件（编号1-9），按回车结束" << std::endl;
	std::cin >> id_piece;

	int id_sheet;
	id_sheet = 1;
	//std::cout << "请输入要使用哪一块板材（编号1-5），按回车结束" << std::endl;
	//std::cin >> id_sheet;

	c_Point_list_2 c_points_piece = input_polygon("D:/Ph.D/Code/Packing/data/packing/Plane with key points/Pieces/piece " + std::to_string(id_piece) + ".xyz");

	FILE* fp;
	std::string kp_str = "D:/Ph.D/Code/Packing/data/packing/Plane with key points/Pieces/key points " + std::to_string(id_piece) + ".txt";
	fp = fopen(kp_str.c_str(), "r");
	std::vector<std::vector<double>> key_points;
	for (int i_case = 0; i_case < 3; ++i_case) {
		std::vector<double> key_point(2);
		for (int i_id = 0; i_id < 2; ++i_id) {
			fscanf(fp, "%lf", &key_point[i_id]);
		}
		key_points.push_back(key_point);
	}

	std::vector<double> cc_piece(2);
	Polygon_2 piece;
	// for (c_Point_list_2::const_iterator it = c_points_piece.begin(); it != c_points_piece.end(); ++it)
	//	piece.push_back(Point_2(it->x(), it->y()));
	// CGAL::draw(piece);
	piece = init_min_c_c(c_points_piece, cc_piece).outer_boundary();
	Polygon_2 key_point_hole;
	for (int i_poi = 0; i_poi < 3; ++i_poi)
		key_point_hole.push_back(Point_2(key_points[i_poi][0] - cc_piece[0], key_points[i_poi][1]
			- cc_piece[1]));

	c_Point_list_2 c_points_sheet = input_polygon("D:/Ph.D/Code/Packing/data/packing/Plane with key points/Sheets/sheet " + std::to_string(id_sheet) + ".xyz");

	std::vector < c_Point_list_2 > vec_c_points_holes;
	for (int i_p_num = 0; i_p_num < sheet_holes[id_sheet - 1]; ++i_p_num) {
		c_Point_list_2 vec_c_points_hole = input_polygon("D:/Ph.D/Code/Packing/data/packing/Plane with key points/Sheets/sheet " + std::to_string(id_sheet) + "h" + std::to_string(i_p_num + 1) + ".xyz");
		vec_c_points_holes.push_back(vec_c_points_hole);
	}

	Polygon_2 sheet;
	for (c_Point_list_2::const_iterator it = c_points_sheet.begin(); it != c_points_sheet.end(); ++it)
		sheet.push_back(Point_2(it->x(), it->y()));

	std::vector<Polygon_2> holes(sheet_holes[id_sheet - 1]);
	for (int i_p_num = 0; i_p_num < sheet_holes[id_sheet - 1]; ++i_p_num) {
		for (c_Point_list_2::const_iterator it = vec_c_points_holes[i_p_num].begin(); it
			!= vec_c_points_holes[i_p_num].end(); ++it)
			holes[i_p_num].push_back(Point_2(it->x(), it->y()));
	}

	double defect_area = 0;
	for (int i_p_num = 0; i_p_num < sheet_holes[id_sheet - 1]; ++i_p_num) {
		defect_area += to_double(holes[i_p_num].area().approx());
	}

	Polygon_set_2 piece_draw;
	piece_draw.insert(piece);
	piece_draw.difference(key_point_hole);
	//CGAL::draw(piece_draw);

	double radius_lb = 1, radius_ub = 1000;
	int edges = 100;

	std::vector<Polygon_2> cirs(3);
	double radius = 1;
	Polygon_set_2 piece_hole;
	piece_hole.insert(piece);
	for (int i_poi = 0; i_poi < 3; ++i_poi) {
		cirs[i_poi] = Polygon_2_from_circle(edges, key_points[i_poi][0] - cc_piece[0], key_points[i_poi][1]
			- cc_piece[1], radius);
		piece_hole.difference(cirs[i_poi]);
	}
	CGAL::draw(piece_hole);

	double r_s = max_cir_support_point(360, 1, 1000, 0.0000000001, piece, cc_piece, key_points);
	std::cout << r_s << std::endl;

	Polygon_2 pgn_cir = Polygon_2_from_circle(360, 0, 0, r_s);

	Polygon_with_holes_2 mink_res_2d = CGAL::minkowski_sum_2(pgn_cir, sheet);

	std::cout << piece.area() << std::endl;

	std::cout << sheet.area() << std::endl;

	std::cout << mink_res_2d.outer_boundary().area() << std::endl;

	std::cout << defect_area << std::endl;

	double max_num = (to_double(mink_res_2d.outer_boundary().area().approx()) - defect_area)
		/ to_double(piece.area().approx());

	std::cout << max_num << std::endl;

	CGAL::draw(mink_res_2d);



	//CGAL::draw(piece_hole);

	Polygon_2 P_t;
	P_t.push_back(Point_2(0, 0));
	P_t.push_back(Point_2(10, 0));
	P_t.push_back(Point_2(10, 10));
	P_t.push_back(Point_2(0, 10));

	Polygon_2 Q;
	Q.push_back(Point_2(1, 1));
	Q.push_back(Point_2(1, 2));
	Q.push_back(Point_2(2, 2));
	Q.push_back(Point_2(2, 1));

	Polygon_2 rect;
	rect.push_back(Point_2(0, 0));
	rect.push_back(Point_2(3, 0));
	rect.push_back(Point_2(3, 2));
	rect.push_back(Point_2(0, 2));

	Polygon_with_holes_2 pwh_try(P_t);
	pwh_try.add_hole(Q);
	std::cout << Q.is_clockwise_oriented() << std::endl;
	std::cout << pwh_try.holes_begin()->is_clockwise_oriented() << std::endl;
	Polygon_2 Q2;
	for (auto vi = --Q.vertices_end(); vi != --Q.vertices_begin(); --vi) {
		Q2.push_back(*vi);
	}
	std::cout << Q2 << std::endl;
	CGAL::draw(pwh_try);

	srand((unsigned)time(NULL));
	for (int i = 0; i < 100; ++i) {
		double a = double(rand());
		std::cout << a << " ";
		double b = double(rand() % 10000) / 10000;
		std::cout << b << " ";
	}

	Polygon_2 Pgn_t;
	Pgn_t.push_back(Point_2(-15, -15));
	Pgn_t.push_back(Point_2(-1, -15));
	Pgn_t.push_back(Point_2(-1, -11));
	Pgn_t.push_back(Point_2(-11, -11));
	Pgn_t.push_back(Point_2(-11, 11));
	Pgn_t.push_back(Point_2(11, 11));
	Pgn_t.push_back(Point_2(11, -11));
	Pgn_t.push_back(Point_2(1, -11));
	Pgn_t.push_back(Point_2(1, -15));
	Pgn_t.push_back(Point_2(15, -15));
	Pgn_t.push_back(Point_2(15, 15));
	Pgn_t.push_back(Point_2(-15, 15));
	CGAL::draw(Pgn_t);
	Polygon_with_holes_2 Pwh_t(Pgn_t);

	Polyhedron phd_spi = spiral_pgn_0(0, 7.5, Pwh_t);
	//std::cout << phd_spi << std::endl;
	CGAL::draw(phd_spi);

	Polyhedron phd_t1, phd_t2, phd_t3, phd_t4;
	fill_cube_4(phd_t1, 0, 10);
	fill_cube_4(phd_t2, 5, 15);
	fill_cube_4(phd_t3, 10, 20);
	fill_cube_4(phd_t4, 15, 25);
	Nef_polyhedron n_phd_t1(phd_t1), n_phd_t2(phd_t2), n_phd_t3(phd_t3), n_phd_t4(phd_t4);
	Nef_polyhedron n_phd_r1, n_phd_r2;
	n_phd_r1 = n_phd_t1 + n_phd_t2 + n_phd_t3;
	n_phd_r2 = n_phd_t1 + n_phd_t4;
	std::cout << n_phd_r1.is_simple() << " " << n_phd_r1.is_valid() << " " << n_phd_r1.number_of_volumes() << std::endl;
	std::cout << n_phd_r2.is_simple() << " " << n_phd_r2.is_valid() << " " << n_phd_r2.number_of_volumes() << std::endl;
	CGAL::draw(n_phd_r1);
	CGAL::draw(n_phd_r2);


	int f_num;
	std::cout << "请输入需要的面的个数" << std::endl;
	std::cin >> f_num;
	Polyhedron phd2;
	//fill_cube_1(phd2);
	//CGAL::draw(phd2);
	fill_cube_2(phd2, f_num);
	std::cout << phd2.is_closed() << phd2.is_empty() << phd2.is_valid() << phd2.normalized_border_is_valid() << std::endl;
	std::cout << phd2 << std::endl;
	CGAL::draw(phd2);
	Nef_polyhedron n_phd_2(phd2);

	std::cout << n_phd_2.is_valid() << std::endl;
	CGAL::draw(n_phd_2);

	// 假设这是你的二维浮点数组
	vector<vector<double>> data_to_out = {
		{1.1, 2.2, 3.3},
		{4.4, 5.5, 6.6},
		{7.7, 8.8, 9.9}
	};

	int name = 123; // 假设这是你的整数
	string filePath = "D:\\Ph.D\\" + to_string(name) + ".csv"; // 构建文件路径

	// 创建文件输出流
	ofstream outFile;

	outFile.precision(14);
	outFile.open("D:\\Ph.D\\Code\\Packing\\GNN\\original data\\test" + to_string(name) + ".csv", std::ios::out);  //以写入和在文件末尾添加的方式打开.csv文件，没有的话就创建该文件。

	// 检查文件是否成功打开
	//if (!outFile) {
	//	cerr << "无法打开文件: " << filePath << endl;
	//	return 1; // 返回错误码
	//}

	// 设置输出精度
	// outFile << fixed << setprecision(14); // 设置小数点后两位

	// 写入数据到 CSV 文件
	for (const auto& row : data_to_out) {
		for (size_t i = 0; i < row.size(); ++i) {
			outFile << row[i];
			if (i < row.size() - 1) {
				outFile << ","; // 列之间用逗号分隔
			}
		}
		outFile << "\n"; // 每行结束后换行
	}

	// 关闭文件
	outFile.close();
	cout << "数据已成功写入" << endl;

	Polyhedron P_temp;

	Polyhedron penta_t;
	fill_phd(penta_t);
	Nef_polyhedron npenta_t(penta_t);
	CGAL::draw(npenta_t);
	npenta_t.convert_to_polyhedron(P_temp);
	std::cout << npenta_t.is_valid() << P_temp << std::endl;
	CGAL::draw(P_temp);
	Polyhedron cube_t;
	fill_cube_1(cube_t);
	Nef_polyhedron ncube_t(cube_t);

	Polyhedron cube_t2;
	fill_cube_3(cube_t2);
	Nef_polyhedron ncube_t2(cube_t2);
	Nef_polyhedron obo_current_nef_phd(penta_t);
	std::cout << ncube_t << std::endl;
	std::cout << obo_current_nef_phd << std::endl;
	for (auto fi = obo_current_nef_phd.halffacets_begin(); fi != obo_current_nef_phd.halffacets_end(); ++fi) {
		// std::cout << &fi << std::endl;

	}
	std::cout << obo_current_nef_phd.number_of_facets() << obo_current_nef_phd.is_bounded() << obo_current_nef_phd.is_empty() << obo_current_nef_phd.is_shared() << obo_current_nef_phd.is_simple() << obo_current_nef_phd.is_valid() << std::endl;

	CGAL::draw(obo_current_nef_phd);
	obo_current_nef_phd = obo_current_nef_phd - ncube_t2;
	CGAL::draw(obo_current_nef_phd);
	obo_current_nef_phd.convert_to_polyhedron(P_temp);
	std::cout << P_temp << std::endl;
	CGAL::draw(P_temp);

	CGAL::draw(ncube_t);
	ncube_t.convert_to_polyhedron(P_temp);
	std::cout << P_temp << std::endl;
	CGAL::draw(P_temp);

	//Nef_polyhedron nphd2(phd2);

	// Perform a sequence of operations.
	Polygon_set_2 S_1;
	Polygon_set_2 S_2;
	S_1.insert(P_t);
	S_1.join(Q);
	CGAL::draw(S_1);
	S_2.insert(P_t);
	S_2.join(Q);
	CGAL::draw(S_2);
	S_1.difference(S_2);
	std::cout << S_1.is_valid() << S_1.number_of_polygons_with_holes() << std::endl;
	std::list<Polygon_with_holes_2> res;
	std::list<Polygon_with_holes_2>::const_iterator it;

	std::cout << "The result contains " << S_1.number_of_polygons_with_holes()
		<< " components:" << std::endl;

	S_1.polygons_with_holes(std::back_inserter(res));
	for (it = res.begin(); it != res.end(); ++it) {
		std::cout << "--> ";
		std::cout << *it << std::endl;
	}
	CGAL::draw(S_1);

	std::vector<int> test_vec(10, 1);
	for (int i_vec : test_vec) {
		std::cout << i_vec << std::endl;
	}
	

	double d_t_s = 1.11111111111111;
	int i_t_s = 10;
	std::stringstream ss;
	ss.precision(14);
	ss << "OFF" << "\n" << i_t_s << " " << d_t_s << "\nend";
	std::string str_o = ss.str();
	std::cout << str_o << std::endl;

	bool test_bool = true;
	int test_int = test_bool * 2 - 1;
	std::cout << test_bool * 2 - 1 << std::endl;
	test_bool = false;
	test_int = test_bool * 2 - 1;
	std::cout << test_bool * 2 - 1 << std::endl;

	std::vector<double> x_test({ 1,0 });
	for (double i_test = 0; i_test < 30; ++i_test) {
		std::vector<double> y_test({ cos(i_test * 3.1415926 / 15), sin(i_test * 3.1415926 / 15) });
		std::cout << how_much_left_2_unit(x_test, y_test) << std::endl;
	}


	std::vector<double> vec_test({ 0,1,2,3 });
	vec_test.insert(vec_test.begin(), -1);
	for (double val : vec_test) {
		std::cout << val << std::endl;
	}

	// Construct P - a bounded rectangle that contains a rectangular hole.
	Polygon_2 outP;
	Polygon_2 holesP[2];

	outP.push_back(Point_2(-3, -5));  outP.push_back(Point_2(3, -5));
	outP.push_back(Point_2(3, 5));    outP.push_back(Point_2(-3, 5));
	holesP[0].push_back(Point_2(-1, -3));
	holesP[0].push_back(Point_2(-1, 3));
	holesP[0].push_back(Point_2(1, 3));
	holesP[0].push_back(Point_2(1, -3));
	holesP[1].push_back(Point_2(2, -4.5));
	holesP[1].push_back(Point_2(2, -3.5));
	holesP[1].push_back(Point_2(-2, -3.5));
	holesP[1].push_back(Point_2(-2, -4.5));

	Polygon_with_holes_2  P(outP, holesP, holesP + 2);
	std::cout << "P = " << P << std::endl;
	for (auto hi = P.holes_begin(); hi != P.holes_end(); ++hi) {
		std::cout << *hi << std::endl;
		std::cout << hi->orientation() << std::endl;
	}
	
	// Connect the outer boundary of the polygon with its holes.
	std::list<Point_2>            pts;
	std::list<Point_2>::iterator  pit;

	connect_holes(P, std::back_inserter(pts));

	for (pit = pts.begin(); pit != pts.end(); ++pit)
		std::cout << '(' << *pit << ")  ";
	std::cout << std::endl;

	Polygon_2 poly_con(pts.begin(), pts.end());

	CGAL::draw(P);
	CGAL::draw(poly_con);

	Polygon_2 outP_2;
	outP_2.push_back(Point_2(-3, -5));  outP_2.push_back(Point_2(3, -5));
	outP_2.push_back(Point_2(3, 5));    outP_2.push_back(Point_2(-3, 5));
	//逆时针为1，顺时针为-1
	std::cout << outP_2.orientation() << std::endl;
	std::cout << outP_2.vertex(0) << std::endl;

	Polygon_2 outP_3;
	outP_3.push_back(Point_2(-30, 5));  outP_3.push_back(Point_2(30, 5));
	outP_3.push_back(Point_2(30, -5));    outP_3.push_back(Point_2(-30, -5));
	std::cout << outP_3.orientation() << std::endl;
	//在里面为1，在边上为0，在外面为-1
	std::cout << outP_2.bounded_side(outP_3.vertex(0)) << std::endl;
	std::cout << outP_2.bounded_side(Point_2(0, 0)) << std::endl;
	std::cout << outP_2.bounded_side(outP_2.vertex(0)) << std::endl;


	CGAL::draw(outP_2);


	std::vector<std::vector<double>> tris_in_fin_face({{0,0,0,0,0,0,3,0,0,0,3,0,0,0,1,0},
		{0,0,0,2,0,0,5,3,0,2,3,0,0,0,1,0}, {0,0,0,0,2,0,3,2,0,3,5,0,0,0,1,0} });
	//sum_of_single_face(tris_in_fin_face);
	std::vector<std::vector<double>> tris_in_fin_face_2({ {0,0,0,0,0,0,0,3,0,3,0,0,0,0,-1,0},
		{0,0,0,2,0,0,2,3,0,5,3,0,0,0,-1,0}, {0,0,0,0,2,0,3,5,0,3,2,0,0,0,-1,0} });
	//sum_of_single_face(tris_in_fin_face_2);

	int a = 1;
	int b = ++a;
	int c = a++;
	std::cout << a << b << c << std::endl;
	// create two nested cubes
	Polyhedron cube1, cube2;
	fill_cube_1(cube1);
	//fill_cube_2(cube2);

	Nef_polyhedron nef1(cube1);
	Nef_polyhedron nef2(cube2);

	// compute the difference of the nested cubes
	Nef_polyhedron nef = nef1 - nef2;

	CGAL::draw(nef);
	return 0;
}