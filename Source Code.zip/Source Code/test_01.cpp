﻿//计算NFP各步骤所需的时间，以及各个面的个数。
#include <list>
#include <iostream>
#include <fstream>
#include <cassert>

#include <thread>

#include <ilcplex\ilocplex.h>
ILOSTLBEGIN // 等同于 using namespace std; 声明命名空间

#include <Eigen/Dense>

#include <CGAL/IO/read_points.h>

#include <CGAL/Simple_cartesian.h>
#include <CGAL/Min_sphere_of_spheres_d.h>
#include <CGAL/Min_sphere_of_points_d_traits_2.h>
#include <CGAL/Random.h>

#include <CGAL/Exact_predicates_exact_constructions_kernel.h>
#include <CGAL/Polygon_2.h>
#include <CGAL/Polygon_with_holes_2.h>
#include <CGAL/Polygon_set_2.h>

#include <CGAL/Boolean_set_operations_2.h>

#include <CGAL/draw_polygon_set_2.h>
#include <CGAL/draw_polygon_2.h>
#include <CGAL/draw_polygon_with_holes_2.h>

#include <CGAL/Polyhedron_3.h>
#include <CGAL/Nef_polyhedron_3.h>
#include <CGAL/minkowski_sum_2.h>
#include <CGAL/minkowski_sum_3.h>
#include <CGAL/partition_2.h>
#include <CGAL/Partition_traits_2.h>
#include <CGAL/IO/Nef_polyhedron_iostream_3.h>
#include <CGAL/Nef_3/SNC_indexed_items.h>
#include <CGAL/convex_decomposition_3.h>
#include <CGAL/convex_hull_3.h>

#include <CGAL/draw_polyhedron.h>
#include <CGAL/draw_nef_3.h>

#include <CGAL/Epick_d.h>
#include <CGAL/Triangulation.h>

#include "gurobi_c++.h"

#include <draw_res.h>
#include <point_calculation.h>
#include <input_initialize.h>
#include <calculate_2d.h>
#include <calculate_3d.h>
#include <generate_para_2d.h>
#include <generate_para_3d.h>
#include <generate_para_4d.h>
#include <test_draw.h>
#include <try_program.h>
#include <draw_whole_res.h>
#include <scip_program.h>
#include <gurobi_program.h>


#define PI 3.1415926535

#define Epsilon 0.00000001

typedef CGAL::Exact_predicates_exact_constructions_kernel K;
typedef CGAL::Polygon_2<K>                                Polygon_2;
typedef CGAL::Polygon_with_holes_2<K>                     Polygon_with_holes_2;
typedef CGAL::Polygon_set_2<K>                            Polygon_set_2;
typedef CGAL::Point_2<K>                                  Point_2;
typedef CGAL::Vector_2<K>                                 Vector_2;
typedef CGAL::Point_3<K>                                  Point_3;
typedef CGAL::Polyhedron_3<K>							  Polyhedron;
typedef CGAL::Nef_polyhedron_3<K>						  Nef_polyhedron;
//typedef K::Point_2										  Point;
using std::cout;
using std::endl;

typedef CGAL::Simple_cartesian<double>                   c_K;//引自参考min_circle_2的例子
typedef CGAL::Min_sphere_of_points_d_traits_2<c_K, double>   c_Traits;
typedef CGAL::Min_sphere_of_spheres_d<c_Traits>            Min_circle;
typedef CGAL::Point_2<c_K>                                 c_Point_2;
typedef CGAL::Polygon_2<c_K>                                c_Polygon_2;
typedef c_K::Point_3									   input_Point;

typedef CGAL::Partition_traits_2<K>                         Traits;
typedef Traits::Polygon_2                                   p_Polygon_2;
typedef Traits::Point_2                                     p_Point_2;

typedef Polygon_2::Vertex_iterator						  VertexIterator;
typedef Polygon_2::Edge_const_iterator					  EdgeIterator;
typedef p_Polygon_2::Vertex_iterator					  p_VertexIterator;
typedef Nef_polyhedron::Volume_const_iterator			  Volume_const_iterator;
typedef Polyhedron::Vertex_iterator						  phd_VertexIterator;
typedef Polyhedron::Facet_iterator					      phd_FacetIterator;
//typedef Nef_polyhedron::Vertex_iterator					  N_phd_VertexIterator;
typedef Nef_polyhedron::Aff_transformation_3			  Aff_transformation_3;
typedef Polyhedron::Halfedge_around_facet_circulator	  Halfedge_facet_circulator;

typedef CGAL::Epick_d<CGAL::Dynamic_dimension_tag>		  D_dim;
typedef CGAL::Triangulation<D_dim>                        Triangulation;
typedef CGAL::Triangulation_data_structure<D_dim>         TDS;
typedef Triangulation::Point			                  D_dim_point;
typedef Triangulation::Full_cell_handle					  Full_cell_handle;
typedef Triangulation::Facet							  Facet;
typedef Triangulation::Face								  Face;

typedef std::list<Point_2>								  Point_list_2;
typedef std::list<c_Point_2>							  c_Point_list_2;
typedef std::list<p_Polygon_2>                            p_Pgn_list_2;
typedef std::list<Point_3>								  Point_list_3;
typedef std::list<Polygon_with_holes_2>                   Pwh_list_2;
typedef std::list<Polygon_2>							  Pgn_list_2;
typedef std::list<Nef_polyhedron>						  N_phd_list;
typedef std::list<Polyhedron>							  phd_list;
typedef std::vector<Full_cell_handle>					  Full_cells;
typedef std::vector<Face>								  Faces;

bool res_sort_nfp(std::vector<double> a, std::vector<double> b) {
	if (a[0] < b[0] + Epsilon && b[0] < a[0] + Epsilon)
		return a[1] < b[1];//如果目标函数一样，重合面积升序
	else
		return a[0] < b[0];//目标函数升序(小的放前面)
}

bool res_sort_ifp(std::vector<double> a, std::vector<double> b) {
	if (a[4] == b[4])
		return a[0] < b[0];//如果ifp编号一样，目标函数升序
	else
		return a[4] < b[4];//ifp编号升序(小的放前面)
}

//根据数组第一位（下标为0），升序排序（小的放前面）
bool res_sort_0(std::vector<double> a, std::vector<double> b) {
	return a[0] < b[0];//ifp编号升序(小的放前面)
}

int main()
{
	std::cout.precision(14);
	std::ofstream nfp_time;
	nfp_time.precision(14);
	nfp_time.open("D:/Ph.D/Code/Packing/data/packing/nfp_time.txt", std::ios::out);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
	nfp_time.close();
	std::vector < c_Point_list_2 > vec_c_points_75 = input_polygons(75, "D:/Ph.D/Code/Packing/data/packing/poly/polygon_");
	std::vector < c_Point_list_2 > vec_c_points_albano_24 = input_polygons(24, "D:/Ph.D/Code/Packing/data/packing/albano/polygon_");

	FILE* fp;
	fp = fopen("D:/Ph.D/Code/Packing/data/packing/random_poly_0.txt", "r");
	std::vector<std::vector<double>> vec_cases;
	std::vector<std::vector<double>> vec_cases_albano;
	for (int i_case = 0; i_case < 100; ++i_case) {
		std::vector<double> vec_case(75);
		std::vector<double> vec_case_albano(24);
		int i_id_albano = 0;
		for (int i_id = 0; i_id < 75; ++i_id) {
			fscanf(fp, "%lf", &vec_case[i_id]);
			if (vec_case[i_id] < 24) {
				vec_case_albano[i_id_albano] = vec_case[i_id];
				i_id_albano++;
			}
		}
		vec_cases.push_back(vec_case);
		vec_cases_albano.push_back(vec_case_albano);
	}

	int which_instance;
	//which_case = 0;
	std::cout << "请输入要使用哪一个问题，0为poly，1为albano，按回车结束" << std::endl;
	std::cin >> which_instance;

	int polygon_num;
	if (which_instance == 0) {
		polygon_num = 30;
		std::cout << "使用poly" << std::endl;
	}
	else {
		polygon_num = 24;
	}
	//std::cout << "请输入多边形数量，按回车结束" << std::endl;
	//std::cin >> polygon_num;

	double ang_step_size;
	ang_step_size = 30;
	//std::cout << "请输入角度步长，按回车结束" << std::endl;
	//std::cin >> ang_step_size;
	std::vector<double> ang_step_size_albano(polygon_num, 30);

	int which_case;
	//which_case = 0;
	std::cout << "请输入要使用哪一个随机序列（如使用1-30原始序列，输入10000），按回车结束" << std::endl;
	std::cin >> which_case;

	std::vector<c_Point_list_2> vec_c_points;
	if (which_instance == 0) {
		if (which_case == 10000) {
			for (int i_pgn = 0; i_pgn < polygon_num; ++i_pgn) {
				vec_c_points.push_back(vec_c_points_75[i_pgn]);
			}
		}
		else {
			for (int i_pgn = 0; i_pgn < polygon_num; ++i_pgn) {
				vec_c_points.push_back(vec_c_points_75[vec_cases[which_case][i_pgn]]);
			}
		}
	}
	else {
		for (int i_pgn = 0; i_pgn < polygon_num; ++i_pgn) {
			vec_c_points.push_back(vec_c_points_albano_24[vec_cases_albano[which_case][i_pgn]]);
			if (vec_cases_albano[which_case][i_pgn] >= 2 && vec_cases_albano[which_case][i_pgn] <= 3) {
				ang_step_size_albano[i_pgn] = 9;
			}
			else {
				if (vec_cases_albano[which_case][i_pgn] >= 8 && vec_cases_albano[which_case][i_pgn] <= 11) {
					ang_step_size_albano[i_pgn] = 20;
				}
			}
		}
	}

	double width;
	if (which_instance == 0) {
		width = 40;
	}
	else {
		width = 49;
	}
	//std::cout << "请输入箱子宽度，按回车结束" << std::endl;
	//std::cin >> width;
	double length;
	if (which_instance == 0) {
		length = 60;
	}
	else {
		length = 200;
	}
	//std::cout << "请输入箱子长度，按回车结束" << std::endl;
	//std::cin >> length;

	double alpha_obj;
	alpha_obj = 0.001;
	//std::cout << "请输入目标函数x+αy中的系数α，按回车结束" << std::endl;
	//std::cin >> alpha_obj;

	double beta_obj;
	beta_obj = 0.00001;
	//std::cout << "请输入目标函数中零件坐标x+y的系数β，按回车结束" << std::endl;
	//std::cin >> beta_obj;

	std::vector<double> polygons_symm(polygon_num, 1);

	//非线性规划情况下，D-function，大概是最大的图形的最长的一条线的长度*sqrt(2)*length
	double big_m_nonlin = 2 * max(length, width) * max(length, width);

	double time_lim = 3600;

	std::vector<Polygon_with_holes_2> pwhs(polygon_num);
	std::vector<Polygon_2> pgns(polygon_num);
	std::vector<Polygon_2> pgns_trans(polygon_num);
	std::vector<Polygon_2> pgns_inset(polygon_num);
	//std::vector<std::list<Nef_polyhedron>> N_pgn_par_lists;
	std::vector<std::vector<double>> pgns_bbox;//每个图形都有一个四维变量，保存着minx，miny，maxx，maxy

	for (int i_p_num = 0; i_p_num < polygon_num; ++i_p_num) {
		std::vector<double> pgn_bbox;
		//调整图形位置，后续需要
		pwhs[i_p_num] = init_min_c(vec_c_points[i_p_num], pgn_bbox);
		//对图形不进行旋转
		pgns[i_p_num] = pwhs[i_p_num].outer_boundary();
		pgns_inset[i_p_num] = Polygon_2_inset(pgns[i_p_num], 0.0000001);
		//CGAL::draw(pwhs[i_p_num]);
		pgn_bbox = bbox_cal(pgns[i_p_num]);
		pgns_bbox.push_back(pgn_bbox);
		//std::list<Nef_polyhedron> N_pgn_par_list;
		//decomp_2(pgns[i_p_num], N_pgn_par_list);
		//N_pgn_par_lists.push_back(N_pgn_par_list);
	}

	std::vector<double> angles_o;//origin（用来对比的）
	angles_o.push_back(0);
	angles_o.push_back(PI / 2);
	angles_o.push_back(PI);
	angles_o.push_back(3 * PI / 2);

	//bin只包含箱子的形状
	std::vector<Polygon_with_holes_2> bin_pwh_vec;
	//Pwh_list_2                  ifp_pwh_list;
	std::vector<Polygon_with_holes_2>::const_iterator  it;

	Point_list_2 poi_box = { Point_2(-1, -1), Point_2(length + 1, -1),
			Point_2(length + 1, width + 1), Point_2(-1, width + 1) };
	Polygon_with_holes_2 ifp_box(Polygon_2(poi_box.begin(), poi_box.end()));
	Point_list_2 poi_bin = { Point_2(0, 0), Point_2(length, 0),
			Point_2(length, width), Point_2(0, width) };
	Polygon_with_holes_2 bin_pwh(Polygon_2(poi_bin.begin(), poi_bin.end()));
	bin_pwh_vec.push_back(bin_pwh);

	//ifp是将箱子挖空后的有孔多边形
	std::vector<Polygon_with_holes_2> ifp_pwh_vec;
	Polygon_with_holes_2 ifp_pwh;
	//如果报错说明difference结果不是一个图形，而是多个图形
	difference(ifp_box, bin_pwh, &ifp_pwh);
	ifp_pwh_vec.push_back(ifp_pwh);

	//CGAL::intersection(pgn_n, Polygon_2(poi_obj.begin(), poi_obj.end()), std::back_inserter(ifp_pwh_vec));
	std::vector<std::list<Nef_polyhedron>> N_pgn_par_lists;
	std::vector<std::vector<double>> coord_all;

	for (int i_p_num = 0; i_p_num < polygon_num; ++i_p_num) {
		for (int i_p_num_2 = 0; i_p_num_2 < polygon_num; ++i_p_num_2) {

			double beg_ang = 0, end_ang;

			double min_ang = min_angle(pgns[i_p_num_2]);
			std::cout << min_ang << std::endl;
			if (min_ang > 30) {
				end_ang = 30;
			}
			else {
				if (min_ang > 22.5) {
					end_ang = 22.5;
				}
				else {
					if (min_ang > 18) {
						end_ang = 18;
					}
					else {
						if (min_ang > 15) {
							end_ang = 15;
						}
						else {
							if (min_ang > 11.25) {
								end_ang = 11.25;
							}
							else {
								std::cout << "min_angle < 11.25" << std::endl;
							}
						}
					}
				}
			}

			DWORD t_spi01 = GetTickCount64();
			Polyhedron phd_spi = spiral_pgn_0(beg_ang, end_ang, pwhs[i_p_num_2]);
			DWORD t_spi02 = GetTickCount64();
			double t_spi0 = (t_spi02 - t_spi01) * 1.0 / 1000;
			//std::cout << phd_spi << std::endl;
			//CGAL::draw(phd_spi);

			DWORD t_dec01 = GetTickCount64();
			std::list<Nef_polyhedron> N_pgn_par_list;
			decomp_2(pgns[i_p_num], N_pgn_par_list);
			N_pgn_par_lists.push_back(N_pgn_par_list);
			DWORD t_dec02 = GetTickCount64();
			double t_dec0 = (t_dec02 - t_dec01) * 1.0 / 1000;

			DWORD t_dec11 = GetTickCount64();
			Nef_polyhedron N_phd_spi(phd_spi);
			CGAL::convex_decomposition_3(N_phd_spi);
			DWORD t_dec12 = GetTickCount64();
			double t_dec1 = (t_dec12 - t_dec11) * 1.0 / 1000;

			//CGAL::draw(pgns[i_p_num]);
			//CGAL::draw(N_phd_spi);

			DWORD t_nfp01 = GetTickCount64();
			Nef_polyhedron mink_res;
			Volume_const_iterator ci = ++N_phd_spi.volumes_begin();
			for (; ci != N_phd_spi.volumes_end(); ++ci) {
				if (ci->mark()) {
					Polyhedron P;
					N_phd_spi.convert_inner_shell_to_polyhedron(ci->shells_begin(), P);
					Nef_polyhedron N_P(P);
					Nef_polyhedron mink_res_temp;
					for (std::_List_iterator<std::_List_val<std::_List_simple_types<Nef_polyhedron>>>
						i_phd = N_pgn_par_list.begin(); i_phd != N_pgn_par_list.end(); ++i_phd) {
						mink_res_temp += CGAL::bipartite_nary_union_sorted_combined(*i_phd, N_P);
					}
					mink_res += mink_res_temp;
				}
			}

			DWORD t_nfp02 = GetTickCount64();
			double t_nfp0 = (t_nfp02 - t_nfp01) * 1.0 / 1000;
			std::cout << t_nfp0 << std::endl;

			//CGAL::draw(mink_res);

			DWORD t_nfp11 = GetTickCount64();
			std::vector<Nef_polyhedron> mink_res_test_vector;
			ci = ++N_phd_spi.volumes_begin();
			for (; ci != N_phd_spi.volumes_end(); ++ci) {
				if (ci->mark()) {
					Polyhedron P;
					N_phd_spi.convert_inner_shell_to_polyhedron(ci->shells_begin(), P);
					Nef_polyhedron N_P(P);
					for (std::_List_iterator<std::_List_val<std::_List_simple_types<Nef_polyhedron>>>
						i_phd = N_pgn_par_list.begin(); i_phd != N_pgn_par_list.end(); ++i_phd) {
						mink_res_test_vector.push_back(CGAL::bipartite_nary_union_sorted_combined(*i_phd, N_P));
					}
				}
			}

			DWORD t_nfp12 = GetTickCount64();
			double t_nfp1 = (t_nfp12 - t_nfp11) * 1.0 / 1000;
			std::cout << t_nfp1 << std::endl;

			int n_faces = 0;
			for (int i = 0; i < mink_res_test_vector.size(); i++) {
				n_faces += mink_res_test_vector[i].number_of_facets();
			}

			DWORD t_nfp21 = GetTickCount64();
			Nef_polyhedron mink_res_2;
			for (int i = 0; i < mink_res_test_vector.size(); i++) {
				mink_res_2 += mink_res_test_vector[i];
			}
			DWORD t_nfp22 = GetTickCount64();
			double t_nfp2 = (t_nfp22 - t_nfp21) * 1.0 / 1000;
			std::cout << t_nfp2 << std::endl;

			//CGAL::draw(mink_res);

			nfp_time.open("D:/Ph.D/Code/Packing/data/packing/nfp_time.txt", std::ios::out | std::ios::app);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
			nfp_time << i_p_num << " " << i_p_num_2 << " " << t_spi0 << " " << t_dec0 << " " << t_dec1 << " " << t_nfp0 << " " << t_nfp1 << " " << t_nfp2 << " " << mink_res_2.number_of_facets() << " " << mink_res_test_vector.size() << " " << n_faces << "\n";
			nfp_time.close();

			//std::cout << mink_res_test_vector.size() << std::endl;
			//for (int i = 0; i < mink_res_test_vector.size(); i++) {
			//	CGAL::draw(mink_res_test_vector[i]);
			//}
		}
	}

	return 0;
}

/*
\n 换行符(LF)

\r 回车(CR) ，相当于键盘上的"Enter"

\t 跳到下一个TAB位置

\0 空字符(NULL)

\' 单引号（撇号）

\" 双引号

\\ 代表一个反斜线字符''\'

\ 继续符，可用于一行的结尾，表示本行与下一行连接起来
*/