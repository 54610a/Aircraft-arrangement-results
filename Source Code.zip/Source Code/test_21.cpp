﻿// test

#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>
#include <CGAL/Polygon_2.h>
#include <CGAL/number_utils.h>   // CGAL::to_double
#include <fstream>
#include <limits>
#include <algorithm>

typedef CGAL::Exact_predicates_inexact_constructions_kernel K;
typedef CGAL::Polygon_2<K> Polygon;

// 把多边形保存为 SVG（只画轮廓）
void save_polygon_as_svg(const Polygon& P,
    const std::string& filename,
    int width = 800,
    int height = 800)
{
    if (P.is_empty())
        return;

    // 1. 计算多边形的包围盒
    double min_x = std::numeric_limits<double>::infinity();
    double max_x = -std::numeric_limits<double>::infinity();
    double min_y = std::numeric_limits<double>::infinity();
    double max_y = -std::numeric_limits<double>::infinity();

    for (auto vit = P.vertices_begin(); vit != P.vertices_end(); ++vit) {
        double x = CGAL::to_double(vit->x());
        double y = CGAL::to_double(vit->y());
        min_x = std::min(min_x, x);
        max_x = std::max(max_x, x);
        min_y = std::min(min_y, y);
        max_y = std::max(max_y, y);
    }

    double dx = max_x - min_x;
    double dy = max_y - min_y;

    // 2. 缩放到图像大小，预留一点边距
    double scale = 0.9 * std::min(width / dx, height / dy);

    // 3. 把多边形中心对齐到图像中心
    double cx = 0.5 * (min_x + max_x);
    double cy = 0.5 * (min_y + max_y);
    double img_cx = width * 0.5;
    double img_cy = height * 0.5;

    std::ofstream out(filename);
    out << "<?xml version=\"1.0\" standalone=\"no\"?>\n";
    out << "<svg xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\" "
        << "width=\"" << width << "\" height=\"" << height << "\">\n";
    // 4. 画一个多边形（轮廓）
    out << "<polygon fill=\"none\" stroke=\"black\" stroke-width=\"1\" points=\"";
    for (auto vit = P.vertices_begin(); vit != P.vertices_end(); ++vit) {
        double x = CGAL::to_double(vit->x());
        double y = CGAL::to_double(vit->y());
        double sx = img_cx + (x - cx) * scale;
        double sy = img_cy - (y - cy) * scale;  // SVG y 轴向下，这里取反
        out << sx << "," << sy << " ";
    }
    out << "\" />\n";
    out << "</svg>\n";
}
int main() {
    std::vector<int> vec_min_b(2);
    std::cout << vec_min_b.size() << vec_min_b[0];
    Polygon P;
    P.push_back(K::Point_2(0, 0));
    P.push_back(K::Point_2(1, 0));
    P.push_back(K::Point_2(1, 1));
    P.push_back(K::Point_2(0, 1));

    save_polygon_as_svg(P, "D:/Ph.D/Code/Packing/data/packing/shang qi test/polygon.svg");

    return 0;
}
