﻿//尝试plane with key points数据集，只用2D NFP，使用已计算好的nfp
#include <list>
#include <iostream>
#include <fstream>
#include <cassert>

#include <thread>

#include <ilcplex\ilocplex.h>
ILOSTLBEGIN // 等同于 using namespace std; 声明命名空间

#include <Eigen/Dense>

#include <CGAL/IO/read_points.h>

#include <CGAL/Simple_cartesian.h>
#include <CGAL/Min_sphere_of_spheres_d.h>
#include <CGAL/Min_sphere_of_points_d_traits_2.h>
#include <CGAL/Random.h>

#include <CGAL/Exact_predicates_exact_constructions_kernel.h>
#include <CGAL/Polygon_2.h>
#include <CGAL/Polygon_with_holes_2.h>
#include <CGAL/Polygon_set_2.h>

#include <CGAL/Boolean_set_operations_2.h>

#include <CGAL/draw_polygon_set_2.h>
#include <CGAL/draw_polygon_2.h>
#include <CGAL/draw_polygon_with_holes_2.h>

#include <CGAL/Polyhedron_3.h>
#include <CGAL/Nef_polyhedron_3.h>
#include <CGAL/minkowski_sum_2.h>
#include <CGAL/minkowski_sum_3.h>
#include <CGAL/partition_2.h>
#include <CGAL/Partition_traits_2.h>
#include <CGAL/IO/Nef_polyhedron_iostream_3.h>
#include <CGAL/Nef_3/SNC_indexed_items.h>
#include <CGAL/convex_decomposition_3.h>
#include <CGAL/convex_hull_3.h>

#include <CGAL/draw_polyhedron.h>
#include <CGAL/draw_nef_3.h>

#include <CGAL/Epick_d.h>
#include <CGAL/Triangulation.h>

#include "gurobi_c++.h"

#include <draw_res.h>
#include <point_calculation.h>
#include <input_initialize.h>
#include <calculate_2d.h>
#include <calculate_3d.h>
#include <generate_para_2d.h>
#include <generate_para_3d.h>
#include <generate_para_4d.h>
#include <test_draw.h>
#include <try_program.h>
#include <draw_whole_res.h>
#include <scip_program.h>
#include <gurobi_program.h>


#define PI 3.1415926535

#define Epsilon 0.00000001

typedef CGAL::Exact_predicates_exact_constructions_kernel K;
typedef CGAL::Polygon_2<K>                                Polygon_2;
typedef CGAL::Polygon_with_holes_2<K>                     Polygon_with_holes_2;
typedef CGAL::Polygon_set_2<K>                            Polygon_set_2;
typedef CGAL::Point_2<K>                                  Point_2;
typedef CGAL::Vector_2<K>                                 Vector_2;
typedef CGAL::Point_3<K>                                  Point_3;
typedef CGAL::Polyhedron_3<K>							  Polyhedron;
typedef CGAL::Nef_polyhedron_3<K>						  Nef_polyhedron;
//typedef K::Point_2										  Point;
using std::cout;
using std::endl;

typedef CGAL::Simple_cartesian<double>                   c_K;//引自参考min_circle_2的例子
typedef CGAL::Min_sphere_of_points_d_traits_2<c_K, double>   c_Traits;
typedef CGAL::Min_sphere_of_spheres_d<c_Traits>            Min_circle;
typedef CGAL::Point_2<c_K>                                 c_Point_2;
typedef CGAL::Polygon_2<c_K>                                c_Polygon_2;
typedef c_K::Point_3									   input_Point;

typedef CGAL::Partition_traits_2<K>                         Traits;
typedef Traits::Polygon_2                                   p_Polygon_2;
typedef Traits::Point_2                                     p_Point_2;

typedef Polygon_2::Vertex_iterator						  VertexIterator;
typedef Polygon_2::Edge_const_iterator					  EdgeIterator;
typedef p_Polygon_2::Vertex_iterator					  p_VertexIterator;
typedef Nef_polyhedron::Volume_const_iterator			  Volume_const_iterator;
typedef Polyhedron::Vertex_iterator						  phd_VertexIterator;
typedef Polyhedron::Facet_iterator					      phd_FacetIterator;
//typedef Nef_polyhedron::Vertex_iterator					  N_phd_VertexIterator;
typedef Nef_polyhedron::Aff_transformation_3			  Aff_transformation_3;
typedef Polyhedron::Halfedge_around_facet_circulator	  Halfedge_facet_circulator;

typedef CGAL::Epick_d<CGAL::Dynamic_dimension_tag>		  D_dim;
typedef CGAL::Triangulation<D_dim>                        Triangulation;
typedef CGAL::Triangulation_data_structure<D_dim>         TDS;
typedef Triangulation::Point			                  D_dim_point;
typedef Triangulation::Full_cell_handle					  Full_cell_handle;
typedef Triangulation::Facet							  Facet;
typedef Triangulation::Face								  Face;

typedef std::list<Point_2>								  Point_list_2;
typedef std::list<c_Point_2>							  c_Point_list_2;
typedef std::list<p_Polygon_2>                            p_Pgn_list_2;
typedef std::list<Point_3>								  Point_list_3;
typedef std::list<Polygon_with_holes_2>                   Pwh_list_2;
typedef std::list<Polygon_2>							  Pgn_list_2;
typedef std::list<Nef_polyhedron>						  N_phd_list;
typedef std::list<Polyhedron>							  phd_list;
typedef std::vector<Full_cell_handle>					  Full_cells;
typedef std::vector<Face>								  Faces;

bool res_sort_nfp(std::vector<double> a, std::vector<double> b) {
	if (a[0] < b[0] + Epsilon && b[0] < a[0] + Epsilon)
		return a[1] < b[1];//如果目标函数一样，重合面积升序
	else
		return a[0] < b[0];//目标函数升序(小的放前面)
}

bool res_sort_ifp(std::vector<double> a, std::vector<double> b) {
	if (a[4] == b[4])
		return a[0] < b[0];//如果ifp编号一样，目标函数升序
	else
		return a[4] < b[4];//ifp编号升序(小的放前面)
}

//根据数组第一位（下标为0），升序排序（小的放前面）
bool res_sort_0(std::vector<double> a, std::vector<double> b) {
	return a[0] < b[0];//ifp编号升序(小的放前面)
}

int main()
{
	std::ofstream out_num;
	out_num.precision(14);

	int id_piece;
	//id_piece = 0;
	std::cout << "请输入要使用哪一个零件（编号1-9），按回车结束" << std::endl;
	std::cin >> id_piece;

	c_Point_list_2 c_points_piece = input_polygon("D:/Ph.D/Code/Packing/data/packing/Plane with key points/Pieces/piece " + std::to_string(id_piece) + ".xyz");

	FILE* fp;
	std::string kp_str = "D:/Ph.D/Code/Packing/data/packing/Plane with key points/Pieces/key points " + std::to_string(id_piece) + ".txt";
	fp = fopen(kp_str.c_str(), "r");
	std::vector<std::vector<double>> key_points;
	for (int i_case = 0; i_case < 3; ++i_case) {
		std::vector<double> key_point(2);
		for (int i_id = 0; i_id < 2; ++i_id) {
			fscanf(fp, "%lf", &key_point[i_id]);
		}
		key_points.push_back(key_point);
	}
	fclose(fp);

	int id_sheet;
	//id_sheet = 0;
	std::cout << "请输入要使用哪一块板材（编号1-5），按回车结束" << std::endl;
	std::cin >> id_sheet;

	std::vector<int> sheet_holes = { 3,2,3,3,6 };

	c_Point_list_2 c_points_sheet = input_polygon("D:/Ph.D/Code/Packing/data/packing/Plane with key points/Sheets/sheet " + std::to_string(id_sheet) + ".xyz");

	std::vector < c_Point_list_2 > vec_c_points_holes;
	for (int i_p_num = 0; i_p_num < sheet_holes[id_sheet - 1]; ++i_p_num) {
		c_Point_list_2 vec_c_points_hole = input_polygon("D:/Ph.D/Code/Packing/data/packing/Plane with key points/Sheets/sheet " + std::to_string(id_sheet) + "h" + std::to_string(i_p_num + 1) + ".xyz");
		vec_c_points_holes.push_back(vec_c_points_hole);
	}

	//std::vector < c_Point_list_2 > vec_c_points_holes = input_polygons(sheet_holes[id_sheet - 1], "D:/Ph.D/Code/Packing/data/packing/Plane with key points/Sheets/sheet " + std::to_string(id_piece) + "h");

	double obj_ang;
	obj_ang = 0;
	//std::cout << "请输入目标函数角度（弧度制），按回车结束" << std::endl;
	//std::cin >> obj_ang;
	double x_para = cos(obj_ang);
	double y_para = sin(obj_ang);
	//std::cout << sin(PI/2) << std::endl;

	int eve_n;
	//eve_n = 8;
	std::cout << "请输入选择几个均分角度进行比较，按回车结束" << std::endl;
	std::cin >> eve_n;

	std::vector<double> cc_piece(2);
	Polygon_2 piece;
	// for (c_Point_list_2::const_iterator it = c_points_piece.begin(); it != c_points_piece.end(); ++it)
	//	piece.push_back(Point_2(it->x(), it->y()));
	// CGAL::draw(piece);
	piece = init_min_c_c(c_points_piece, cc_piece).outer_boundary();
	Polygon_2 key_point_hole;
	for (int i_poi = 0; i_poi < 3; ++i_poi)
		key_point_hole.push_back(Point_2(key_points[i_poi][0] - cc_piece[0], key_points[i_poi][1]
			- cc_piece[1]));

	Polygon_2 sheet;
	for (c_Point_list_2::const_iterator it = c_points_sheet.begin(); it != c_points_sheet.end(); ++it)
		sheet.push_back(Point_2(it->x(), it->y()));

	std::vector<Polygon_2> holes(sheet_holes[id_sheet - 1]);
	for (int i_p_num = 0; i_p_num < sheet_holes[id_sheet - 1]; ++i_p_num) {
		for (c_Point_list_2::const_iterator it = vec_c_points_holes[i_p_num].begin(); it
			!= vec_c_points_holes[i_p_num].end(); ++it)
			holes[i_p_num].push_back(Point_2(it->x(), it->y()));
	}

	Polygon_set_2 piece_draw;
	piece_draw.insert(piece);
	piece_draw.difference(key_point_hole);
	//CGAL::draw(piece_draw);

	Polygon_set_2 sheet_draw;
	sheet_draw.insert(sheet);
	for (int i_p_num = 0; i_p_num < sheet_holes[id_sheet - 1]; ++i_p_num) {
		sheet_draw.difference(holes[i_p_num]);
	}
	//CGAL::draw(sheet_draw);

	std::vector<Polygon_set_2> feasible_vec;
	std::vector<std::vector<Polygon_2>> nfp_vv;

	for (int i_eve_1 = 0; i_eve_1 < eve_n; ++i_eve_1) {
		int ang_1 = 360.0 / eve_n * i_eve_1;
		std::cout << "reading: ang_1: " << ang_1 << std::endl;
		Polygon_set_2 feasible_single;

		Polygon_2 feasible_sheet;
		std::vector<double> f_poi({ 0,0 });
		kp_str = "D:/Ph.D/Code/Packing/data/packing/nfp record/p"
			+ std::to_string(id_piece) + "s" + std::to_string(id_sheet) + "_"
			+ std::to_string(ang_1) + "feasible_sheet.txt";
		fp = fopen(kp_str.c_str(), "r");
		while (fscanf(fp, "%lf", &f_poi[0]) == 1) {
			fscanf(fp, "%lf", &f_poi[1]);
			feasible_sheet.push_back(Point_2(f_poi[0], f_poi[1]));
		}
		fclose(fp);

		feasible_single.insert(feasible_sheet);

		for (int i_hole = 0; i_hole < sheet_holes[id_sheet - 1]; ++i_hole) {
			Polygon_2 hole_nfp;
			f_poi = { 0,0 };
			kp_str = "D:/Ph.D/Code/Packing/data/packing/nfp record/p"
				+ std::to_string(id_piece) + "s" + std::to_string(id_sheet) + "h"
				+ std::to_string(i_hole) + "_" + std::to_string(ang_1) + "hole_nfp.txt";
			fp = fopen(kp_str.c_str(), "r");
			while (fscanf(fp, "%lf", &f_poi[0]) == 1) {
				fscanf(fp, "%lf", &f_poi[1]);
				hole_nfp.push_back(Point_2(f_poi[0], f_poi[1]));
			}
			fclose(fp);
			feasible_single.difference(hole_nfp);
		}
		feasible_vec.push_back(feasible_single);

		std::vector<Polygon_2> nfp_v;
		for (int i_eve_2 = 0; i_eve_2 < eve_n; ++i_eve_2) {
			int ang_2 = 360.0 / eve_n * i_eve_2;
			Polygon_2 piece_nfp;
			f_poi = { 0,0 };
			kp_str = "D:/Ph.D/Code/Packing/data/packing/nfp record/p"
				+ std::to_string(id_piece) + "_" + std::to_string(ang_1) + "_"
				+ std::to_string(ang_2) + "piece_nfp.txt";
			fp = fopen(kp_str.c_str(), "r");
			while (fscanf(fp, "%lf", &f_poi[0]) == 1) {
				fscanf(fp, "%lf", &f_poi[1]);
				piece_nfp.push_back(Point_2(f_poi[0], f_poi[1]));
			}
			fclose(fp);
			nfp_v.push_back(piece_nfp);
			//std::cout << ang_2 << std::endl;
		}
		nfp_vv.push_back(nfp_v);
	}

	// feasible_basic只针对当前旋转角度
	Polygon_set_2 feasible_basic;
	feasible_basic.insert(sheet);
	Polygon_2 sheet_kp;
	for (int i_poi = 0; i_poi < 3; ++i_poi) {
		sheet_kp = Polygon_2_trans(sheet, cc_piece[0] - key_points[i_poi][0], cc_piece[1]
			- key_points[i_poi][1]);
		feasible_basic.intersection(sheet_kp);
	}
	//CGAL::draw(feasible_basic);
	for (int i_p_num = 0; i_p_num < sheet_holes[id_sheet - 1]; ++i_p_num) {
		Polygon_with_holes_2 mink_res_2d = CGAL::minkowski_sum_2(holes[i_p_num],
			Polygon_2_turn_acw(piece, PI));
		feasible_basic.difference(mink_res_2d);
	}
	//CGAL::draw(feasible_basic);

	std::vector<Polygon_2> pgns_to_draw;
	for (int i_p_num = 0; i_p_num < sheet_holes[id_sheet - 1]; ++i_p_num)
		pgns_to_draw.push_back(holes[i_p_num]);
	int num_packed = 0;
	//Polygon_set_2 feasible = feasible_basic;
	std::vector<std::vector<double>> res_coords;
	for (;;) {
		double best_obj = 100000;
		int best_i_eve;
		std::vector<double> best_coord;
		for (int i_eve = 0; i_eve < eve_n; ++i_eve) {
			if (feasible_vec[i_eve].number_of_polygons_with_holes() == 0) {
				continue;
			}
			std::list<Polygon_with_holes_2> res;
			std::list<Polygon_with_holes_2>::const_iterator it;

			double best_obj_local = 100000;
			std::vector<double> best_coord_local;
			feasible_vec[i_eve].polygons_with_holes(std::back_inserter(res));
			for (it = res.begin(); it != res.end(); ++it) {
				Polygon_2 ob = it->outer_boundary();
				for (VertexIterator vi = ob.vertices_begin(); vi != ob.vertices_end(); ++vi) {
					double vi_x = to_double(vi->x().approx());
					double vi_y = to_double(vi->y().approx());
					double obj = vi_x * x_para + vi_y * y_para;
					if (obj < best_obj_local) {
						best_obj_local = obj;
						best_coord_local = { vi_x, vi_y };
					}
				}
			}
			if (best_obj_local < best_obj) {
				best_obj = best_obj_local;
				best_coord = best_coord_local;
				best_i_eve = i_eve;
			}
		}

		if (best_obj == 100000)
			break;

		pgns_to_draw.push_back(Polygon_2_trans(Polygon_2_turn_acw(piece, 2.0 * PI / eve_n * best_i_eve),
			best_coord[0], best_coord[1]));
		std::cout << "best_i_eve: " << best_i_eve << std::endl;

		/*
		if (feasible.number_of_polygons_with_holes() == 0) {
			break;
		}
		std::list<Polygon_with_holes_2> res;
		std::list<Polygon_with_holes_2>::const_iterator it;

		double best_obj = 100000;
		std::vector<double> best_coord(2);
		feasible.polygons_with_holes(std::back_inserter(res));
		for (it = res.begin(); it != res.end(); ++it) {
			Polygon_2 ob = it->outer_boundary();
			for (VertexIterator vi = ob.vertices_begin(); vi != ob.vertices_end(); ++vi) {
				double vi_x = to_double(vi->x().approx());
				double vi_y = to_double(vi->y().approx());
				double obj = vi_x * x_para + vi_y * y_para;
				if (obj < best_obj) {
					best_obj = obj;
					best_coord = {vi_x, vi_y};
				}
			}
		}
		res_coords.push_back(best_coord);
		Polygon_with_holes_2 mink_res_2d = CGAL::minkowski_sum_2(Polygon_2_trans(piece,
			best_coord[0], best_coord[1]), Polygon_2_turn_acw(piece, PI));
		feasible.difference(mink_res_2d);
		num_packed++;
		std::cout << num_packed << std::endl;
		*/

		for (int i_eve = 0; i_eve < eve_n; ++i_eve) {
			//std::cout << "updating: i_eve: " << i_eve << std::endl;
			/*
			if (i_eve == 2) {
				Polygon_set_2 pgn_set_temp = feasible_vec[i_eve];
				CGAL::draw(pgn_set_temp);
				Polygon_2 nfp_trans = Polygon_2_trans(nfp_vv[i_eve][best_i_eve], best_coord[0],
					best_coord[1]);
				nfp_trans = nfp_vv[i_eve][best_i_eve];
				std::cout << nfp_trans << std::endl;
				CGAL::draw(nfp_trans);
				Polygon_set_2 test;
				test.insert(nfp_trans);
				CGAL::draw(test);
				test.difference(pgn_set_temp);
				CGAL::draw(test);
				test.difference(nfp_trans);
				CGAL::draw(test);
				pgn_set_temp.difference(test);
				CGAL::draw(pgn_set_temp);
			}
			*/
			feasible_vec[i_eve].difference(Polygon_2_trans(nfp_vv[i_eve][best_i_eve], best_coord[0],
				best_coord[1]));
		}

		num_packed++;
		std::cout << "num_packed: " << num_packed << std::endl;
	}

	out_num.open("D:/Ph.D/Code/Packing/data/packing/num_pieces.txt", std::ios::out | std::ios::app);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
	out_num << num_packed;
	out_num.close();
	//for (int i_num = 0; i_num < num_packed; i_num++) {
	//	pgns_to_draw.push_back(Polygon_2_trans(piece, res_coords[i_num][0], res_coords[i_num][1]));
	//}
	pgns_to_draw.push_back(sheet);

	double length = 0;
	double width = 0;
	for (VertexIterator vi = sheet.vertices_begin(); vi != sheet.vertices_end(); ++vi) {
		double vi_x = to_double(vi->x().approx());
		double vi_y = to_double(vi->y().approx());
		if (vi_x > length)
			length = vi_x;
		if (vi_y > width)
			width = vi_y;
	}
	draw_whole_res(length, width, pgns_to_draw, length / 80);

	return 0;
}

/*
\n 换行符(LF)

\r 回车(CR) ，相当于键盘上的"Enter"

\t 跳到下一个TAB位置

\0 空字符(NULL)

\' 单引号（撇号）

\" 双引号

\\ 代表一个反斜线字符''\'

\ 继续符，可用于一行的结尾，表示本行与下一行连接起来
*/

/*
//尝试plane with key points数据集，只用2D NFP
#include <list>
#include <iostream>
#include <fstream>
#include <cassert>

#include <thread>

#include <ilcplex\ilocplex.h>
ILOSTLBEGIN // 等同于 using namespace std; 声明命名空间

#include <Eigen/Dense>

#include <CGAL/IO/read_points.h>

#include <CGAL/Simple_cartesian.h>
#include <CGAL/Min_sphere_of_spheres_d.h>
#include <CGAL/Min_sphere_of_points_d_traits_2.h>
#include <CGAL/Random.h>

#include <CGAL/Exact_predicates_exact_constructions_kernel.h>
#include <CGAL/Polygon_2.h>
#include <CGAL/Polygon_with_holes_2.h>
#include <CGAL/Polygon_set_2.h>

#include <CGAL/Boolean_set_operations_2.h>

#include <CGAL/draw_polygon_set_2.h>
#include <CGAL/draw_polygon_2.h>
#include <CGAL/draw_polygon_with_holes_2.h>

#include <CGAL/Polyhedron_3.h>
#include <CGAL/Nef_polyhedron_3.h>
#include <CGAL/minkowski_sum_2.h>
#include <CGAL/minkowski_sum_3.h>
#include <CGAL/partition_2.h>
#include <CGAL/Partition_traits_2.h>
#include <CGAL/IO/Nef_polyhedron_iostream_3.h>
#include <CGAL/Nef_3/SNC_indexed_items.h>
#include <CGAL/convex_decomposition_3.h>
#include <CGAL/convex_hull_3.h>

#include <CGAL/draw_polyhedron.h>
#include <CGAL/draw_nef_3.h>

#include <CGAL/Epick_d.h>
#include <CGAL/Triangulation.h>

#include "gurobi_c++.h"

#include <draw_res.h>
#include <point_calculation.h>
#include <input_initialize.h>
#include <calculate_2d.h>
#include <calculate_3d.h>
#include <generate_para_2d.h>
#include <generate_para_3d.h>
#include <generate_para_4d.h>
#include <test_draw.h>
#include <try_program.h>
#include <draw_whole_res.h>
#include <scip_program.h>
#include <gurobi_program.h>


#define PI 3.1415926535

#define Epsilon 0.00000001

typedef CGAL::Exact_predicates_exact_constructions_kernel K;
typedef CGAL::Polygon_2<K>                                Polygon_2;
typedef CGAL::Polygon_with_holes_2<K>                     Polygon_with_holes_2;
typedef CGAL::Polygon_set_2<K>                            Polygon_set_2;
typedef CGAL::Point_2<K>                                  Point_2;
typedef CGAL::Vector_2<K>                                 Vector_2;
typedef CGAL::Point_3<K>                                  Point_3;
typedef CGAL::Polyhedron_3<K>							  Polyhedron;
typedef CGAL::Nef_polyhedron_3<K>						  Nef_polyhedron;
//typedef K::Point_2										  Point;
using std::cout;
using std::endl;

typedef CGAL::Simple_cartesian<double>                   c_K;//引自参考min_circle_2的例子
typedef CGAL::Min_sphere_of_points_d_traits_2<c_K, double>   c_Traits;
typedef CGAL::Min_sphere_of_spheres_d<c_Traits>            Min_circle;
typedef CGAL::Point_2<c_K>                                 c_Point_2;
typedef CGAL::Polygon_2<c_K>                                c_Polygon_2;
typedef c_K::Point_3									   input_Point;

typedef CGAL::Partition_traits_2<K>                         Traits;
typedef Traits::Polygon_2                                   p_Polygon_2;
typedef Traits::Point_2                                     p_Point_2;

typedef Polygon_2::Vertex_iterator						  VertexIterator;
typedef Polygon_2::Edge_const_iterator					  EdgeIterator;
typedef p_Polygon_2::Vertex_iterator					  p_VertexIterator;
typedef Nef_polyhedron::Volume_const_iterator			  Volume_const_iterator;
typedef Polyhedron::Vertex_iterator						  phd_VertexIterator;
typedef Polyhedron::Facet_iterator					      phd_FacetIterator;
//typedef Nef_polyhedron::Vertex_iterator					  N_phd_VertexIterator;
typedef Nef_polyhedron::Aff_transformation_3			  Aff_transformation_3;
typedef Polyhedron::Halfedge_around_facet_circulator	  Halfedge_facet_circulator;

typedef CGAL::Epick_d<CGAL::Dynamic_dimension_tag>		  D_dim;
typedef CGAL::Triangulation<D_dim>                        Triangulation;
typedef CGAL::Triangulation_data_structure<D_dim>         TDS;
typedef Triangulation::Point			                  D_dim_point;
typedef Triangulation::Full_cell_handle					  Full_cell_handle;
typedef Triangulation::Facet							  Facet;
typedef Triangulation::Face								  Face;

typedef std::list<Point_2>								  Point_list_2;
typedef std::list<c_Point_2>							  c_Point_list_2;
typedef std::list<p_Polygon_2>                            p_Pgn_list_2;
typedef std::list<Point_3>								  Point_list_3;
typedef std::list<Polygon_with_holes_2>                   Pwh_list_2;
typedef std::list<Polygon_2>							  Pgn_list_2;
typedef std::list<Nef_polyhedron>						  N_phd_list;
typedef std::list<Polyhedron>							  phd_list;
typedef std::vector<Full_cell_handle>					  Full_cells;
typedef std::vector<Face>								  Faces;

bool res_sort_nfp(std::vector<double> a, std::vector<double> b) {
	if (a[0] < b[0] + Epsilon && b[0] < a[0] + Epsilon)
		return a[1] < b[1];//如果目标函数一样，重合面积升序
	else
		return a[0] < b[0];//目标函数升序(小的放前面)
}

bool res_sort_ifp(std::vector<double> a, std::vector<double> b) {
	if (a[4] == b[4])
		return a[0] < b[0];//如果ifp编号一样，目标函数升序
	else
		return a[4] < b[4];//ifp编号升序(小的放前面)
}

//根据数组第一位（下标为0），升序排序（小的放前面）
bool res_sort_0(std::vector<double> a, std::vector<double> b) {
	return a[0] < b[0];//ifp编号升序(小的放前面)
}

int main()
{
	std::ofstream out_num;
	out_num.precision(14);

	int id_piece;
	//id_piece = 0;
	std::cout << "请输入要使用哪一个零件（编号1-9），按回车结束" << std::endl;
	std::cin >> id_piece;

	c_Point_list_2 c_points_piece = input_polygon("D:/Ph.D/Code/Packing/data/packing/Plane with key points/Pieces/piece " + std::to_string(id_piece) + ".xyz");

	FILE* fp;
	std::string kp_str = "D:/Ph.D/Code/Packing/data/packing/Plane with key points/Pieces/key points " + std::to_string(id_piece) + ".txt";
	fp = fopen(kp_str.c_str(), "r");
	std::vector<std::vector<double>> key_points;
	for (int i_case = 0; i_case < 3; ++i_case) {
		std::vector<double> key_point(2);
		for (int i_id = 0; i_id < 2; ++i_id) {
			fscanf(fp, "%lf", &key_point[i_id]);
		}
		key_points.push_back(key_point);
	}

	int id_sheet;
	//id_sheet = 0;
	std::cout << "请输入要使用哪一块板材（编号1-5），按回车结束" << std::endl;
	std::cin >> id_sheet;

	std::vector<int> sheet_holes = { 3,2,3,3,6 };

	c_Point_list_2 c_points_sheet = input_polygon("D:/Ph.D/Code/Packing/data/packing/Plane with key points/Sheets/sheet " + std::to_string(id_sheet) + ".xyz");

	std::vector < c_Point_list_2 > vec_c_points_holes;
	for (int i_p_num = 0; i_p_num < sheet_holes[id_sheet - 1]; ++i_p_num) {
		c_Point_list_2 vec_c_points_hole = input_polygon("D:/Ph.D/Code/Packing/data/packing/Plane with key points/Sheets/sheet " + std::to_string(id_sheet) + "h" + std::to_string(i_p_num + 1) + ".xyz");
		vec_c_points_holes.push_back(vec_c_points_hole);
	}

	//std::vector < c_Point_list_2 > vec_c_points_holes = input_polygons(sheet_holes[id_sheet - 1], "D:/Ph.D/Code/Packing/data/packing/Plane with key points/Sheets/sheet " + std::to_string(id_piece) + "h");

	double obj_ang;
	obj_ang = 0;
	//std::cout << "请输入目标函数角度（弧度制），按回车结束" << std::endl;
	//std::cin >> obj_ang;
	double x_para = cos(obj_ang);
	double y_para = sin(obj_ang);
	//std::cout << sin(PI/2) << std::endl;

	int eve_n;
	eve_n = 1;
	//std::cout << "请输入选择几个均分角度进行比较，按回车结束" << std::endl;
	//std::cin >> eve_n;

	std::vector<double> cc_piece(2);
	Polygon_2 piece;
	// for (c_Point_list_2::const_iterator it = c_points_piece.begin(); it != c_points_piece.end(); ++it)
	//	piece.push_back(Point_2(it->x(), it->y()));
	// CGAL::draw(piece);
	piece = init_min_c_c(c_points_piece, cc_piece).outer_boundary();
	Polygon_2 key_point_hole;
	for (int i_poi = 0; i_poi < 3; ++i_poi)
		key_point_hole.push_back(Point_2(key_points[i_poi][0] - cc_piece[0], key_points[i_poi][1]
			- cc_piece[1]));

	Polygon_2 sheet;
	for (c_Point_list_2::const_iterator it = c_points_sheet.begin(); it != c_points_sheet.end(); ++it)
		sheet.push_back(Point_2(it->x(), it->y()));

	std::vector<Polygon_2> holes(sheet_holes[id_sheet - 1]);
	for (int i_p_num = 0; i_p_num < sheet_holes[id_sheet - 1]; ++i_p_num) {
		for (c_Point_list_2::const_iterator it = vec_c_points_holes[i_p_num].begin(); it
			!= vec_c_points_holes[i_p_num].end(); ++it)
			holes[i_p_num].push_back(Point_2(it->x(), it->y()));
	}

	Polygon_set_2 piece_draw;
	piece_draw.insert(piece);
	piece_draw.difference(key_point_hole);
	CGAL::draw(piece_draw);

	Polygon_set_2 sheet_draw;
	sheet_draw.insert(sheet);
	for (int i_p_num = 0; i_p_num < sheet_holes[id_sheet - 1]; ++i_p_num) {
		sheet_draw.difference(holes[i_p_num]);
	}
	CGAL::draw(sheet_draw);

	// feasible_basic只针对当前旋转角度
	Polygon_set_2 feasible_basic;
	feasible_basic.insert(sheet);
	Polygon_2 sheet_kp;
	for (int i_poi = 0; i_poi < 3; ++i_poi) {
		sheet_kp = Polygon_2_trans(sheet, cc_piece[0] - key_points[i_poi][0], cc_piece[1]
			- key_points[i_poi][1]);
		feasible_basic.intersection(sheet_kp);
	}
	//CGAL::draw(feasible_basic);
	for (int i_p_num = 0; i_p_num < sheet_holes[id_sheet - 1]; ++i_p_num) {
		Polygon_with_holes_2 mink_res_2d = CGAL::minkowski_sum_2(holes[i_p_num],
			Polygon_2_turn_acw(piece, PI));
		feasible_basic.difference(mink_res_2d);
	}
	//CGAL::draw(feasible_basic);

	std::vector<Polygon_2> pgns_to_draw;
	for (int i_p_num = 0; i_p_num < sheet_holes[id_sheet - 1]; ++i_p_num)
		pgns_to_draw.push_back(holes[i_p_num]);
	int num_packed = 0;
	//Polygon_set_2 feasible = feasible_basic;
	std::vector<std::vector<double>> res_coords;
	for (;;) {
		double best_obj = 100000;
		double best_ang;
		std::vector<double> best_coord;
		for (int i_eve = 0; i_eve < eve_n; ++i_eve) {
			double ang_r = 2.0 * PI / eve_n * i_eve;
			Polygon_2 piece_r = Polygon_2_turn_acw(piece, ang_r);
			Polygon_set_2 feasible;
			feasible.insert(sheet);
			Polygon_2 sheet_kp;
			for (int i_poi = 0; i_poi < 3; ++i_poi) {
				double x_o = cc_piece[0] - key_points[i_poi][0];
				double y_o = cc_piece[1] - key_points[i_poi][1];
				double x_r = x_o * cos(ang_r) - y_o * sin(ang_r);
				double y_r = x_o * sin(ang_r) + y_o * cos(ang_r);
				sheet_kp = Polygon_2_trans(sheet, x_r, y_r);
				feasible.intersection(sheet_kp);
			}
			for (int i_p_num = 0; i_p_num < pgns_to_draw.size(); ++i_p_num) {
				Polygon_with_holes_2 mink_res_2d = CGAL::minkowski_sum_2(pgns_to_draw[i_p_num],
					Polygon_2_turn_acw(piece_r, PI));
				feasible.difference(mink_res_2d);
			}
			if (feasible.number_of_polygons_with_holes() == 0) {
				continue;
			}
			std::list<Polygon_with_holes_2> res;
			std::list<Polygon_with_holes_2>::const_iterator it;

			double best_obj_local = 100000;
			std::vector<double> best_coord_local;
			feasible.polygons_with_holes(std::back_inserter(res));
			for (it = res.begin(); it != res.end(); ++it) {
				Polygon_2 ob = it->outer_boundary();
				for (VertexIterator vi = ob.vertices_begin(); vi != ob.vertices_end(); ++vi) {
					double vi_x = to_double(vi->x().approx());
					double vi_y = to_double(vi->y().approx());
					double obj = vi_x * x_para + vi_y * y_para;
					if (obj < best_obj_local) {
						best_obj_local = obj;
						best_coord_local = { vi_x, vi_y };
					}
				}
			}
			if (best_obj_local < best_obj) {
				best_obj = best_obj_local;
				best_coord = best_coord_local;
				best_ang = ang_r;
			}
		}

		if (best_obj == 100000)
			break;

		pgns_to_draw.push_back(Polygon_2_trans(Polygon_2_turn_acw(piece, best_ang), best_coord[0],
			best_coord[1]));
		num_packed++;
		std::cout << num_packed << std::endl;
	}

	out_num.open("D:/Ph.D/Code/Packing/data/packing/num_pieces.txt", std::ios::out | std::ios::app);  //以写入和在文件末尾添加的方式打开.txt文件，没有的话就创建该文件。
	out_num << num_packed;
	out_num.close();
	//for (int i_num = 0; i_num < num_packed; i_num++) {
	//	pgns_to_draw.push_back(Polygon_2_trans(piece, res_coords[i_num][0], res_coords[i_num][1]));
	//}
	pgns_to_draw.push_back(sheet);

	double length = 0;
	double width = 0;
	for (VertexIterator vi = sheet.vertices_begin(); vi != sheet.vertices_end(); ++vi) {
		double vi_x = to_double(vi->x().approx());
		double vi_y = to_double(vi->y().approx());
		if (vi_x > length)
			length = vi_x;
		if (vi_y > width)
			width = vi_y;
	}
	draw_whole_res(length, width, pgns_to_draw, length / 80);

	return 0;
}
*/